# Model

## Learning Log

# Sprint 3:

<details>
<summary> Dinsdag 27 oktober </summary>

### Feedback verwerken van gisteren

#### De uitklapmenu’s laten aansluiten op mijn website

Katey gaf tijdens de feedback aan dat de kopjes van mijn uitklapmenu’s wat groter mochten. Daardoor ontdekte ik dat ik de opmaak van mijn details en summary nog niet bewust had ingesteld.

Ik heb de kopjes van de uitklapmenu’s hetzelfde lettertype gegeven als mijn andere kopjes, maar dan iets kleiner. De tekst binnen de menu’s heb ik juist iets kleiner gemaakt dan mijn gewone alinea’s, waarbij ik erop heb gelet dat deze goed leesbaar blijft.

Hierdoor sluiten de uitklapmenu’s beter aan op de rest van mijn website en vormt de typografie meer één geheel.

<img src="./assets/images-readme/feedback-katey.png" alt="" />
Foto: De feedback verwerkt die ik gister heb gekregen van Katey

#### Mijn CSS opruimen met nesting

Ik heb de voorbeelden die Sanne in mijn code had gemaakt opnieuw bekeken en gebruikt om zelf met CSS-nesting aan de slag te gaan. Vervolgens heb ik dit in mijn hele CSS-bestand toegepast, zodat regels die bij elkaar horen bij elkaar staan en ik minder selectors hoef te herhalen.

Na iedere samenvoeging heb ik mijn website via Live Server gecontroleerd. Zo kon ik stap voor stap bekijken of de vormgeving en werking nog klopten en eventuele foutjes meteen aanpassen.

Volgens mij is dit goed gelukt. Mijn CSS is nu overzichtelijker en door de voorbeelden zelf toe te passen, begrijp ik beter hoe nesting werkt.

<img src="./assets/images-readme/css.png" alt="" />
Foto: Ik heb mijn css mooiere en overzichtelijk gemaakt.

#### Meer samenhang in mijn afbeeldingen en gifjes

Ik heb gekeken hoe ik mijn afbeeldingen en gifjes meer één geheel kon laten vormen. Door de feedback van Sanne zag ik dat ik verschillende stijlen door elkaar gebruikte, waardoor het beeldmateriaal minder goed op elkaar aansloot.

Vanwege de beschikbare tijd kon ik niet alles opnieuw tekenen of opbouwen. Daarom heb ik ChatGPT gevraagd om mijn gifjes dezelfde realistische uitstraling te geven als de eerder gemaakte afbeeldingen van mijzelf. Die afbeeldingen heb ik als voorbeeld meegestuurd.

Daarna heb ik de resultaten zelf verder afgewerkt in Canva. Daar heb ik van de afbeeldingen weer bewegende gifjes gemaakt en deze gedownload voor mijn website.

Ik begrijp nu beter waarom Sanne dit aangaf. Ik vond de beelden afzonderlijk leuk, maar samen vormden ze nog geen duidelijk geheel. Door de stijl op elkaar af te stemmen, komt de sfeer van mijn website beter naar voren.

<img src="./assets/images-readme/nieuwegifjes.png" alt="" />
Foto: Het verschil in de oude en de nieuwe gif.

#### Afbeeldingen kiezen en de privacyknop aanpassen

Ik heb gekeken welke afbeeldingen ik nog binnen de beschikbare tijd kan bewerken. Omdat ik niet zeker weet of ik alles ga redden, heb ik keuzes gemaakt in wat ik nog wil aanpassen om meer samenhang te krijgen.

Ook de afbeeldingen van mijn privacyknop heb ik een realistischere uitstraling gegeven. De handjes vond ik daardoor niet meer goed passen. Daarom heb ik voor de geopende melding het mandje anders vormgegeven, zodat het lijkt alsof iemand al met het haakwerk bezig is. Zo past ook dit onderdeel beter bij de nieuwe stijl van mijn website.

<img src="./assets/images-readme/cookienieuwe.png" alt="" />
Foto: De verschillende cookies.

#### De lampjes op elkaar afstemmen

Ik heb bij alle schilderijtjes hetzelfde lampje gebruikt, zodat ze beter bij elkaar passen. Door dit detail consequent terug te laten komen, vormen de schilderijtjes meer één geheel en sluit het beeldmateriaal beter aan op de rest van mijn website.

<img src="./assets/images-readme/schilder.png" alt="" />
Foto: De schilderijtjes als 1 geheel gemaakt.

#### Ook de gifjes dezelfde stijl geven

Ik had de gifjes net allemaal een eigen, leuke omgeving gegeven. Toch merkte ik dat ook daarin weer verschillende stijlen door elkaar liepen. Daarom heb ik ze opnieuw aangepast en zo realistisch mogelijk gemaakt, zodat ze beter aansluiten op mijn andere afbeeldingen.

Hierdoor behouden de diertjes hun eigen uitstraling, maar vormen de gifjes samen meer één geheel. Ik heb hiervan geleerd om niet alleen naar ieder beeld apart te kijken, maar ook naar hoe alle beelden bij elkaar passen op mijn website.

<img src="./assets/images-readme/gifjes-n.png" alt="" />
Foto: Hoe ik mijn gifjes heb veranderd zodat ze in de zelfde stijl zijn.

#### De juiste lijsten gebruiken bij mijn haakpatronen

Toen ik het volgende feedbackpunt van Sanne bekeek, ontdekte ik dat ik bij mijn haakpatronen overal een <ul> had gebruikt. Bij de stappen van een patroon is de volgorde juist belangrijk: je moet de toeren in de juiste volgorde uitvoeren. Daarom past een geordende lijst, een <ol>, hier beter. Voor de benodigdheden kan een <ul> wel blijven staan.
Ik heb meteen gekeken of ik dit kon combineren met het trucje dat Sanne mij had uitgelegd: de lijstmarkering aanpassen, zodat er bijvoorbeeld ‘Toer 1’ en ‘Toer 2’ voor de stappen staat. Zo sluit de nummering beter aan op het haakpatroon.

Uiteindelijk heb ik dit alleen bij het patroon van Flappie toegepast, omdat het meer werk kostte dan verwacht. Met meer tijd had ik dit ook bij de andere patronen willen doen.

<img src="./assets/images-readme/patroon-flappie.png" alt="" />
Foto: Ik heb het patroon van Flappie aangepast met de feedback van Sanne.
</details>

<details>
<summary> Maandag 26 oktober </summary>

### kleine aanpasingen voor de les

#### Meer samenhang tussen de gifjes

Ik heb gekeken hoe ik de gifjes op mijn website meer één geheel kon laten vormen. Bij het beertje en de krab had ik al aandacht besteed aan de omgeving. Daarom wilde ik ook de andere haakfiguurtjes op een vergelijkbare manier uitwerken.

Voor het draakje, eendje, leeuwtje en Misty heb ik geprobeerd iets leuks te bedenken dat bij het diertje past. Daarbij wilde ik de speelse beweging behouden en de gifjes een wat huiselijkere sfeer geven.

Zo krijgt ieder figuurtje een eigen plekje, terwijl de gifjes beter op elkaar aansluiten. Hiermee wil ik de warme, persoonlijke sfeer van mijn website ook in het beeldmateriaal terug laten komen.

<img src="./assets/images-readme/gifs.png" alt="" />
Foto: De gifjes die ik meer samenhang heb gegeven.

#### Een muisaanwijzer in mijn haakthema

Ik wilde ook mijn muisaanwijzer laten aansluiten op mijn website. Daarom heb ik in Canva twee kleine afbeeldingen gemaakt: een bolletje wol met een haaknaald voor de gewone aanwijzer en een haaknaald met steken voor links, knoppen en uitklapmenu’s. De afbeeldingen waren 40 × 40 pixels.

Ik vermoedde dat ik de afbeeldingen met url() in mijn CSS kon toevoegen, zoals ik eerder met een achtergrond had gedaan. Toch had ik het gevoel dat mijn code nog niet compleet was. Ik wilde eerst uitleg zoeken op YouTube, maar vanwege de beperkte tijd heb ik mijn idee en code aan ChatGPT voorgelegd.

#### Het klikpunt en een reserveaanwijzer toevoegen

ChatGPT wees mij op het klikpunt en de reserveaanwijzer die nog ontbraken. Met twee getallen na de afbeelding geef ik aan waar het precieze klikpunt zit. Daarna volgt `auto` of `pointer`, zodat de browser een standaardaanwijzer kan gebruiken als de afbeelding niet geladen wordt.

Ik kreeg ook advies over de afmetingen. Mijn afbeeldingen van 40 × 40 pixels zijn niet automatisch te groot, maar het blijft belangrijk om te controleren of ze goed worden weergegeven en prettig werken.

Na het aanvullen van mijn CSS werkte mijn aangepaste muisaanwijzer. Het is een klein detail, maar het maakt mijn website voor mij persoonlijker en zorgt ervoor dat het haakthema ook tijdens het navigeren terugkomt.

<img src="./assets/images-readme/muis.png" alt="" />
Foto: hoe ik gevraagd aan chat of mijn code klopt.

### In de les

#### Elkaars werk bekijken tijdens de expo

In de les hebben we een expo gehouden waarbij we elkaars websites konden bekijken. Bij ons werk lag een feedbackformulier waarop klasgenoten gekleurde stickers en opmerkingen konden achterlaten. Blauw stond voor privacy/wet en toegankelijkheid, rood voor ontwerp en groen voor techniek.

#### De feedback op mijn website

Ik kreeg positieve reacties op de duidelijke privacyinformatie en het gebruik van lege alt-teksten bij decoratieve afbeeldingen. Ook vonden klasgenoten mijn website overzichtelijk en kwam mijn persoonlijkheid duidelijk naar voren. De kleine details, zoals de lampjes die aan en uit gaan, werden gewaardeerd. Mijn songtekst werd daarnaast als kleurrijk omschreven.

Op technisch gebied kreeg ik complimenten over het gebruik van Grid, de responsiviteit en de CSS-animaties. Er werd bijvoorbeeld genoemd dat een animatie soepel verliep.

Het was fijn om mijn werk op deze manier te laten bekijken. De reacties geven mij vertrouwen dat mijn rustige website toch persoonlijk overkomt en dat de speelse details iets toevoegen aan het geheel.

<img src="./assets/images-readme/expo.png" alt="" />
Foto: Mijn feedback die ik gekregen heb tijdens de expo

### Elkaars website en README beoordelen

Na de expo werden we verdeeld in groepjes van vier. Ik zat samen met Katey, Samir en Lars. Katey en ik hebben elkaars website bekeken en beoordeeld. Zo konden we feedback geven en zien hoe de ander de opdracht had aangepakt.

Daarna hebben we met z’n vieren onze README-bestanden doorgenomen. We controleerden of alle benodigde informatie erin stond. Hieruit bleek dat mijn README compleet was. Dat was fijn om te horen, omdat ik naast mijn website ook de bijbehorende documentatie goed op orde wil hebben.

<img src="./assets/images-readme/elkaarbeoordelen.png" alt="" />
Foto: De beoordelings formulieren die we hebben ingevuld.

### Mijn CSS overzichtelijker maken met nesting

Aan het einde van de les kwam Sanne even bij mij zitten. Hij had een paar handige tips voor mijn code en legde uit hoe ik CSS kan nesten. Daarbij heeft hij een aantal voorbeelden in mijn code uitgewerkt, zodat ik kon zien hoe ik dit zelf kan toepassen.

Met nesting kan ik CSS-regels die bij elkaar horen binnen elkaar schrijven. Hierdoor hoef ik niet steeds de volledige selector te herhalen en wordt duidelijker welke regels bij welk onderdeel horen.

Ik was erg blij met deze uitleg. Mijn CSS-bestand is inmiddels behoorlijk uitgebreid en op deze manier kan ik mijn code netter en overzichtelijker maken. De voorbeelden van Sanne kan ik gebruiken om de rest van mijn CSS verder op te ruimen.

<img src="./assets/images-readme/voorbeeld-sanne.png" alt="" />
Foto: De voorbeelden die Sanne gaf voor het nesten van mijn css.

</details>

<details>
<summary> zondag 25 oktober </summary>

### SOngtekst

#### Het refrein toevoegen en vormgeven

Daarna ben ik verdergegaan met het refrein, zoals Diederik had geadviseerd. Ik wilde vooral de herkenbare letters Y.M.C.A. laten opvallen en hiermee het vrolijke, dansende gevoel van het liedje uitbeelden.

Ik heb iedere letter en punt in een aparte <span> gezet, zodat ik ze afzonderlijk kan vormgeven. De letters kregen elk een eigen kleur: rood, blauw, groen en paars. Met een verspringend schaduweffect heb ik ze meer diepte gegeven.

#### Beweging en herhaling

Vervolgens heb ik een bounce-animatie toegevoegd waarbij de letters springen en de punten blijven staan. Ook heb ik een overgang voor het vergroten ingesteld, zodat ik met een hover-effect kan spelen. De grootte van Y.M.C.A. heb ik gekoppeld aan de schermbreedte.

Bij de tweede herhaling van ‘It’s fun to stay at the Y.M.C.A.’ heb ik dezelfde opbouw gebruikt. Die herhaling past bij het liedje en zorgt voor samenhang in mijn ontwerp. De inleidende zinnen blijven klein en links uitgelijnd, terwijl Y.M.C.A. groot in het midden staat. Zo krijgt het belangrijkste deel van het refrein duidelijk de nadruk. Om de tweede Y.M.C.A. toch anders te maken gaat de animatie hier van voor naar achter.

<img src="./assets/images-readme/tweedeymca.png" alt="" />
Foto: hoe ik de twee Y.M.C.A er in heb gezet. en dat het herhaling is maar toch net iets anders.

### Opnieuw feedback verwerken

Ik heb mijn website opnieuw laten bekijken en kreeg weer bruikbare feedback. Er stonden nog een paar spel- en typefouten in de teksten, die ik meteen heb verbeterd. Ook bleek dat op de homepagina bij Misty, Bert en Teddy nog de algemene namen ‘poes’, ‘krab’ en ‘beertje’ stonden. Die heb ik aangepast naar de namen van de figuurtjes.

#### De privacyknop verfijnen

Samen hebben we nog eens naar mijn privacyknop gekeken. Die was erg nadrukkelijk aanwezig. Daarom heb ik het woord ‘Privacy’ aangepast, zodat het lijkt alsof het in de mand is gehaakt. Ook heb ik de bollen wol verder in de mand geplaatst en de naalden meer op haaknaalden laten lijken. Hiermee sluit de knop beter aan op mijn haakwereld.

### Wat goed werkt

De tester vond de opmaak prettig en waardeerde dat de haakpatronen aparte pagina’s hebben, zodat bezoekers niet eindeloos hoeven te scrollen. Ook vond ze de afbeeldingen en gifjes van mijzelf goed gelukt. De kleuren van de lichte en donkere modus werden positief ontvangen, vooral het detail dat de lampjes aan- en uitgaan.

Deze feedback hielp mij om de laatste details te verbeteren en liet zien dat mijn persoonlijke stijl duidelijk overkomt.

<img src="./assets/images-readme/feedabcktessa.png" alt="" />
Foto: Een aantal foto's van de feedback en hoe ik het heb aangepast.

### Songtekst

#### De nadruk op ‘everything’ en ‘enjoy’

Ik ben verdergegaan met mijn songtekst en heb het liedje opnieuw beluisterd. Bij de zin ‘They have everything for young men to enjoy’ hoorde ik minder uitgesproken accenten dan bij Y.M.C.A., maar ‘everything’ en ‘enjoy’ springen er wel uit. Daarom heb ik de rest van de zin rustig gehouden en deze twee woorden meer nadruk gegeven.

Beide woorden heb ik in een em gezet en groter gemaakt. ‘Everything’ kreeg een blauwe kleur en een animatie waarbij het woord breder wordt. ‘Enjoy’ heb ik paars gemaakt en een dansende beweging gegeven, waarbij het omhoog beweegt en naar links en rechts draait. Tijdens die beweging verandert ook het lettergewicht van het variabele font.

De animaties duren drie seconden. ‘Enjoy’ begint anderhalve seconde later, zodat de accenten elkaar afwisselen. Daarnaast heb ik gewerkt met extra letterruimte bij ‘everything’ en een schaduweffect bij ‘enjoy’. Zo probeer ik de nadruk die ik hoor in de muziek zichtbaar te maken in mijn typografie.

<img src="./assets/images-readme/everthing-enjoy.png" alt="" />
Foto: Hoe ik de volgende zin heb gemaakt.

#### ‘All the boys’ nadruk geven

Daarna ben ik verdergegaan met de laatste zin van het refrein. Tijdens het luisteren hoorde ik nadruk op ‘all the’ en vooral op ‘boys’. Dit wilde ik zichtbaar maken door de tekst naar het einde van de zin steeds groter en opvallender te laten worden.

Ik heb ‘all the boys’ in een strong gezet en ‘boys’ daarbinnen een eigen em gegeven. Hierdoor kan ik beide onderdelen apart vormgeven. ‘All the’ heb ik vergroot en ‘BOYS’ nog groter gemaakt, met rode letters en een witte en blauwe schaduw. Dit sluit aan op de kleuren die ik eerder in het refrein heb gebruikt.

Ook heb ik een hover-effect toegevoegd. Als je met de muis over ‘BOYS’ gaat, wordt het woord groter, draait het iets naar links en verandert het lettergewicht. Zo krijgt het belangrijkste woord van de zin extra nadruk en een speels effect.

#### ‘BOYS’ in kleine stapjes laten bewegen

Ik had het gevoel dat er nog iets miste bij ‘BOYS’. Daarom wilde ik een beweging toevoegen die zichtbaar wordt tijdens het scrollen. In Canva heb ik verschillende animaties bekeken om te ontdekken welk effect ik leuk vond. Het idee van een woord dat als een trappetje naar beneden beweegt, sprak mij het meest aan.

Vervolgens heb ik teruggekeken naar mijn scrollanimatie voor ‘down’ en onderzocht hoe ik met @keyframes verschillende stapjes kon maken. Hierbij beweegt ‘BOYS’ als één geheel. Ik heb veel getest en geëxperimenteerd met het aantal treden en de afstand tussen de stappen. Helaas ben ik vergeten om van die tussenversies screenshots te maken.

Uiteindelijk heb ik gekozen voor zes kleine stapjes. Daarmee krijgt het woord een speelse beweging, zonder dat het effect te heftig wordt. Als volgende stap wil ik onderzoeken of ik ook met de helderheid kan spelen om het woord tijdens het scrollen extra nadruk te geven.

<img src="./assets/images-readme/boys.png" alt="" />
Foto: Hoe ik de nadruk heb gelegd op de BOYS.

### De beweging afmaken met transparantie

Als laatste heb ik de zichtbaarheid van ‘BOYS’ tijdens de trapjesanimatie aangepast. Terwijl het woord bij het scrollen in kleine stapjes naar beneden beweegt, vervaagt het nu geleidelijk.

Deze toevoeging maakt het effect voor mij helemaal af. Het woord springt eerst duidelijk naar voren en verdwijnt daarna rustig naar de achtergrond. Zo vormt de beweging een speelse afsluiting van mijn refrein.

<img src="./assets/images-readme/boys2.png" alt="" />
Foto: Hoe ik de nadruk heb gelegd op de BOYS.

## Zaterdag 24 oktober

### Feedback verwerken

#### Losse links en knoppen aanpassen

Ik ben begonnen met het verwerken van de feedback op mijn HTML. Bij links die als enige in een `<p>` stonden, heb ik de overbodige alinea weggehaald en de `<a>` los geplaatst.

Hierdoor veranderde de opmaak van mijn knoppen en stonden ze niet meer zoals ik wilde. Daarom heb ik de bijbehorende CSS aangepast om de plaatsing en onderlinge ruimte weer in balans te brengen. Zo heb ik mijn HTML eenvoudiger gemaakt en de vormgeving daarop afgestemd.

<img src="./assets/images-readme/knopaanpassen.png" alt="" />
Foto: Hoe ik mij a heb aangepast zodat alles weer goed staat.

#### Mijn website verbeteren voor kleinere schermen

Daarna ben ik verdergegaan met de feedback over kleinere schermen. Via de responsive weergave in de browser heb ik verschillende schermbreedtes uitgeprobeerd. Zo kon ik ook bekijken hoe mijn website eruitziet op een scherm dat smaller is dan mijn eigen telefoon.

Ik merkte dat sommige teksten erg smal werden en onderdelen niet meer goed pasten. Daarom heb ik gewerkt aan de ruimte aan de zijkanten en onderzocht welke gifjes ik op kleine schermen kan verbergen. Hiermee wil ik de tekst meer ruimte geven en de pagina rustiger maken.

Tussendoor heb ik steeds tussen smalle en brede schermen gewisseld om de gevolgen van mijn aanpassingen te bekijken. Daarbij lette ik op de titel, navigatie, afbeeldingen en tekstindeling. Zo heb ik geleerd dat testen op alleen mijn eigen telefoon niet voldoende is om te weten of mijn website op andere schermformaten goed werkt.

<img src="./assets/images-readme/naarkleinscherm.png" alt="" />
Foto: Hoe ik heb gekeken hoe ik mijn website kan verbeteren voor een klein scherm.

### De indeling van mijn main opnieuw opbouwen

Na de eerdere aanpassingen merkte ik dat de teksten op kleine schermen nog steeds niet prettig stonden. Daarom heb ik besloten om de volledige indeling van mijn `main` opnieuw aan te pakken.

Ik heb de ruimte en verdeling van de inhoud aangepast en het resultaat opnieuw op een klein scherm bekeken. De tekst krijgt nu voldoende ruimte en sluit beter aan op de schermbreedte. Hiermee heb ik de eerdere verbetering verder uitgewerkt, zodat ook de hoofdinhoud op een klein scherm goed leesbaar is.

<img src="./assets/images-readme/tekstklienscherm.png" alt="" />
Foto: Ik heb mijn main aangepast waardoor alles nu goed er uit ziet als het scherm klein is.

### Een nieuw idee voor mijn privacymelding

Gisteren heb ik met mijn groepje besproken welke feedback iedereen had gekregen. Een groepsgenoot vertelde dat hij het koekje bij zijn privacymelding moest aanpassen, omdat de melding niet een echt cookie is die je kan weigeren of accepteren. Hoewel ik deze feedback zelf niet had gekregen, zette het mij wel aan het denken over mijn eigen ontwerp.

Ik begreep het punt: een koekje kan verwachtingen oproepen die niet aansluiten op de informatie in mijn privacymelding. Daarom ben ik gaan onderzoeken hoe ik dit onderdeel anders kan vormgeven, passend bij mijn haakwereld.

Als eerste heb ik in Canva verschillende elementen verzameld en bekeken welke ik zou kunnen gebruiken. Hiermee wil ik een nieuw ontwerp maken dat aansluit op mijn website en waarmee bezoekers de privacyinformatie kunnen openen.

<img src="./assets/images-readme/elementencookie.png" alt="" />
Foto: De elementen die ik inressant vond voor mijn cookie.

#### Nieuwe afbeeldingen voor mijn privacymelding

Als eerste heb ik twee afbeeldingen gemaakt voor de gesloten en geopende privacymelding. Ik heb ze vormgegeven in een stijl die bij mijn website past en daarna meteen de oude koekjesafbeeldingen vervangen. Ik vond het resultaat gelijk leuker en beter aansluiten op mijn haakwereld.

Bij het bekijken van de donkere modus merkte ik alleen dat het kruisje om de melding te sluiten nauwelijks zichtbaar was. Daarom heb ik een nieuwe variant gemaakt met een achtergrondvlakje achter het kruisje. Hierdoor is het kruisje in zowel de lichte als de donkere modus duidelijk te zien.

<img src="./assets/images-readme/nieuwecookies.png" alt="" />
Foto: De elementen die ik inressant vond voor mijn cookie.

#### De positie en grootte verder aanpassen

Daarna heb ik de positie en grootte van de afbeeldingen bij mijn privacymelding verder aangepast, zodat ze beter op de pagina passen.

Tijdens het bekijken merkte ik dat ik de nieuwste afbeelding, met het achtergrondvlakje achter het kruisje, nog niet had toegevoegd. Daarom heb ik meteen de oude versie vervangen. Zo staat nu ook de aangepaste afbeelding in mijn website.

<img src="./assets/images-readme/positiecookie.png" alt="" />
Foto: De positie en grote goed zetten voor de nieuwe plaatjes.

#### Een persoonlijk beeld op mijn informatiepagina

Ook heb ik een afbeelding van mijzelf toegevoegd aan mijn pagina met meer informatie. Hiermee wil ik de pagina persoonlijker maken en laten aansluiten op mijn haakwereld.

Daarna heb ik de plaatsing aangepast, zodat de afbeelding onderaan blijft staan wanneer je de uitklapbare menu’s opent of sluit. Ook op een klein scherm staat de afbeelding helemaal onderaan. Zo krijgt de informatie eerst de ruimte en sluit het beeld de pagina af.
haken
<img src="./assets/images-readme/plaatjejuus.png" alt="" />
Foto: nog en persoonlijke tast er bijgevoegd

### Een aparte beginpagina maken

Daarna heb ik een nieuwe beginpagina gemaakt om bezoekers welkom te heten in mijn haakwereld. Eerst heb ik hoofdpagina.html aangemaakt en de volledige inhoud van mijn bestaande index.html hiernaartoe gekopieerd. Vervolgens heb ik uit index.html de onderdelen verwijderd die ik niet op mijn beginpagina wilde hebben.

In index.html heb ik een korte introductie, een persoonlijke afbeelding en de knop Ontdek mijn haakwereld geplaatst. Via deze knop komen bezoekers op hoofdpagina.html, waar ze verder kunnen kijken naar mijn creaties.

Ik heb bewust de privacymelding op beide pagina’s laten staan. Zo kunnen bezoekers de informatie meteen bij binnenkomst openen en later op de hoofdpagina opnieuw terugvinden.

Tot slot heb ik op de andere pagina’s de Home- en teruglinks aangepast van index.htm`naar hoofdpagina.htm. Daarmee komen bezoekers bij het teruggaan direct bij de inhoud van mijn website. Ook heb ik de beginpagina op een klein scherm bekeken om de plaatsing van de tekst, knop en afbeelding te controleren.

<img src="./assets/images-readme/beginpagina.png" alt="" />
Foto: een begin pagina gemaakt om het echt meer persoonlijker te maken.

### Mijn website laten testen

Ik heb mijn website opnieuw laten bekijken door mensen uit mijn omgeving. Zij hebben de lichte en donkere modus getest en de mobiele versie in zowel portrait als landscape bekeken.

De reacties waren positief: beide modi waren prettig leesbaar en de teksten werden als vlot, duidelijk en persoonlijk ervaren. Ook de afbeeldingen nodigden uit om verder te kijken. Vooral mijn ‘over mij’-tekst en de hakende Judith met haar tattoo werden gewaardeerd, omdat die mijn website persoonlijker maken.

### Verbeterpunten verwerken

Tijdens het testen kwamen ook een paar aandachtspunten naar voren. Het privacymandje zat op mobiel soms over de tekst en bleef tijdens het lezen in beeld staan. Daarnaast stond het kruisje van de geopende melding in landscape buiten beeld en in portrait erg hoog. Bij sommige haakpagina’s was de eerste alinea te smal, mogelijk doordat de animatie op mobiel verborgen wordt.

Ik ben meteen met deze feedback aan de slag gegaan en heb verschillende punten aangepast. Het lukte mij alleen nog niet om de privacymelding verder naar beneden te plaatsen zoals ik wilde. Ondanks dat resterende punt kreeg ik terug dat de website al erg goed was. Deze test hielp mij om te ontdekken wat bezoekers prettig vinden en waar de mobiele weergave nog aandacht nodig heeft.

<img src="./assets/images-readme/feedback.png" alt="" />
Foto: De feedback die ik gekregen heb en hoe ik dit heb opgelost.

## Vrijdag 23 oktober

### Retrospectief: de onzichtbare last

Tijdens de les heb ik een retrospectief gemaakt over het hele blok. Een van de opdrachten was om mijn ervaring uit te beelden met een metafoor. Ik wilde laten zien dat ik graag meer aan school had willen doen, maar dat mijn privéomstandigheden veel invloed hadden op mijn concentratie en energie.

Daarom heb ik mijzelf getekend met een ballon waarop ‘studie’ staat. Die staat voor mijn motivatie en de richting waarin ik vooruit wil. Aan mijn been zit een ketting met een zware bol waarop ‘privé’ staat. Die verbeeldt wat mij tegenhoudt, ook wanneer ik zelf graag verder wil.

Ik heb mijn tekening ‘De onzichtbare last’ genoemd. Aan mijn schoolwerk is misschien te zien dat ik minder heb kunnen doen dan ik wilde, maar de reden daarachter is niet altijd zichtbaar. Met deze metafoor wil ik laten zien dat mijn motivatie er wel is, terwijl de ruimte om die om te zetten in werk niet altijd hetzelfde is.

<img src="./assets/images-readme/Metafoor3.jpg" alt="" />
Foto: De metafoor die ik heb gemaakt voor het hele blok.

### Feedback

### Feedback van Diederik en een derdejaarsstudent

Tijdens de les heb ik feedback gekregen van Diederik en een derdejaarsstudent. Eerst vroeg Diederik of ik de eerdere feedback had verwerkt. Ik kon uitleggen welke aanpassingen ik had gedaan, zoals het veranderen van het lettertype van mijn alinea’s. Ook heb ik toegelicht dat ik in mijn songtekst uitgebreider experimenteer met typografie. Mijn persoonlijke website wil ik rustig houden, terwijl ik met Y.M.C.A. juist wil laten zien wat ik met expressieve typografie kan.

Diederik was blij met de voortgang van mijn songtekst. Hij vertelde zelfs dat hij mijn werk woensdag als voorbeeld in de les had laten zien. Dat vond ik fijn om te horen. Wel adviseerde hij om te kijken of ik minimaal één refrein kan toevoegen en de grote witruimtes tussen de onderdelen kan verkleinen.

### Mijn code en schermformaten bekijken

Daarna heeft de derdejaarsstudent mijn code bekeken. Een van de opmerkingen ging over een link die ik binnen een `<p>` had geplaatst. Voor een losse link, zoals een knop, kan die extra alinea overbodig zijn. Een link binnen een alinea is op zichzelf wel toegestaan.

Ook bleek dat mijn website op schermen kleiner dan mijn eigen telefoon nog niet overal goed werkt. Tot nu toe had ik vooral op mijn eigen telefoon getest. Tijdens dit feedbackmoment heb ik geleerd hoe ik in de browser andere schermformaten kan bekijken. Daarmee kan ik gerichter controleren waar mijn indeling nog aanpassingen nodig heeft.

Daarnaast bleek een stukje code dat ik rechtstreeks uit een deepdive had overgenomen niet helemaal goed te staan. Dat vond ik ergens grappig, omdat het uit een lesvoorbeeld kwam. Tegelijkertijd liet het mij zien dat ik overgenomen code altijd binnen mijn eigen website moet controleren.

Met deze feedback heb ik weer concrete verbeterpunten om mijn website en songtekst verder af te werken.

## Voor de les van vrijdag 23 okt

### De alt-teksten aanvullen

Vroeg in de ochtend ben ik verdergegaan met de laatste verbeteringen aan mijn website. Ik heb alle afbeeldingen nagelopen, omdat ik gisteren bij sommige de alt-tekst was vergeten of een te korte beschrijving had toegevoegd.

Ik heb de ontbrekende alt-teksten aangevuld en bestaande beschrijvingen duidelijker gemaakt. Daarmee wil ik ervoor zorgen dat bezoekers die een screenreader gebruiken ook begrijpen wat de afbeeldingen laten zien en welke informatie ze toevoegen.

<img src="./assets/images-readme/alt.png" alt="" />
Foto: Alt"" toegevoegd aan mijn afbeeldingen.

### Het beeld bij ‘town’ aanpassen

Daarna heb ik opnieuw naar de afbeelding bij het woord ‘town’ in mijn songtekst gekeken. Ik vond de vorige versie toch niet helemaal passen bij wat ik wilde uitstralen. Daarom heb ik het beeld aangepast om het persoonlijker en levendiger te maken.

Hiermee wil ik de betekenis van het woord blijven uitbeelden en het plaatje beter laten aansluiten op de speelse sfeer van mijn songtekst.

<img src="./assets/images-readme/nieuwe-town.png" alt="" />
Foto: Miijn town plaatje vernieuwd.

### Y.M.C.A. op de achtergrond toevoegen

Ik wilde de letters Y.M.C.A. groot achter mijn songtekst plaatsen. Daarom heb ik eerst teruggekeken naar hoe ik mijn bestaande achtergrond had opgebouwd. Dit hielp mij om na te denken over de plaatsing, maar voor de letters heb ik een andere aanpak gebruikt.

Ik heb de letters achter de songtekst en vóór de discotegels geplaatst. Daarna heb ik met de grootte, positie en zichtbaarheid gespeeld. Zo wilde ik de achtergrond meer karakter geven, terwijl de songtekst op de voorgrond leesbaar blijft.

<img src="./assets/images-readme/groot-ymca.png" alt="" />
Foto: Y.M.C.A op de achtergond zetten

### De achtergrondletters schuin plaatsen

Daarna heb ik de grote Y.M.C.A.-letters verder vormgegeven. Met `transform: rotate(-15deg)` heb ik het achtergrondonderdeel schuin gezet. Hierdoor loopt de reeks letters schuin achter de songtekst langs en krijgt de compositie een speelser effect.

Met Grid heb ik de vier letters over vier rijen verdeeld. Het achtergrondonderdeel staat in hetzelfde gridvak als het eerste couplet, maar ligt met `z-index: -1` achter de inhoud. De letters schalen met het scherm mee door `clamp()`.

Ook heb ik de roze-paarse kleur duidelijker zichtbaar gemaakt, met een dekking van 34%. Tijdens het scrollen heb ik bekeken hoe de letters samengaan met de discotegels, tekst en afbeeldingen. Ik wilde dat ze opvallen, terwijl de songtekst de meeste aandacht blijft krijgen.

<img src="./assets/images-readme/ymca-shuin.png" alt="" />
Foto: De Y.M.C.A. schuin geplaats

## Donderdag 22 oktober

### Beertje

#### Teddy en zijn babydekentje uitwerken

Voor mijn laatste haakpatroon heb ik drie afbeeldingen en een gifje voorbereid, passend bij de stijl van mijn andere haakfiguurtjes. Daarna heb ik een introductiepagina gemaakt met informatie, tips en een knop naar het patroon.

Op de aparte patroonpagina heb ik de afkortingen en instructies verdeeld over tussenkopjes en lijsten, zodat bezoekers de stappen makkelijk kunnen volgen. Ook heb ik vermeld dat het beeldmateriaal met AI is gemaakt en het patroon nog niet is proefgehaakt.

Tot slot heb ik het lettertype van de `<h4>`-kopjes aangepast en de foto’s veranderd om de vormgeving beter op elkaar af te stemmen.

<img src="./assets/images-readme/beertje.png" alt="" />
Foto: Het verloop van de pagina over het beertje

<img src="./assets/images-readme/beertjeaf.png" alt="" />
Foto: De pagina over het beertje + het haak patroon af.

### Menu aanpassen

#### Mijn ‘over mij’- en haakpatronenpagina opbouwen

Daarna ben ik begonnen aan mijn ‘over mij’-pagina en de overzichtspagina met haakpatronen. Tijdens het werken wisselde ik steeds tussen deze pagina’s. Daardoor lopen de screenshots wat door elkaar.

Op de haakpatronenpagina heb ik een introductie en korte beschrijvingen van de haakfiguurtjes toegevoegd. Hiermee wil ik bezoekers helpen een patroon te kiezen. Ook heb ik de navigatie overzichtelijker gemaakt met de links Home, Haakpatronen en Contact.

Op mijn ‘over mij’-pagina vertel ik wie ik ben, wat ik studeer en hoe mijn liefde voor haken en ontwerpen samenkomt op deze website. Daarnaast heb ik een persoonlijk sfeerbeeld toegevoegd en vermeld dat dit met AI is bewerkt. Met een link naar de haakpatronen kunnen bezoekers vanuit mijn verhaal verder naar mijn creaties.

Bij beide pagina’s heb ik de bestaande kleuren en lettertypes aangehouden en tussendoor in de browser bekeken hoe de inhoud overkomt.

<img src="./assets/images-readme/navigatie.png" alt="" />
Foto: Ik heb mijn navigatue aangepast.

#### Een persoonlijke afbeelding voor beide modes

Daarna heb ik een afbeelding van mijzelf gemaakt met een gehaakt lijstje eromheen. Dit past bij het onderwerp van mijn website en maakt mijn ‘over mij’-pagina persoonlijker.

Ik heb twee versies gemaakt: één voor de lichte modus en één voor de donkere modus. In de donkere versie geeft de lamp naast het lijstje licht. Zo wilde ik een speels detail toevoegen dat aansluit op de gekozen modus.

Vervolgens heb ik beide afbeeldingen in mijn HTML gezet en met CSS bepaald welke zichtbaar is. Standaard verschijnt de lichte versie. Zodra de bezoeker de donkere modus kiest, wordt deze verborgen en verschijnt de versie met de brandende lamp. Hiervoor heb ik :has() en :checked gebruikt om op de geselecteerde themakeuze te reageren.

<img src="./assets/images-readme/juud-licht-donker.png" alt="" />
Foto: Hoe ik mijn 2 foto's heb toegevoegd.

### De haakpatronenpagina afronden

Daarna heb ik de overzichtspagina met mijn haakpatronen afgemaakt. Hier kunnen bezoekers de verschillende figuurtjes bekijken en kiezen over welk haakproject ze meer willen lezen.

Vervolgens wilde ik onderzoeken of ik de afbeeldingen op deze pagina ook kan laten wisselen tussen de lichte en donkere modus, zoals bij mijn ‘over mij’-pagina. Hiervoor heb ik van ieder haakfiguurtje twee versies voorbereid, met een gehaakte omlijsting en een lampje. In de lichte versie staat het lampje uit en in de donkere versie brandt het.

Mijn volgende stap is om deze afbeeldingen aan de themakeuze te koppelen. Daarmee wil ik de pagina meer samenhang geven en het wisselen van modus een speels detail meegeven.

<img src="./assets/images-readme/haakpatr.png" alt="" />
Foto: Ik heb de basis voor de pagina over de haak patronen af gemaakt.

<img src="./assets/images-readme/licht:donker-dietjes.png" alt="" />
Foto: De foto's van de diertjes met en zonder licht.

### Algemene code voor de afbeeldingen

Ik heb de CSS die alleen voor mijn persoonlijke foto werkte vervangen door algemene regels. De code kijkt nu of de bestandsnaam van een afbeelding `-lmode` of `-dmode` bevat. Hierdoor kan ik dezelfde regels gebruiken voor mijn eigen foto én de afbeeldingen van mijn haakfiguurtjes.

Standaard worden de lichte afbeeldingen getoond. Wanneer de bezoeker de donkere modus kiest, worden deze verborgen en verschijnen de donkere versies met brandende lampjes.

Ik heb beide modi in de browser bekeken om het resultaat te vergelijken. Zo hoef ik niet voor iedere afbeelding aparte CSS te schrijven en reageren de afbeeldingen op dezelfde manier op de themakeuze.

<img src="./assets/images-readme/licht:donkerdieren.png" alt="" />
Foto: De foto's van de diertjes met en zonder licht die in de pagina van het haken staan.

## woensdag 21 oktober

Vanwege mijn prive situatie redden ik het niet om naar school te komen maar ik heb wel gekeken hoe ik zo veel mogelijk kan doen.

### Voorbereiding voor de les

#### Twee artikelen lezen

Voor de les moest ik twee artikelen lezen. Eén daarvan heb ik niet kunnen lezen, omdat ik cookies moest accepteren om toegang te krijgen. Dat wilde ik niet, waardoor ik dat artikel niet verder heb kunnen bekijken.
Het andere artikel ging over The Dead Internet Theory. Volgens deze theorie wordt het internet steeds meer gevuld met bots en AI-content, waardoor echte menselijke interactie minder zichtbaar wordt. Het artikel bespreekt deze zorgen, maar de theorie is geen bewezen beschrijving van het hele internet.

#### Wat ik uit het artikel heb gehaald

Bots kunnen nuttige taken uitvoeren, maar ook spam en nepreacties verspreiden. Door AI is het bovendien makkelijker geworden om grote hoeveelheden teksten en afbeeldingen te maken. Automatische likes en reacties kunnen vervolgens de indruk geven dat deze inhoud populair of betrouwbaar is.
Wat mij vooral opviel, is dat platforms verdienen aan onze aandacht. Daardoor krijgen klikken, likes en kijktijd soms meer aandacht dan de kwaliteit van de inhoud. Dit kan het moeilijker maken om betrouwbare informatie te herkennen en betekenisvol contact te vinden.

Voor mij is de belangrijkste les dat ik kritisch moet blijven kijken naar wat ik online tegenkom. Wie heeft iets gemaakt, met welk doel en is het duidelijk of AI is gebruikt? Het artikel liet mij nadenken over de vraag of het internet vooral draait om menselijke verbinding, of steeds meer om automatische inhoud en geld verdienen.

### Meer discosfeer met een achtergrond

Daarna heb ik onderzocht hoe ik de achtergrond kon gebruiken om mijn songtekst meer discosfeer te geven. Hiervoor heb ik een afbeelding van een kleurrijke discovloer gemaakt. De verlichte tegels passen bij het feestelijke gevoel dat ik met mijn Y.M.C.A.-ontwerp wil overbrengen.

Vervolgens heb ik de zwarte delen van de afbeelding transparant gemaakt. Hierdoor blijven de gekleurde tegels zichtbaar en kan de achtergrondkleur van mijn pagina ertussendoor komen. Zo sluit de afbeelding beter aan op de rest van mijn ontwerp.

Ik heb deze versie als achtergrond toegevoegd aan mijn songtekstpagina. Hiermee wilde ik de verschillende onderdelen meer met elkaar verbinden en ook tussen de teksten en animaties het discogevoel laten terugkomen. Daarbij wil ik blijven letten op de leesbaarheid, zodat de achtergrond de songtekst ondersteunt.

<img src="./assets/images-readme/zwart:wit.png" alt="" />
Foto: Mijn eerste ontwerpen voor de dansvloer.

#### De discovloer meer tot leven brengen

Ik had het gevoel dat er nog iets miste aan de achtergrond. Daarom heb ik de basis van de discovloer op 15% dekking gehouden en verschillende tegels een dekking tussen de 20% en 50% gegeven.

Hierdoor vallen sommige tegels meer op dan andere en krijgt de vloer meer afwisseling. Zo probeer ik het effect van een verlichte dansvloer sterker over te brengen, terwijl de achtergrond licht genoeg blijft om de songtekst goed te kunnen lezen.

<img src="./assets/images-readme/discovloer.png" alt="" />
Foto: van de dansvloer met verschillende tegels

#### Meer samenhang in het eerste couplet

Daarna heb ik verschillende kleine aanpassingen gedaan om het eerste couplet meer één geheel te maken. Ik heb de vormgeving van de eerste ‘Young man’ beter laten aansluiten op de tweede en derde. Door deze herhaling ontstaat er meer samenhang tussen de momenten waarop je als bezoeker wordt aangesproken.

Ook heb ik de kleur van ‘down’ veranderd naar roze, zodat deze beter aansluit op de rest van mijn ontwerp. Bij zowel ‘down’ als ‘unhappy’ heb ik daarnaast de instellingen van het variabele lettertype aangepast. Hiermee heb ik verder gespeeld met de lettervormen en de uitstraling van deze woorden.

#### Het couplet afsluiten

Om het eerste couplet visueel af te sluiten, heb ik een gifje gemaakt en toegevoegd. Hiermee wilde ik het dansgevoel nog even terug laten komen voordat de bezoeker verdergaat naar het volgende couplet.

Als laatste heb ik de achtergrondkleur weggehaald. Met deze aanpassingen heb ik geprobeerd de typografie, kleuren, achtergrond en beweging beter op elkaar af te stemmen.

<img src="./assets/images-readme/ideegif.png" alt="" />
Foto: De eerste opzet voor het gifje

<img src="./assets/images-readme/disco.png" alt="" />
Foto: Alle aanpassingen.

### Mijn prioriteiten aanpassen

Vanwege de tijdsdruk heb ik besloten om mijn songtekstpagina voorlopig te beperken tot het eerste couplet. Ik heb de overige coupletten en refreinen weggehaald, zodat de pagina zich richt op het gedeelte dat ik al heb uitgewerkt.

Ik ga nu eerst verder met mijn persoonlijke website. Daar wil ik bekijken welke onderdelen nog ontbreken en wat ik kan aanvullen of verbeteren. Mijn checklist helpt mij om overzicht te houden en te bepalen wat als eerste aandacht nodig heeft.

Als ik daarna nog tijd over heb, wil ik verderwerken aan de songtekst. Voor nu kies ik ervoor om mijn aandacht te richten op het afronden en verbeteren van mijn website.

<img src="./assets/images-readme/alleen1.png" alt="" />
Foto: voor nu alleen couplet 1.

#### De haakpatronen verder uitwerken

Als eerste wil ik kijken of ik voor alle haakpatronen op mijn website een eigen pagina kan maken. Op deze pagina’s wil ik ook het volledige haakpatroon plaatsen, zodat bezoekers het zelf kunnen volgen en het figuurtje kunnen namaken.

Ik wil daarbij letten op een duidelijke opbouw met de benodigde materialen, gebruikte afkortingen en de stappen van het patroon. Zo wil ik mijn website verder aanvullen en de patronen overzichtelijk en bruikbaar maken voor bezoekers.

### Misty de poes

#### De pagina’s voor Misty maken

Daarna ben ik begonnen met de pagina’s voor Misty. Ik heb eerst een introductiepagina over Misty gemaakt en vervolgens een aparte pagina met het haakpatroon. Hiervoor heb ik dezelfde opbouw gebruikt als bij de andere patronen, zodat de pagina’s bij elkaar passen en bezoekers de indeling herkennen.

Tijdens het maken ben ik helaas vergeten om tussendoor screenshots te nemen. Daardoor kan ik de tussenstappen niet laten zien. De werkwijze was wel hetzelfde als bij mijn eerdere pagina’s: de bestaande structuur als basis gebruiken en de inhoud aanpassen aan Misty.

#### Een snelle toegang toevoegen

Bovenaan heb ik ook een knop toegevoegd als snelkoppeling, zodat bezoekers sneller bij het patroon kunnen komen. Voor nu heb ik eerst de functie toegevoegd. Later wil ik de navigatie veranderen omdat het te veel wordt.

<img src="./assets/images-readme/poesmisty.png" alt="" />
Foto: De pagina's over Misty

### Bert de krab

#### Beeldmateriaal voor Rachele de krab

Als eerste heb ik afbeeldingen en een gifje gemaakt die ik wil gebruiken op mijn pagina over Rachele de krab. Hiermee bereid ik het beeldmateriaal voor voordat ik de pagina zelf verder opbouw.

Ik wil de afbeeldingen gebruiken om Rachele te laten zien en de pagina visueel aan te laten sluiten op mijn andere haakpatronen. Met het gifje wil ik ook wat beweging en een speels karakter toevoegen. De volgende stap is om dit beeldmateriaal een plek te geven op de introductiepagina en de pagina met het haakpatroon.

<img src="./assets/images-readme/Rachelle.png" alt="" />
Foto: De foto's voor Rachelle de krab

#### De naam veranderen naar Bert de krab

Toen ik mijn vriend liet zien wat ik tot nu toe had gemaakt, vond hij de naam ‘Rachele’ niet zo goed bij het krabbetje passen. Hij stelde voor om hem Bert de krab te noemen.

Ik vond dit zelf ook een leuke naam en heb besloten zijn suggestie over te nemen. Daarom ga ik de naam aanpassen.

#### De achtergrond van het gif aanpassen

Ik kwam erachter dat mijn gifje nog een achtergrond had. Daarom heb ik deze transparant gemaakt, zodat Bert beter aansluit op de achtergrond van mijn website.

<img src="./assets/images-readme/rachelle:bert.png" alt="" />
Foto: Begin van de pagina

#### De introductiepagina van Bert opbouwen

Daarna ben ik verdergegaan met de introductiepagina van Bert de krab. Ik heb dezelfde opbouw en vormgeving gebruikt als bij mijn andere haakfiguurtjes, zodat de pagina aansluit op de rest van mijn website.

Bovenaan heb ik Bert toegevoegd aan de navigatie en het gifje naast de introductietekst geplaatst. In de tekst vertel ik hoe Bert eruitziet en hoe het krabbetje wordt opgebouwd tijdens het haken.

#### Informatie voor de bezoeker toevoegen

Vervolgens heb ik de pagina aangevuld met aparte onderdelen voor ‘Over Bert’, projectinformatie, benodigdheden, technieken, handige tips en veiligheid. Met tussenkopjes en opsommingen heb ik geprobeerd de informatie overzichtelijk te verdelen. Zo kan een bezoeker vooraf bekijken wat nodig is en wat het project inhoudt.

<img src="./assets/images-readme/startbert.png" alt="" />
Foto: Het begin van de pagina voor Bert.

#### De introductiepagina van Bert afronden

De pagina over Bert de krab is nu af. Hier kunnen bezoekers kennismaken met Bert en informatie vinden over het project en de benodigdheden.

Ik ga nu beginnen aan de aparte pagina met zijn haakpatroon. Hiervoor gebruik ik dezelfde opbouw als bij mijn andere patroonpagina’s, zodat de website één geheel blijft.

<img src="./assets/images-readme/infobert.png" alt="" />
Foto: informatie pagina over Bert af.

### Het haakpatroon van Bert uitwerken

Na de introductiepagina heb ik de aparte pagina met het haakpatroon van Bert de krab opgebouwd. Ik ben begonnen met een korte introductie en een overzicht van de gebruikte afkortingen. Zo kunnen bezoekers vooraf opzoeken wat de termen in het patroon betekenen.

Daarna heb ik de instructies per onderdeel toegevoegd, zoals het lijf, de oogkassen, scharen en poten. In de HTML heb ik deze onderdelen verdeeld over aparte article elementen met tussenkopjes. De haakrondes staan ieder in een eigen alinea, zodat de stappen tijdens het haken makkelijk terug te vinden zijn.

### De pagina afronden

Aan het einde heb ik uitleg toegevoegd over het in elkaar zetten van Bert en het afwerken van de losse draden. Ook heb ik een knop geplaatst waarmee bezoekers terug kunnen naar de introductiepagina.

Tijdens het uitwerken heb ik de pagina steeds in de browser bekeken, hier in de donkere modus. Daarnaast heb ik met de zoekfunctie gecontroleerd of de oude naam nog in mijn code stond. Met deze pagina staat naast de kennismaking met Bert nu ook het patroon op mijn website.

<img src="./assets/images-readme/patroonkrab.png" alt="" />
Foto: De pagina over het patroon van de krab af.

#### Lange tekstblokken opsplitsen

Toen de patroonpagina van Bert af was, merkte ik dat sommige tekstblokken erg lang waren. Daarom heb ik de langere artikelen opgesplitst in twee aparte article elementen.

Hierdoor wordt de informatie in kleinere stukken aangeboden en ontstaat er meer overzicht op de pagina. Zo kunnen bezoekers tijdens het haken makkelijker hun plek terugvinden en de stappen volgen.

<img src="./assets/images-readme/opsplitsing.png" alt="" />
Foto: Voor en na, na het opsplitsen van de artikelen.

### Het lettertype en de leesbaarheid verbeteren

Ik heb nu ook het lettertype van mijn alinea’s (p) aangepast. Dit wilde ik al langer doen en heb ik nu meegenomen in het verbeteren van mijn website.

Daarnaast heb ik meer witruimte tussen de tekstregels gemaakt, zodat de tekst minder dicht op elkaar staat. Hiermee wil ik de pagina’s rustiger en prettiger leesbaar maken, vooral bij de langere uitleg en haakpatronen.

Ik had de verschillende varianten geprobeerd alleen daarvan ben ik vergeten foto's van te maken.

<img src="./assets/images-readme/p.png" alt="" />
Foto: Ik heb van 1 font meerdere varianten gedownload

We hadden deze dag geen check-out

## Dinsdag 20 oktober

### Hulp van een collega bij mijn code

Dinsdag moest ik werken en had ik voortgangsgesprekken met enkele medewerkers. Tijdens deze gesprekken vraag ik altijd hoe het gaat met school of studie en hoe het thuis gaat. Een medewerker met wie ik het goed kan vinden, vraagt dit ook altijd aan mij.

Omdat ik wist dat hij een opleiding in de richting van programmeren had gevolgd, vertelde ik over mijn huidige schoolopdrachten. Ik legde uit dat ik mijn eigen website maak en daarnaast bezig ben met een typografische uitwerking van een songtekst. Na zijn voortgangsgesprek wilde hij graag even meekijken naar mijn code.

Hij vond het opvallend dat ik voor de opdracht geen classes mocht gebruiken. Tegelijkertijd vond hij het ook wel interessant dat deze beperking mij dwingt om op een andere manier met mijn HTML en CSS te werken.

#### De gekozen modus onthouden

Hij vroeg of ik ergens tegenaan liep waarbij hij kon helpen. Ik vertelde dat ik graag wilde dat mijn website onthoudt of een bezoeker voor de lichte of donkere modus heeft gekozen. Die keuze moest ook behouden blijven wanneer iemand naar een andere pagina gaat, zodat de bezoeker dit niet steeds opnieuw hoeft in te stellen.

Hij heeft mij geholpen om dit met JavaScript uit te werken en in mijn website te verwerken. Dit was een verbetering die ik al langer wilde toevoegen, dus ik was blij dat ik hier samen met hem naar kon kijken.

<img src="./assets/images-readme/hulpjava.png" alt="" />
Foto: De code die ik samen met zijn hulp in mijn javascript heb gezet.

#### ‘Unhappy’ laten veranderen tijdens het scrollen

Daarna hebben we mijn songtekst bekeken, omdat hij nieuwsgierig was naar wat ik daarmee aan het maken was. Ik vertelde over mijn idee om het woord ‘unhappy’ tijdens het scrollen te laten veranderen in de vorm van een verdrietig mondje.

Ik vroeg of dit mogelijk was en hoe ik dat kon aanpakken. Hij heeft mij uitgelegd hoe ik dit effect kon opbouwen en geholpen om het in mijn code te zetten. Hierdoor kon ik verder met een idee waarvan ik zelf nog niet goed wist hoe ik het moest uitvoeren.

<img src="./assets/images-readme/unhappy.png" alt="" />
Foto: hoe ik de unhappy naar een zielig gezichtje kan zetten.

#### Terugkijken op de hulp

Daarna moest ik weer verder met de gesprekken, maar ik was heel blij met zijn hulp. Het was fijn om mijn ideeën te kunnen bespreken met iemand die ervaring heeft met programmeren en samen naar mijn code te kijken. Zijn uitleg hielp mij om verder te komen met zowel mijn persoonlijke website als mijn songtekst. Deze onderdelen heb ik dus met zijn begeleiding uitgewerkt.

### voorbereiding voor woensdag 21 oktober.

## Maandag 19 oktober

### Een rustigere werkplek zoeken

Vandaag heb ik mijn best gedaan om in de les te blijven en mee te doen. Toch merkte ik dat ik de uitleg niet goed opnam en er met mijn gedachten niet bij was. Ik raakte snel geïrriteerd door alles om mij heen. Met drie klassen in één lokaal waren er op dat moment te veel prikkels om mij goed te kunnen concentreren.

Daarom heb ik besloten om weg te gaan en op een andere plek verder te werken. Ik ben in een restaurant gaan zitten met mijn oortjes in, zodat ik mij wat meer kon afzonderen. Ik hoopte daar meer rust te vinden en mijn aandacht beter op mijn schoolwerk te kunnen richten.

Thuis werken voelde voor mij ook niet als een goede oplossing, omdat mijn gedachten daar steeds naar de thuissituatie gaan. Door een andere werkplek te zoeken, heb ik geprobeerd rekening te houden met wat ik op dat moment nodig had om toch verder te kunnen werken.

### Mijn website zelf beoordelen

Toen ik merkte dat het in de les niet meer ging en ik op een andere plek ben gaan werken, heb ik het werkblad zelf ingevuld voor mijn website. Dit hielp mij om gericht naar mijn ontwerp te kijken en stil te staan bij wat al goed werkt en wat nog aandacht nodig heeft.

Vanuit deze beoordeling heb ik een checklist voor mezelf gemaakt met de punten die mij opvielen. Zo heb ik een overzicht van wat ik nog wil controleren en aanpassen, en kan ik deze punten stap voor stap afwerken.

### Het testmoment alsnog organiseren

Ik besef dat ik door mijn vertrek het testmoment met een klasgenoot heb gemist. Mijn eigen beoordeling geeft mij aanknopingspunten, maar ik wil ook ontdekken hoe iemand anders mijn website ervaart.

Daarom ga ik mensen uit mijn omgeving vragen om mijn website te testen en het werkblad in te vullen. Zo kan ik onderzoeken of de website ook begrijpelijk is voor mensen die de opdracht niet kennen en ontdekken welke verbeterpunten zij tegenkomen.

<img src="./assets/images-readme/werkblad.jpg" alt="" />
Foto: Mijn ingevulde werkblad

### Verder met mijn songtekst: meer ruimte onder het gif

Ik ben weer verdergegaan met het uitwerken van mijn songtekst. Tijdens het bekijken van mijn pagina merkte ik dat de volgende zin te dicht op het gif stond, waardoor de tekst door de afbeelding heen liep. Daarom heb ik de ruimte onder het gif aangepast en tussendoor in de browser gekeken hoe dit eruitzag. Hiermee wilde ik zorgen dat de animatie en de tekst elkaar niet overlappen en de songtekst goed leesbaar blijft.

Ik wil nu eerst verderwerken aan de rest van de songtekst, zodat ik een complete versie heb. Daarna ga ik het geheel opnieuw bekijken en bepalen wat ik nog kan aanvullen of aanpassen om het ontwerp verder te verbeteren.

<img src="./assets/images-readme/ruimtegif.png" alt="" />
Foto: Ik heb meer ruimte gecreert tussen het gifje en de songteskt.

### ‘Town’ uitbeelden met een dorpssilhouet

Hierna ben ik verdergegaan met de zin ‘’cause you’re in a new town’. Ik wilde het woord ‘town’ visueel uitbeelden. Daarom heb ik een afbeelding van een dorpssilhouet toegevoegd, waarin het woord zelf is verwerkt. Zo vormen de huisjes, bomen en kerk samen met de letters één geheel.

Ik heb de afbeelding in de HTML op de plek van het woord ‘town’ gezet en een alt-tekst toegevoegd. De rest van de zin staat erboven, zodat de afbeelding aansluit op wat je leest.

Vervolgens heb ik een animatie gemaakt met de naam dorp-verschijnt. Aan het begin is het dorp doorzichtig, kleiner en iets naar beneden verplaatst. Tijdens de animatie wordt het zichtbaar, schuift het omhoog en groeit het naar zijn volledige grootte. Hiermee wilde ik het dorp laten verschijnen alsof je op een nieuwe plek aankomt.

<img src="./assets/images-readme/town.png" alt="" />
Foto: ik heb in canva eerst 2 verschillende afbeeldingen gemaakt en daarna de best in mijn html gezet.

We hadden deze dag geen Check-out.

## Zaterdag 17 oktober

### Het gif toevoegen aan mijn songtekst

#### De animatie op de pagina plaatsen

De volgende dag ben ik verdergegaan met het plaatsen van mijn gif in het eerste couplet. Onder ‘I said’ en de bewegende ‘YOUNG MAN’ heb ik de animatie van het opstaande poppetje gezet. De zin ‘pick yourself off the ground’ staat onder de animatie, zodat beeld en tekst elkaar ondersteunen.

### De grootte en ruimte aanpassen

Ik heb het gif met 'display: block' en automatische zijmarges in het midden geplaatst. Eerst probeerde ik een breedte van '12em', maar daarna heb ik deze vergroot naar '16em'. Hierdoor werden het poppetje, de achtergrond en de tekst duidelijker zichtbaar.

Er zat eerst nog veel witruimte tussen ‘YOUNG MAN’, het gif en de volgende regels. Daarom heb ik verschillende marges uitgeprobeerd, waaronder negatieve marges om de onderdelen dichter naar elkaar toe te brengen. Na iedere aanpassing heb ik in de browser bekeken hoe het geheel eruitzag.

Op deze manier heb ik stap voor stap gezocht naar een passende grootte en plaatsing. Het gif krijgt nu een duidelijke plek binnen het couplet, waarna de rest van de songtekst eronder verdergaat.

<img src="./assets/images-readme/gifjegeplaats.png" alt="" />
Foto: Hoe ik het gijfje in de songtekdt heb geplaats.

## Vrijdag 16 oktober

Door gesprekken in mijn thuissituatie heb ik helaas niet veel aan school kunnen doen.

### ‘Pick yourself off the ground’ uitwerken als gif

#### Van idee naar beweging

Na de feedback op mijn schetsen ben ik gaan onderzoeken hoe ik mijn idee kon uitwerken in een gif. In mijn eerste poging werd het poppetje toch weer door iemand anders geholpen. Daarmee maakte ik opnieuw dezelfde vergissing: de zin gaat juist over jezelf overeind helpen. Ik merk dat ik de laatste tijd door mijn privésituatie minder goed met mijn hoofd bij school ben, waardoor ik dit soort dingen sneller over het hoofd zie.

Ik wilde het idee wel behouden. Daarom heb ik de beweging aangepast, zodat het poppetje zelfstandig van de grond opstaat. Zo kon ik verderwerken vanuit mijn bestaande idee en de handeling beter laten aansluiten op de betekenis van de songtekst.

### Een achtergrond toevoegen

Vervolgens heb ik gekeken hoe ik met een achtergrond duidelijker kon maken dat het poppetje op de grond ligt. Ik wilde de beweging meer context geven, zodat het opstaan beter te herkennen is. Hiervoor heb ik verschillende versies uitgeprobeerd en gekeken hoe de achtergrond en het poppetje samen overkomen.

### De begrijpelijkheid testen

Daarna heb ik mensen uit mijn omgeving gevraagd of zij begrepen wat ik wilde uitbeelden. In combinatie met de songtekst vonden zij de betekenis duidelijk. Dat gaf mij meer vertrouwen in de uitwerking, al was ik er zelf nog niet helemaal van overtuigd dat het beeld zonder uitleg duidelijk genoeg was.

Daarom heb ik ervoor gekozen om ‘pick yourself off the ground’ onder de animatie te zetten. Vanuit de eerdere feedback wilde ik eerst onderzoeken of alleen beeld voldoende zou zijn. Na het uitwerken heb ik toch gekozen voor een combinatie van beeld en tekst, zodat de bezoeker de beweging direct aan de juiste zin kan koppelen.

<img src="./assets/images-readme/beginvormgeving.png" alt="" />
Foto: Mijn eerste opzetjes voor het

<img src="./assets/images-readme/gifje.png" alt="" />
Foto: Hoe het gifje er uiteindelijk is geworden.

## Donderdag 15 oktober

### Meer ruimte en beweging in het eerste couplet

#### ‘YOUNG MAN’ als opener in het midden

Ik ben verder aan het experimenteren met de indeling van het eerste couplet. Hiervoor heb ik ‘YOUNG MAN’ uit de doorlopende tekst gehaald en op een eigen regel in het midden geplaatst. Zo wordt het meer een opener die je aandacht trekt voordat je de rest van de zin leest.

Met display: block, centrering en extra witruimte boven en onder de woorden heb ik deze plek gemaakt. Ook heb ik het vertrekpunt van de schaalanimatie naar het midden verplaatst, zodat de woorden vanuit hun nieuwe positie groter worden.

De animatie heeft nu een cyclus van 25 seconden. De woorden verschijnen, worden groter en blijven een tijd duidelijk zichtbaar voordat ze weer verdwijnen. Hierdoor ontstaat meer rust tussen de herhalingen. Daarnaast heb ik een hover toegevoegd waarmee ‘YOUNG MAN’ lichtblauw wordt wanneer je er met de muis overheen gaat.

#### ‘Down’ letterlijk naar beneden laten vallen

Daarna ben ik begonnen met het woord ‘down’. Ik wil de betekenis hiervan zichtbaar maken door het woord naar beneden te laten vallen en te laten verdwijnen.

Ik heb ‘down’ daarom ook op een eigen regel gezet, groter gemaakt en in het midden geplaatst. Met extra witruimte eronder maak ik ruimte voor de beweging. In de animatie combineer ik translateY() met opacity: het woord verschijnt eerst, blijft even staan en zakt vervolgens naar beneden terwijl het vervaagt. Daarna begint de animatie opnieuw. Deze cyclus duurt vijf seconden.

#### De compositie verder onderzoeken

Tot slot heb ik ook de overige tekst van het eerste couplet gecentreerd. Hierdoor sluit deze beter aan bij de losse woorden in het midden. Ik probeer hiermee de tekst minder als één vast tekstblok te presenteren en meer met plaatsing, witruimte en nadruk te spelen.

Dit is nog in ontwikkeling. Ik ben aan het bekijken hoeveel ruimte de onderdelen nodig hebben en hoe de animaties samenwerken. Mijn doel is dat de vormgeving de betekenis en nadruk van de woorden ondersteunt, terwijl de volgorde van de songtekst duidelijk blijft.

<img src="./assets/images-readme/15okt.png" alt="" />
Foto: het begin van mijn eerste couplet.

### ‘Down’ laten wegzakken tijdens het scrollen

#### Van automatisch vallen naar reageren op scrollen

Daarna heb ik de animatie van ‘down’ verder aangepast. Eerst viel het woord automatisch naar beneden en begon de beweging steeds opnieuw. Ik wilde onderzoeken hoe het zou werken als het woord pas wegzakt wanneer je verder scrolt. Zo heeft de bezoeker zelf invloed op de beweging.

#### Beweging, kleur en transparantie combineren

Ik heb ‘down’ rood gemaakt, zodat het extra opvalt tussen de zwarte tekst. Aan het begin blijft het woord even op zijn plek staan. Wanneer je verder scrolt, verplaatst het zich naar beneden en wordt het uiteindelijk transparant.

Ik heb verschillende scrollposities bekeken om te vergelijken hoe het woord zichtbaar blijft en vervolgens verdwijnt. Hiermee probeer ik de betekenis van ‘down’ letterlijk in de beweging terug te laten komen.

#### Een extra reactie bij hover

Vervolgens heb ik een korte hoveranimatie toegevoegd. Wanneer je met de muis over ‘down’ gaat, maakt het woord een kleine verende beweging: eerst iets naar beneden, daarna een stukje omhoog en weer terug.

### De tweede ‘Young man’ uitwerken

#### Het gevoel van roepen uitbeelden

Na mijn experiment met ‘down’ ben ik verdergegaan met de tweede ‘Young man’ in het eerste couplet. Omdat hiervoor ‘I said’ staat, wilde ik de woorden laten overkomen alsof iemand je echt roept.

Ik heb hiervoor een animatie met de naam roepen gemaakt. Daarin combineer ik groter en kleiner worden met een kleine draaiing naar links en rechts. Tijdens een deel van de beweging krijgt de tekst ook een rode kleur. De animatie duurt vijf seconden en blijft zich herhalen.

#### Verschillende versies vergelijken

Ik heb verschillende groottes en plaatsingen geprobeerd. Ook heb ik tekens rondom ‘Young man’ gezet om het roepen extra te benadrukken. Daarna heb ik weer een versie zonder deze tekens bekeken.

Tijdens het uitproberen overlapten de woorden soms met ‘I said’. Daarom heb ik de indeling aangepast en met regelovergangen ‘I said’, ‘Young man’ en de volgende zin onder elkaar geplaatst. Hierdoor kreeg de bewegende tekst meer ruimte en werd ‘Young man’ een duidelijk afzonderlijk onderdeel.

<img src="./assets/images-readme/15okt2.png" alt="" />
Foto: het begin van mijn eerste couplet.

### Ideeën voor ‘Pick yourself off the ground’ onderzoeken

#### Schetsen

Voor de zin ‘pick yourself off the ground’ heb ik verschillende ideeën bedacht en geschetst. Ik wilde onderzoeken hoe ik de betekenis van deze woorden visueel kon uitbeelden en hoe ik daarbij met typografie en beweging kon spelen.

Ik heb nagedacht over hoe ik het opstaan van de grond kon vertalen naar mijn ontwerp. Moest de tekst zelf bewegen, of kon ik de woorden combineren met een beeld dat de handeling laat zien? Door verschillende mogelijkheden op papier te zetten, kon ik deze eerst vergelijken voordat ik ze in code ging uitwerken.

Met deze schetsen wilde ik ontdekken welke uitwerking het beste bij de zin én bij de speelse sfeer van mijn Y.M.C.A.-pagina past. Ze vormen een vertrekpunt om verder te experimenteren met de plaatsing en beweging van de woorden..

<img src="./assets/images-readme/schets-ground.png.jpeg" alt="" />

#### Feedback vragen op mijn schetsen

Toen ik feedback wilde vragen op mijn schetsen voor ‘pick yourself off the ground’, ontdekte ik dat ik iets over het hoofd had gezien. In bijna al mijn ideeën werd het poppetje door iemand anders geholpen, terwijl de zin juist gaat over jezelf overeind helpen. Daardoor sloten mijn schetsen inhoudelijk nog niet helemaal aan op de songtekst.

Dat vond ik frustrerend. Door mijn privésituatie merk ik dat ik mijn aandacht op dit moment minder goed bij school kan houden. Dit was voor mij een moment waarop dat duidelijk naar voren kwam. Toch wilde ik onderzoeken welke onderdelen van mijn ideeën ik nog kon gebruiken.

#### De manier van uitbeelden vergelijken

Ik heb daarom mijn feedbackvraag aangepast. In plaats van te vragen of de schetsen de zin goed uitbeelden, heb ik gevraagd welke manier van weergeven het meest aanspreekt. Bijvoorbeeld: het woord ‘ground’ laten veranderen in een poppetje, een poppetje rondom de woorden laten bewegen of de hele handeling zonder tekst uitbeelden.

Hiervoor heb ik mensen uit mijn omgeving gevraagd die zelf ook creatief bezig zijn. Ik verwachtte dat zij goed konden meedenken over de visuele mogelijkheden, ook als de inhoud van de schets nog aangepast moest worden.

#### Wat ik met de feedback ga doen

Uit de reacties kwam naar voren dat het volledig uitbeelden van de handeling, zonder tekst, het leukste werd gevonden. Als ik het poppetje zo aanpas dat het zelfstandig opstaat, vonden de testers dat de betekenis voldoende voor zichzelf zou spreken.
Deze feedback geeft mij een richting om verder te werken. Ik kan mijn idee behouden, maar moet de handeling aanpassen zodat het poppetje zichzelf overeind helpt. Zo heeft het feedbackmoment mij toch geholpen om een keuze te maken voor de verdere uitwerking

Ik ga morgen kijken hoe ik dit kan proberen uit te werken.

## Woensdag 14 oktober

### Het eerste couplet onderzoeken en opnieuw naar de titel kijken

#### Opnieuw luisteren naar het liedje

Nadat ik helaas een dag niet aan mijn ontwerp had kunnen werken, heb ik opnieuw nagedacht over wat ik met de liedtekst wilde doen. Ik heb Y.M.C.A. nog een keer geluisterd en bewust gelet op welke woorden opvallen, waar de nadruk ligt en hoe de woorden worden gezongen.

Ik wilde deze keer vanuit de muziek bepalen welke vormgeving passend zou zijn. Daarom heb ik het eerste couplet in mijn aantekeningenboekje uitgeschreven en de woorden onderstreept waarmee ik wilde experimenteren.

#### Ideeën voor de nadruk en beweging

Bij ‘Young man’ hoorde ik een duidelijke, krachtige nadruk. Ik heb erbij geschreven dat het bijna schreeuwerig klinkt en dat ik dit misschien met dikkere letters kan uitbeelden.

Daarnaast heb ik ideeën opgeschreven voor andere woorden. Bij ‘down’ dacht ik aan een beweging naar beneden, bijvoorbeeld door het woord te laten zakken tijdens het scrollen. Bij ‘ground’ wilde ik onderzoeken of het woord juist een opstaande beweging kon krijgen. Voor ‘need to be’ dacht ik aan een animatie die het ritme van de melodie volgt. ‘Unhappy’ wilde ik mogelijk groter maken.

#### Een eerste aanpassing aan ‘Young man’

Daarna heb ik een eerste aanpassing gedaan aan het couplet. Ik heb de drie keer dat ‘Young man’ voorkomt geselecteerd en groter weergegeven. In mijn CSS heb ik hiervoor font-size: 1.8em gebruikt en de instellingen van het variabele lettertype aangepast.

In de browser kregen deze woorden daardoor duidelijk meer nadruk dan de rest van de zin. Hiermee heb ik een eerste stap gezet om de nadruk die ik in het liedje hoor ook zichtbaar te maken in mijn typografie. De bewegingen voor de andere woorden heb ik op dit moment nog niet uitgewerkt.

#### Toch weer terug naar de titel

Tijdens het werken aan het couplet bleef de titel mij bezighouden. Hoewel ik de letters, lampjes en muzieknootjes al had uitgewerkt, had ik nog steeds het gevoel dat er iets niet helemaal klopte.

Ik heb dus wel een begin gemaakt met het eerste couplet, maar wil eerst verder onderzoeken wat de titel nog nodig heeft. De ideeën voor de liedtekst heb ik vastgelegd, zodat ik daar daarna op kan voortbouwen.

<img src="./assets/images-readme/couplet1.png" alt="" />
Foto: Nogmaals onderzoek gedaan naar couplet 1 en een begin gemaakt aan 1 woord.

### De lampjes per letter laten knipperen

#### Een ander ritme voor de titel

Ik heb de animatie van mijn lampjes aangepast. Eerst gingen de lampjes afzonderlijk aan, maar ik wilde onderzoeken hoe het eruitzag als alle lampjes binnen één letter tegelijk knipperden. Daarna zou de volgende letter aan de beurt komen: eerst de Y, dan de M, de C en de A.

Deze variant vind ik een stuk leuker. De letters krijgen om de beurt aandacht en het knipperen geeft de titel meer het gevoel van een verlicht bord bij een optreden.

#### Eerst de vertraging op de verkeerde plek

Het was even uitvogelen hoe ik dit kon aanpassen. Ik had eerst de afzonderlijke delays bij de lampjes weggehaald en een delay toegevoegd aan de span van de Y. Bij de M probeerde ik vervolgens een vertraging van vijf seconden. Dit gaf niet het resultaat dat ik verwachtte. Ik moest de vertraging dus instellen op de lampjes zelf.

#### Alle lampjes binnen een letter selecteren

Daarna heb ik aparte CSS-regels gemaakt waarmee ik alle lampjes binnen één letter selecteerde. Voor de Y gebruikte ik bijvoorbeeld:

header h1 > span:nth-of-type(1) > span {
animation-delay: 0s;
}

Deze selector kiest de eerste span binnen mijn titel en vervolgens de spans die daar direct in staan. Dat zijn de lampjes van de Y. Hierdoor krijgen ze allemaal dezelfde vertraging en beginnen ze tegelijk.

Hetzelfde heb ik gedaan voor de andere letters. In deze tussenversie kreeg de M een delay van één seconde, de C van twee seconden en de A van drie seconden. Daarmee kon ik de letters na elkaar laten oplichten, terwijl de lampjes op hun bestaande plekken bleven staan.

#### Het aan- en uitgaan vormgeven

Ook heb ik de animatie verder aangepast met @keyframes. Heb de lampjes verder niet aangepast. Wanneer ze aanstaan, zijn ze geel en hebben ze een gele gloed. Wanneer ze uitstaan, worden ze wit en verdwijnt de schaduw. Dus dit is nog steeds het zelfde gebleven.

Door de momenten van aan- en uitgaan en de vertragingen te veranderen, heb ik gezocht naar een verloop dat ik mooi vond. Ik heb steeds iets aangepast en daarna in de browser bekeken wat het effect was. Zo kwam ik uiteindelijk tot een versie waarbij het knipperen naar mijn idee goed over de letters verloopt.

#### Leren door te proberen

Tijdens het experimenteren wist ik niet bij iedere aanpassing precies waarom iets werkte. Ik heb veel geprobeerd en op het zicht beoordeeld of het resultaat bij mijn idee paste. Toen de animatie eruitzag zoals ik wilde, dacht ik: ja, dit wordt het!
Alleen ik heb geen idee of dit is hoe het moet, maar het werkt.

<img src="./assets/images-readme/perletter2.png" alt="" />
Foto: De lampjes per letter laten gaan in plaats van per lampje.

### De titel rustiger maken met feedback van mijn moeder

#### Opnieuw naar het geheel kijken

Na het aanpassen van de knipperende lampjes heb ik mijn moeder om feedback gevraagd. Zij gaf aan dat de titel nu behoorlijk druk was. Naast de gekleurde letters en de bewegende lampjes gebruikte ik namelijk ook verschillende soorten muzieknootjes.

Eerder vond ik die afwisseling juist leuk, maar door haar reactie ben ik opnieuw naar het geheel gaan kijken. De verschillende onderdelen waren afzonderlijk speels, maar samen vroegen ze veel aandacht.

#### Verschillende versies vergelijken

Ik heb eerst de dubbele muzieknoten weggehaald en vervangen door enkele muzieknoten maar wel 2 verschillende. Daarna heb ik deze versie weer aan mijn moeder laten zien. Zij vond dat de titel hierdoor al een stuk rustiger werd.

Vervolgens heb ik nog een versie gemaakt waarin ik overal hetzelfde muzieknootje gebruikte. Ook deze heb ik aan haar voorgelegd. Ze vond deze variant nog rustiger, omdat er meer herhaling en minder verschil tussen de tekens zat.

Door na iedere aanpassing opnieuw feedback te vragen, kon ik de versies stap voor stap vergelijken en gerichter bepalen welke verandering hielp.

#### Mijn uiteindelijke keuze

Ik heb ervoor gekozen om de laatste versie te houden: één soort muzieknootje tussen de letters. Zo blijft de verbinding met muziek zichtbaar, terwijl de titel meer samenhang krijgt. De gekleurde letters en de knipperende lampjes zorgen al voor veel afwisseling.

Deze feedback heeft mij geholpen om verder te kijken dan mijn voorkeur voor losse details. Ik vond de verschillende muzieknootjes leuk, maar in combinatie met de rest werkte een eenvoudiger keuze beter. Door iets weg te halen, kreeg de titel juist meer rust.

<img src="./assets/images-readme/perletter.png" alt="" />
Foto: Het verschil van 2 soorten muziek nootjes en 1 soort.

### Spotlights toevoegen aan mijn titel

#### Mijn eerdere idee alsnog uitproberen

Ik bedacht mij ineens dat we na de tweede week ook kleur en beeld mochten gebruiken. Daardoor kon ik mijn eerdere idee met de spotlights opnieuw oppakken. Dit stond al in mijn schetsen en was ook genoemd tijdens de feedback uit mijn omgeving.

Ik wilde onderzoeken of de spotlights het podiumgevoel van mijn titel konden versterken. Mijn idee was om iedere letter te belichten op het moment dat de lampjes in die letter aangaan.

#### De afbeeldingen maken in Canva

Ik heb in Canva verschillende gekleurde spotlights gemaakt en deze als afbeeldingen aan mijn pagina toegevoegd. De lichtbundels hebben zachte randen, waardoor ze geleidelijk overlopen in de achtergrond.

Bij het eerste bekijken was een spotlight nog veel te groot: de afbeelding nam bijna het hele scherm in beslag. Ik moest dus eerst met CSS de grootte en plaatsing aanpassen voordat de lichtbundels onderdeel van mijn titel konden worden.

<img src="./assets/images-readme/spotlights.png" alt="" />
Foto: De spotslights die ik heb gemaakt via Canva

Bron: [Canva](https://www.canva.com/nl_nl/)

#### De spotlights boven de letters plaatsen

Met de selector header > img heb ik de afbeeldingen een gezamenlijke basisvormgeving gegeven. Daarna heb ik met :nth-of-type() iedere spotlight afzonderlijk geselecteerd en boven de bijbehorende letter geplaatst.

Ik gebruikte position: fixed en top: -3vh, zodat de lichtbundels vanaf de bovenrand van het browservenster lijken te komen. Ze staan daarmee binnen de webpagina, maar geven het gevoel dat het licht van boven het scherm op de titel valt.

Voor de grootte gebruikte ik vw en vh. Vervolgens heb ik de horizontale positie per afbeelding aangepast met left. Dit was vooral uitproberen: een waarde veranderen, in de browser kijken en daarna weer bijstellen. Op de screenshots is te zien dat ik ook kleine aanpassingen heb gedaan om de bundels beter boven de letters te krijgen.

#### De timing afstemmen op de lampjes

Daarna heb ik de timing van de spotlights afgestemd op de knipperende lampjes. Ik gebruikte dezelfde volgorde en probeerde dezelfde vertragingen toe te passen, zodat de spotlight en de lampjes van een letter samen aangaan.

In de verdere uitwerking kreeg iedere spotlight een eigen animatie. Met opacity kan de afbeelding zichtbaar en onzichtbaar worden. De animaties hebben een duur van zes seconden en blijven zich herhalen. Met step-end schakelt de zichtbaarheid op de ingestelde momenten, waardoor het effect meer op aan- en uitgaan lijkt.

Zo wilde ik de verlichting als één geheel laten werken: eerst krijgt de Y aandacht, daarna de M, de C en de A.

<img src="./assets/images-readme/spotlightaanpassen.png" alt="" />
Foto: De spotslights op de juist plek zetten met de letters.

### De spotlights testen en verder met de songtekst

#### Feedback op het discogevoel

Nadat ik de spotlights had toegevoegd, heb ik mijn ontwerp laten bekijken. Ik kreeg vooral enthousiaste reacties: de combinatie van de gekleurde letters, knipperende lampjes en spotlights deed mensen echt aan disco denken.

Dat is precies de sfeer die ik wil overbrengen met Y.M.C.A. Deze reacties bevestigden voor mij dat de verlichting iets toevoegt aan de titel en helpt om het feestelijke gevoel van het liedje zichtbaar te maken.

#### Een probleem tijdens het scrollen oplossen

Tijdens het testen ontdekte ik ook iets wat niet werkte zoals ik wilde. Wanneer ik naar beneden scrolde, bleven de spotlights bovenaan het scherm hangen, terwijl de titel wel uit beeld verdween. Daardoor stonden de lichtbundels niet meer bij de letters waarvoor ze bedoeld waren.

Ik heb de positionering in mijn CSS aangepast, zodat de spotlights nu met de titel mee uit beeld scrollen. Hiermee blijft de verlichting onderdeel van de titel en komt deze tijdens het scrollen niet over de rest van de songtekst te staan.

Deze test liet mij zien dat ik niet alleen naar het eerste beeld van mijn pagina moet kijken. Ook tijdens het scrollen moeten de onderdelen blijven werken zoals ik ze heb bedacht.

<img src="./assets/images-readme/scrolprobleem.png" alt="" />
Foto: Het probleem met het scrollen oplossen. waardoor het niet mee scrolt.

#### De melodie als idee voor later

Ik wil nog onderzoeken of ik het oplichten van de letters kan laten aansluiten op de manier waarop ‘Y.M.C.A.’ in het liedje wordt gezongen. Daarmee zou de animatie nog sterker verbonden zijn met de muziek.

Dit idee parkeer ik voorlopig. Als ik later tijd over heb, kan ik ermee experimenteren. Voor nu wil ik mijn aandacht richten op de rest van de songtekst, zodat ook de coupletten en het refrein verder worden uitgewerkt. De titel heeft inmiddels de discosfeer die ik zocht; mijn volgende stap is om de nadruk en het ritme van het liedje ook in de overige tekst zichtbaar te maken.

### Experimenteren met ‘YOUNG MAN’

#### De nadruk uit het liedje vertalen

Na de titel ben ik verdergegaan met de eerste ‘Young man’ van het eerste couplet. In het liedje klinkt dit alsof iemand je rechtstreeks aanspreekt en je aandacht probeert te trekken. Dat wilde ik zichtbaar maken door de woorden in hoofdletters te zetten en met een animatie groter en kleiner te laten worden.

### Overlap en verschuivende tekst oplossen

Tijdens het uitproberen kwamen de vergrote woorden over de rest van de zin heen te staan. Ik verving transform: scale() eerst door een animatie met font-size. Dat hielp tegen de overlap, maar zorgde ervoor dat de omliggende tekst steeds meeschoof.

Daarom ben ik teruggegaan naar scale() en heb ik de span een vaste breedte gegeven. Ik probeerde verschillende breedtes om voldoende ruimte voor de grootste versie van de woorden te reserveren. Ook paste ik de regelhoogte aan. Hierdoor kon ‘YOUNG MAN’ bewegen zonder dat de rest van de tekst telkens van plek veranderde.

<img src="./assets/images-readme/overlap.png.png" alt="" />
Foto: Young man valt over de rest van de tekst heen.

<img src="./assets/images-readme/testoverlap.png" alt="" />
Foto: Heb gekeken of ik de overlap kon tegen gaan met mer ruimte.

### Grootte, transparantie en snelheid uitproberen

Ik heb veel verschillende versies geprobeerd. Daarbij experimenteerde ik met de grootte, transparantie en snelheid van de animatie. Ik wilde bekijken hoe het overkomt als de woorden eerst wat transparanter zijn en tijdens het groter worden steeds duidelijker zichtbaar worden. Ook heb ik gespeeld met rustmomenten, zodat de woorden niet voortdurend bewegen.

Na iedere aanpassing bekeek ik het resultaat in de browser. Zo kon ik vergelijken welke combinatie het beste paste bij het gevoel dat ik wilde overbrengen.

<img src="./assets/images-readme/YMtrans.png" alt="" />
Foto: Verschillende dingen geprobeerd om Young man zo goed mogelijk te laten overkomen.

### Wat ik hiervan heb geleerd

Dit was vooral een proces van proberen, vergelijken en bijstellen. Ik merkte dat kleine veranderingen in grootte, transparantie en timing veel invloed hebben op de uitstraling. Daarnaast leerde ik dat ik bij een animatie ook rekening moet houden met de ruimte eromheen. Ik wil dat ‘YOUNG MAN’ aandacht trekt, terwijl de volledige zin prettig leesbaar blijft.

## Maandag 12 oktober

### De titel afmaken en feedback verzamelen

#### Ook de C en A uitwerken

Na de Y en M heb ik ook de letters C en A afgemaakt. Ik heb de lampjes over deze letters verdeeld en de plaatsing aangepast aan hun vorm. Daarmee zijn nu alle vier de letters van mijn titel uitgewerkt met lampjes.

#### Past de titel bij het liedje?

Daarna heb ik mensen in mijn omgeving gevraagd wat zij van de titel vonden en of ze deze bij Y.M.C.A. vonden passen. Ik wilde weten of de uitstraling die ik voor ogen had ook bij anderen overkwam.

De feedback was dat het ontwerp heel goed bij het liedje paste. Ze vonden het eruitzien als iets ouds en een tikkeltje ‘cringe’. Dat is eigenlijk precies de sfeer die ik wilde bereiken: een beetje overdreven, vrolijk en met het gevoel van een ouderwets optreden. Voor mij bevestigde deze feedback dat de titel de bedoelde uitstraling begint te krijgen.

#### Het idee van een spotlight

Ook kreeg ik de suggestie om de letters echt in een spotlight te zetten. Ik heb uitgelegd dat ik dit zelf ook graag wilde en dat het idee al in mijn schetsen stond. Het zou het podiumgevoel van de titel verder kunnen versterken.

Omdat ik voor deze opdracht geen beeldmateriaal mag gebruiken, kan ik dit niet met een afbeelding toevoegen zoals ik eerst voor ogen had. Een lichteffect met CSS zou nog een mogelijkheid zijn om te onderzoeken. Voor nu heb ik eerst de letters en de lampjes afgemaakt en feedback verzameld op deze versie.
Natuurlijk ga ik leter kijken of ik het op een manier nog kan toevoegen en kan onderzoeken wat het effect er van is.

### De punten vervangen door muzieknootjes

#### Een speelser detail in de titel

Na het uitwerken van de letters en de lampjes heb ik gekeken hoe ik de punten tussen Y, M, C en A speelser kon maken. Ik wilde onderzoeken of ik deze kon vervangen door muzieknootjes. Daarmee krijgt ook dit kleine onderdeel van de titel een duidelijke verbinding met het liedje.

#### Verschillende muzieknootjes uitproberen

Eerst heb ik één soort muzieknoot gebruikt. Zo kon ik bekijken hoe het eruitzag wanneer hetzelfde teken tussen de letters terugkwam. Dit gaf herhaling en samenhang, maar ik wilde ook een versie met meer afwisseling proberen.

Daarom heb ik vervolgens verschillende soorten muzieknootjes toegevoegd. Deze variant vond ik leuker, omdat de afwisseling de titel een speelsere uitstraling geeft. De tekens horen nog steeds bij elkaar doordat het allemaal muzieknoten zijn, maar ze zijn niet precies hetzelfde.

#### Een kleine verandering met effect

Met deze aanpassing heb ik verder onderzocht hoe ik het muzikale en vrolijke gevoel van Y.M.C.A. in mijn typografie kan verwerken. Niet alleen de grote letters en de lampjes bepalen de uitstraling; ook de tekens ertussen hebben daar invloed op.

Voor deze versie heb ik gekozen voor meerdere soorten muzieknootjes. Die afwisseling past beter bij het speelse gevoel dat ik met mijn titel wil bereiken.

<img src="./assets/images-readme/vanpuntnaarmuziek.png" alt="" />
Foto: De punten tussen de letters vervangen door muziek npotjes.

## Herfstvakantie van 12 okt tot 18 okt

Helaas verdrietig nieuws gekregen in mijn privé omgeving waardoor niet mij zelf kan inzetten zoals ik dat wil.

## Vrijdag 9 oktober

### De lampjes in de armen van de Y plaatsen

#### Uitzoeken waarom de plaatsing niet werkte

Na het plaatsen van de lampjes in het rechte gedeelte van de Y ben ik verdergegaan met de schuine armen. Dit bleek lastiger dan ik had verwacht. Ik heb lang geprobeerd om de lampjes op de juiste plek te krijgen door de posities aan te passen, maar ik kreeg niet het resultaat dat ik wilde.

Daarom heb ik ChatGPT om hulp gevraagd. Ik wilde begrijpen waarom mijn code niet werkte, zodat ik daarna zelf verder kon met het indelen van de lampjes.

#### De juiste span selecteren

Ik gebruikte eerst deze selector:

header h1 > span:nth-of-type(4) {
top: 20%;
left: 20%;
}

Hiermee selecteerde ik de vierde span die direct binnen mijn h1 staat. Dat was niet het vierde lampje binnen de Y. Mijn lampjes staan namelijk een niveau dieper: binnen de span van de letter.

ChatGPT stelde daarom deze selector voor:

header h1 > span:first-of-type > span:nth-of-type(4) {
top: 20%;
left: 20%;
}

Deze selector kiest eerst de eerste span binnen de titel, waarin mijn Y staat. Vervolgens selecteert hij de vierde span binnen die letter. Zo worden de waarden voor top en left toegepast op het bedoelde lampje.

#### Verder met de verdeling

Ik heb deze aanpassing geprobeerd en toen werkte het! Hierdoor kon ik verder met het plaatsen van de overige lampjes in de Y.

Dit hielp mij om beter te begrijpen hoe mijn HTML-opbouw samenhangt met mijn CSS-selectors. Het probleem zat niet alleen in de positie die ik had ingesteld, maar vooral in welk onderdeel ik selecteerde. Bij spans binnen andere spans moet ik dus goed aangeven op welk niveau ik een aanpassing wil doen.

### De lampjes verder uitwerken en laten oplichten

#### De hele Y vullen met lampjes

Voor ieder lampje heb ik de positie afzonderlijk ingesteld. Daarbij heb ik steeds gekeken of het rondje binnen de letter bleef en of de afstand tot de andere lampjes goed was.

Hierdoor begon de titel steeds meer op mijn oorspronkelijke schets te lijken. De lampjes waren nu verspreid over de letter, waardoor het idee van een verlichte podiumletter duidelijker werd.

#### Kleur toevoegen aan de titel

Daarna heb ik de Y rood gemaakt en de lampjes geel laten worden. De overige letters waren op dat moment nog zwart. Zo kon ik eerst op één letter onderzoeken hoe de kleuren en de lampjes samen werkten.

De rode letter met gele lampjes geeft de titel een vrolijkere uitstraling. Dit past bij het feestelijke gevoel dat ik met mijn Y.M.C.A. ontwerp wil overbrengen. Door eerst alleen de Y uit te werken, kon ik deze vormgeving beoordelen voordat ik ermee verderging bij de andere letters.

#### De lampjes laten aangaan

Vervolgens heb ik een animatie toegevoegd waarmee de lampjes van wit naar geel veranderen. Door de lampjes op verschillende momenten te laten veranderen, ontstaat het effect dat ze na elkaar aangaan.

Dit sluit aan bij mijn idee van een verlicht bord. De rondjes zijn daardoor meer dan alleen versiering: de verandering van kleur laat ze op lampjes lijken die worden ingeschakeld.

#### De lampjes duidelijker zichtbaar maken

In de eerste gekleurde versie waren de lampjes nog vrij eenvoudige gele rondjes. Daarna heb ik ze verder vormgegeven met een zwart randje en een gele gloed.

Het zwarte randje maakt de omtrek van ieder lampje duidelijker zichtbaar op de rode letter. De gloed eromheen versterkt het idee dat het lampje licht geeft. Hierdoor lijken de rondjes meer op echte verlichting.

Ik heb het resultaat ook van dichtbij bekeken. Zo kon ik beter zien hoe de rand en de gloed eruitzagen en of de lampjes nog netjes binnen de letter stonden. Daarna heb ik een opname gemaakt om deze vormgeving samen met de animatie te bekijken.

#### Verdergaan met de letter M

Toen de Y verder was uitgewerkt, ben ik begonnen met de lampjes in de M. Hiervoor gebruikte ik dezelfde opbouw: de letter staat in een eigen span en de lampjes staan daarbinnen in afzonderlijke spans.

De M heeft een andere vorm dan de Y. Daarom kon ik de posities niet zomaar overnemen. Ik heb de lampjes verdeeld over de linkerzijde, de schuine lijnen in het midden en de rechterzijde.

Met selectors zoals header h1 > span:nth-of-type(2) > span:nth-of-type(3) kon ik een specifiek lampje binnen de tweede letter selecteren. Vervolgens bepaalde ik met top en left waar dat lampje moest komen.

In deze tussenversie bleef de M zwart. Daardoor kon ik ook zien hoe dezelfde gele lampjes met hun gloed eruitzagen op een andere achtergrondkleur.

#### Wat ik tijdens deze stap heb geleerd

Tijdens deze uitwerking heb ik geleerd dat de plaatsing, kleur en afwerking samen bepalen hoe overtuigend het lampjeseffect is. Met alleen witte rondjes had ik een eerste basis. Door geel, een rand en een gloed toe te voegen, werd het idee van verlichting veel duidelijker.

Ook merkte ik dat iedere letter een eigen verdeling nodig heeft. De basisvormgeving van de lampjes kan ik opnieuw gebruiken, maar hun posities moet ik aanpassen aan de lettervorm.

Mijn titel is hiermee weer een stap verder uitgewerkt. De Y heeft nu een eerste werkende lichtanimatie en ik ben begonnen met het toepassen van de lampjes op de M. Vanuit deze basis kan ik verder werken aan de overige letters en het geheel blijven vergelijken met mijn schets.

### Meerdere lampjes toevoegen en de vorm vergelijken

### De lampjes over de Y verdelen

Nadat het eerste vierkantje op de letter Y stond, heb ik meerdere spans toegevoegd binnen diezelfde letter. Vervolgens heb ik de vierkantjes op verschillende hoogtes geplaatst. Zo ontstond er een rij van drie witte vierkantjes in het onderste, rechte gedeelte van de Y.

Hierbij heb ik gekeken naar de afstand tussen de vierkantjes en of ze netjes binnen de zwarte letter bleven. Door eerst een klein gedeelte van de Y uit te werken, kon ik rustig onderzoeken hoe ik meerdere lampjes kon plaatsen voordat ik de rest van de titel zou vullen.

#### Van vierkantjes naar rondjes

Daarna wilde ik vergelijken of ronde lampjes beter bij mijn idee zouden passen. Ik heb de vormgeving aangepast, waardoor de witte vierkantjes veranderden in rondjes. De plaatsing bleef hetzelfde, zodat ik het verschil tussen de twee vormen goed kon bekijken.

De ronde vorm sluit meer aan bij de lampjes uit mijn oorspronkelijke schets. Op de screenshots is deze stap duidelijk te zien: eerst staan er drie witte vierkantjes in de Y en daarna drie witte rondjes.

<img src="./assets/images-readme/vierkantnaarrondje.png" alt="" />
Foto: Heb het lampje van een vierkantje naar een rondje veranderd.

### Mijn eerste experiment met een lampje in de letter Y

#### Iedere letter als eigen onderdeel

Voor mijn idee met de lampjes wil ik iedere letter als een afzonderlijk onderdeel kunnen vormgeven. Daarom heb ik de letters van Y.M.C.A. ieder in een eigen span gezet. Zo kan iedere letter de basis worden waarbinnen ik kleine lampjes plaats.

Ik ben begonnen met één vierkantje in de Y. Eerst wilde ik onderzoeken of ik een extra span binnen de span van de letter kon zetten en deze vervolgens met CSS zichtbaar kon maken. Ik wist niet zeker of die opbouw mogelijk was en of het mag, maar door het uit te proberen zag ik dat het werkt.

#### Een vierkantje maken met CSS

De binnenste span heb ik met CSS vormgegeven als een klein wit vierkantje. Hiervoor heb ik de breedte en hoogte allebei op 0.05em gezet en een witte achtergrond toegevoegd.

Omdat ik em gebruik, wordt de grootte van het vierkantje bepaald door de lettergrootte die het erft. Hierdoor kan het vierkantje meeschalen wanneer de titel groter of kleiner wordt. Dit past bij mijn titel, die zich ook aanpast aan de schermbreedte.

Dit vierkantje is mijn eerste proef voor een lampje. Ik heb dus nog niet meteen alle letters gevuld, maar ben begonnen met één onderdeel om te begrijpen hoe ik het kan opbouwen.

#### Vanuit één lampje verder bouwen

Deze stap geeft mij een basis om mijn schets verder uit te werken. Ik wil hierna onderzoeken hoe ik meerdere lampjes over de letters kan verdelen. Iedere letter heeft een andere vorm, dus ik moet per letter bekijken waar de lampjes het beste passen.

Daarna wil ik kijken of ik de lampjes van kleur kan laten veranderen, zodat het lijkt alsof ze één voor één aangaan. Voor nu heb ik eerst getest of de opbouw met een span binnen een span werkt en hoe ik het eerste lampje op de juiste plek kan zetten.

<img src="./assets/images-readme/grootenkleinscehrm.png" alt="" />
Foto: Het eerste rondje in de Y gezet

### De titel bovenaan de pagina platsen

#### De eerdere indeling aanpassen

Om mijn idee met de lampjes verder uit te werken, heb ik eerst de plaatsing van mijn titel aangepast. In mijn vorige versie stond Y.M.C.A. op grote schermen verticaal aan de linkerkant van de liedtekst. Ik heb de CSS die voor deze plaatsing en schrijfrichting zorgde weggehaald.

Ik heb ervoor gekozen om de titel nu horizontaal bovenaan de pagina te zetten. Hierdoor krijgt de titel een centrale plek en kan ik de vier letters naast elkaar vormgeven, zoals in mijn schets. Dit vormt het uitgangspunt voor mijn verdere experiment met de lampjes.

#### Een dikker en eenvoudiger lettertype

Daarna heb ik de vormgeving van de letters aangepast. Ik heb gekozen voor een zo eenvoudig mogelijk lettertype en de letters dikker gemaakt. Ik wil eerst een duidelijke basis hebben waarin de vorm van Y, M, C en A goed herkenbaar is.

De dikke letters passen bij mijn schets, waarin de titel uit brede letters met kleine lampjes bestaat. Door de lettervorm eenvoudig te houden, kan ik straks onderzoeken hoe de lampjes binnen de letters passen en welk effect ze op de leesbaarheid hebben.

<img src="./assets/images-readme/tittelzijkantnaarboven.png" alt="" />
Foto: De titel veranderen van de zijkant naar het midden van de bovenkant.

#### De grootte aanpassen aan het scherm

Ook heb ik de titelgrootte afgestemd op de beschikbare schermruimte. Op een klein scherm is de titel kleiner, zodat hij beter binnen de pagina past. Op een groot scherm worden de letters groter en krijgt de titel meer nadruk.

Ik heb de verschillende weergaven bekeken door mijn browservenster smaller en breder te maken. Zo kon ik vergelijken hoe de titel eruitziet bij verschillende schermgroottes.

Met deze aanpassingen heb ik een nieuwe basis gemaakt: een horizontale titel bovenaan de pagina, met dikke, eenvoudige letters die in grootte reageren op het scherm. Vanuit deze basis wil ik verder werken aan het plaatsen en laten oplichten van de lampjes.

### Mijn oude schets opnieuw gebruiken voor de titel

#### Nieuwe titel

Na het werken aan het draaiende rondje wil ik nu kijken hoe ik de titel van mijn Y.M.C.A.-pagina verder kan vormgeven. Nu ik ook kleur mag gebruiken, zie ik nieuwe mogelijkheden om de titel opvallender te maken en het feestelijke gevoel van het liedje terug te laten komen.

Daarom heb ik een van mijn eerdere schetsen er opnieuw bij gepakt. Ik wil onderzoeken of ik dit idee met HTML en CSS kan uitwerken en hoe het past bij de rest van mijn pagina.

#### Grote letters met kleine lampjes

In deze schets heb ik Y.M.C.A. getekend met grote, brede letters. In de letters zitten kleine rondjes die lampjes voorstellen. Dit doet mij denken aan een verlicht bord bij een theater of een podium. Die uitstraling vind ik passen bij de muziek, het optreden en de vrolijke sfeer van Y.M.C.A.

Met kleur wil ik het idee van de lampjes duidelijker maken. Ik wil onderzoeken of ik ze één voor één kan laten oplichten, zodat het lijkt alsof de verlichting wordt aangezet. Daarmee krijgt de titel niet alleen een opvallende vorm, maar ook beweging.

<img src="./assets/images-readme/oudeschets.png" alt="" />
Foto: Miijn eerdere schets waar ik nu weer op terug gevallen ben.

#### Onderzoeken hoe ik de schets kan coderen

Mijn volgende stap is om te bekijken hoe ik dit ontwerp kan opbouwen in mijn code. Eerst wil ik zorgen dat de letters de juiste vorm, grootte en plaatsing krijgen. Daarna wil ik onderzoeken hoe ik de lampjes binnen de letters kan plaatsen en afzonderlijk kan laten veranderen.

Ik wil dit stap voor stap aanpakken, zodat ik begrijp wat iedere aanpassing doet en mijn proces goed kan vastleggen. Het is nu nog een idee dat ik wil uitproberen. Tijdens het coderen moet ik bekijken of het technisch lukt, of de titel leesbaar blijft en of de beweging goed samengaat met het draaiende rondje.

Door mijn oude schets opnieuw te gebruiken, bouw ik verder op mijn eerdere voorbereiding. Nu ik meer heb geoefend met CSS en animaties, kan ik onderzoeken hoe ik dat getekende idee kan vertalen naar een werkend ontwerp.

## Les van vrijdag 9 oktober

### Verder werken aan mijn typografische ontwerp van Y.M.C.A.

#### Na de feedback verder met mijn songtekst

Na de feedbackmomenten met Diederik en Sanne ben ik verdergegaan met mijn songtekst. Ik had woensdag en donderdag vooral gewerkt aan mijn voorbereiding, zoals de schetsen, de deepdives en de user tests. Vandaag wilde ik die voorbereiding verder vertalen naar mijn eigen ontwerp in HTML en CSS.

Ik ben verdergegaan met het draaiende rondje met de tekst ‘Y.M.C.A. – Village People’. De basis hiervan had ik eerder gemaakt met behulp van het voorbeeld van Sanne op CodePen. Vandaag heb ik vooral geëxperimenteerd met de onderdelen binnen dat rondje: de verdeling van de letters, muzieknoten, extra beweging en de snelheid van de animatie.

Mijn doel was om het vrolijke en dansbare gevoel van het liedje zichtbaar te maken. Tegelijkertijd wilde ik dat de tekst nog goed te lezen bleef. Daarom heb ik verschillende versies geprobeerd en tussendoor feedback gevraagd.

#### De letters afzonderlijk kunnen aanpassen

In mijn HTML staat iedere letter van het rondje in een eigen span. Ook de tussenruimtes en de tekens tussen de woorden zijn aparte onderdelen. Hierdoor kan ik met CSS niet alleen het hele rondje vormgeven, maar ook afzonderlijke onderdelen selecteren.

Dit was handig toen ik extra accenten wilde toevoegen. De letters konden hun bestaande beweging behouden, terwijl ik bepaalde tekens een andere vormgeving of een extra animatie gaf.

#### Muzieknoten toevoegen aan het rondje

Om de verbinding met het liedje duidelijker te maken, heb ik muzieknoten toegevoegd tussen de tekst. Hiermee wilde ik het rondje meer het gevoel geven van muziek en beweging.

De muzieknoten staan, net als de letters, in afzonderlijke spans. Daardoor kon ik ze apart selecteren met `:nth-of-type()`. Deze selector kijkt naar de positie van een element tussen elementen van hetzelfde type.

Tijdens het aanpassen heb ik verschillende posities geprobeerd. Ik moest goed controleren welke span daadwerkelijk de muzieknoot bevatte. Wanneer ik in de HTML een extra span toevoegde, bijvoorbeeld voor een tussenruimte, veranderde de telling. Daardoor kon mijn CSS ineens een ander onderdeel selecteren dan ik bedoelde.

Hierdoor merkte ik hoe belangrijk het is om mijn HTML en CSS samen te bekijken. De selector kan technisch goed geschreven zijn, maar moet ook overeenkomen met de opbouw van mijn HTML.

Bron: Ik heb op
[Toptal](https://www.toptal.com/designers/htmlarrows/symbols/) een element gezocht die ik kan toevoegen voor de muzieknootjes.

#### De muzieknoten laten meebewegen

Daarna heb ik de muzieknoten een extra animatie gegeven. Ze bewegen mee in het rondje en worden daarnaast afwisselend groter en kleiner. Hierdoor krijgen ze een soort pulserende beweging.

Ik heb hiervoor een aparte animatie gemaakt met @keyframes. Bij het begin en het einde van de animatie hebben de muzieknoten dezelfde schaal. Halverwege worden ze groter. Doordat de animatie zich blijft herhalen, ontstaat een doorgaande beweging.

In mijn eerste versie veranderde de schaal van 1 naar 1.3 en weer terug. Deze animatie duurde drie seconden. Vervolgens heb ik ook een rustigere variant geprobeerd: van 0.` naar 1.2, met een duur van vijf seconden.

Door die waarden aan te passen kon ik vergelijken hoe nadrukkelijk de muzieknoten aanwezig waren. Een groter verschil in schaal maakt de beweging opvallender. Een langere duur laat de verandering rustiger verlopen.

Ik wilde hiermee onderzoeken hoe ik een extra accent kon toevoegen zonder dat het de draaiende tekst te veel zou afleiden.

#### Twee animaties op hetzelfde onderdeel gebruiken

Bij de muzieknoten gebruikte ik twee animaties tegelijk: de animatie voor het draaien in het rondje en de animatie voor het groter en kleiner worden.
Dit ging alleen niet zoals ik wilde. Dus na een aantal keer proberen om het mooi te krijgen heb ik er voor gekozen om de tweede weg te halen en het alleen bij 1 muziek nootje per plek te houden.

#### Een kleurenpalet zoeken dat bij Village People past

Naast de beweging heb ik gekeken naar kleuren die bij mijn ontwerp zouden kunnen passen. Hiervoor heb ik een foto van Village People gebruikt als uitgangspunt. Uit die foto heb ik een kleurenpalet gehaald.
In het palet zitten lichtblauw, een zandkleur, bijna zwart, rood en donkerbruin.

Zo heb ik een uitgangspunt voor mijn kleurkeuzes dat verbonden is aan de artiesten. Ik kan hiermee verder onderzoeken welke kleuren goed werken voor de tekst, de achtergrond en de accenten.

Bron:
[Adobe color](https://color.adobe.com/create/color-wheel?tab=image) hier mee heb ik het kleuren pallet gemaakt.

#### Feedback vragen op de snelheid en leesbaarheid

Om te controleren hoe anderen de animatie ervaren, heb ik filmpjes van mijn ontwerp doorgestuurd. Ik vroeg onder andere wat zij van de snelheid vonden, of de tekst goed te lezen was en of een andere draairichting misschien beter zou werken.

Ik vond het belangrijk om dit te vragen, omdat ik zelf al lang naar mijn ontwerp had gekeken. Ik weet welke tekst er staat en kan die daardoor makkelijker herkennen. Iemand die de animatie voor het eerst ziet, kijkt daar anders naar.

Meerdere reacties waren positief. Een tester vond de beweging niet te langzaam, maar ook niet zo snel dat je er duizelig van wordt. Laura gaf aan dat zij de tekst kon lezen. Een andere tester vond de snelheid prima.

Ook kreeg ik de reactie dat ik het rondje niet sneller moest maken, omdat de tekst dan moeilijker leesbaar zou worden. Dat was voor mij een belangrijk punt: de beweging moet bijdragen aan het ontwerp, maar de woorden moeten herkenbaar blijven.

### Feedback en mijn ontwerpkeuzes onderbouwen

#### Feedback van Diederik en Sanne

Vandaag hebben we in een groepje feedback gekregen van Diederik en Sanne. Tijdens dit moment hebben we gekeken naar de voortgang van mijn songtekst. Ik was met de uitwerking in code nog niet heel ver, omdat ik door mijn trip naar Londen wat achterliep.

Ik heb uitgelegd dat ik woensdag en donderdag vooral bezig ben geweest met mijn schetsen, het inhalen van de deep dives en het verzamelen van feedback via gebruikerstesten. Daarmee heb ik eerst gewerkt aan mijn ideeën en de kennis die ik nodig heb om deze uit te werken.

Diederik en Sanne vonden dit een goede aanpak. Ook vonden ze het positief dat ik zelf duidelijk kon aangeven wat ik al had gedaan en wat er nog moest gebeuren. Hoewel mijn ontwerp nog niet ver was uitgewerkt, kon ik wel uitleggen waar ik stond en hoe ik verder wilde.

#### Een individueel feedbackgesprek met Diederik

Daarna had ik een één op ééngesprek met Diederik, omdat ik het feedbackmoment van vorige week vrijdag had gemist. Tijdens dit gesprek hebben we vooral naar mijn persoonlijke website gekeken.

We hebben gesproken over mijn privacyinformatie, de rustige uitstraling van mijn website en mijn learning log. Hierdoor kon ik mijn keuzes verder toelichten en kreeg ik feedback op zowel mijn ontwerp als de manier waarop ik mijn proces beschrijf.

#### Mijn keuze voor privacyinformatie uitleggen

Diederik wilde meer weten over het koekje op mijn website. Hij vroeg waarom bezoekers daar niet kunnen kiezen om te accepteren of af te wijzen.

Ik heb uitgelegd dat ik het koekje gebruik om informatie te geven over privacy. Op mijn website gebruik ik geen optionele cookies waarvoor ik een keuze tussen accepteren en afwijzen aanbied. Daarom heb ik gekozen voor een informatief bericht.

Ook heb ik toegelicht dat de hosting bij het opvragen van de website al servergegevens kan vastleggen, zoals een IP-adres. Een afwijsknop op mijn pagina zou die registratie niet ongedaan maken. Met het bericht wil ik daarom duidelijk uitleggen wat er gebeurt, zodat de bezoeker hierover informatie kan vinden.

#### Waarom mijn website rustig en clean is

Diederik vroeg ook waarom mijn website zo netjes en clean is en of ik er meer persoonlijke dingen in wil verwerken. Ik heb uitgelegd dat deze rustige uitstraling juist bij mij past.

Omdat de opdracht gaat over het maken van een persoonlijke website, vind ik het belangrijk dat het ontwerp laat zien wie ik ben. Voor mij hoeft een persoonlijke website niet per se druk te zijn. De rustige indeling en verzorgde uitstraling zijn ook persoonlijke keuzes.

Ik heb daarom bewust gekozen om mijn website overzichtelijk en clean te houden. Ik wil mijn ontwerpkeuzes kunnen koppelen aan mijn eigen voorkeuren, zodat ik kan uitleggen waarom de website er zo uitziet.

#### Experimenteren binnen mijn songtekst

Tijdens het gesprek heb ik aangegeven dat ik wel graag wil spelen en experimenteren met typografie. Dat wil ik vooral laten zien in mijn songtekstproject.

Binnen de Y.M.C.A. pagina kan ik onderzoeken wat er gebeurt wanneer ik letters laat bewegen, draaien of van grootte laat veranderen. Dit geeft mij ruimte om andere dingen uit te proberen en mijn vaardigheden verder te ontwikkelen.

Diederik vond dit een goede uitleg. Ik kon onderbouwen waarom ik bepaalde experimenten niet in mijn persoonlijke website verwerk, maar ze wel binnen mijn songtekst wil onderzoeken. Zo maak ik een bewuste keuze over welke vormgeving bij welk onderdeel past.

#### Feedback op mijn learning log

We hebben ook kort naar mijn learning log gekeken. Diederik gaf aan dat deze erg lang is en daardoor veel leeswerk vraagt. Tegelijkertijd vond hij het mooi om te zien dat ik mijn proces duidelijk beschrijf en mijn keuzes goed uitleg en onderbouw.
Deze feedback laat mij zien dat mijn uitgebreide uitleg helpt om mijn werk te begrijpen.

#### Wat ik uit de gesprekken meeneem

Uit de feedback neem ik mee dat ik goed kan aangeven waar ik sta en wat mijn volgende stappen zijn. Ook kon ik mijn keuzes voor de privacyinformatie en de uitstraling van mijn website toelichten.

Ik wil nu verder werken aan de uitwerking van mijn songtekst. Daarbij kan ik de voorbereiding, schetsen en reacties van de testers gebruiken om bewuste keuzes te maken. Daarnaast wil ik mijn learning log duidelijk blijven bijhouden, met aandacht voor de hoeveelheid tekst en de leesbaarheid.

<img src="./assets/images-readme/verder-YMCA.png" alt="" />
Foto: Verschillende foto's van mijn YMCA

<img src="./assets/images-readme/kleurenpallet-YMCA.png" alt="" />
Foto: Mijn kleuren pallet voor YMCA

### CHeck-out

1. Welke variabelen kan ik gebruiken?

Bij Seraphs kan ik experimenteren met wght en SRFS. Met wght verander ik de dikte van de letters. Met SRFS verander ik de schreven, de uiteinden van de letters. Ik wil onderzoeken welke combinatie bij mijn songtekst past.

2. Wat kunnen deze variabelen toevoegen?

Met verschillende diktes kan ik hiërarchie maken. Belangrijke woorden kunnen dikker worden, zodat ze meer opvallen dan de rest van de tekst. Met de schreven kan ik de uitstraling veranderen en onderzoeken hoe speels of uitgesproken ik de letters wil maken. Daarbij wil ik erop letten dat de songtekst goed leesbaar blijft.

3. Hoe zou ik animatie kunnen toepassen?

Ik zou de letters afwisselend dikker en dunner kunnen laten worden, alsof ze meebewegen op het ritme van de muziek. Ook kan ik woorden of letters na elkaar laten bewegen om accenten uit de zang te benadrukken. Ik wil hiermee experimenteren om te ontdekken wat bij de energie van Y.M.C.A. past, zonder dat de tekst te druk wordt.

## Donderdag 8 oktober

### Aan mijn Y.M.C.A. ontwerp beginnen

#### Van voorbereiding naar mijn eigen ontwerp

Na de deep dives ben ik begonnen met het uitwerken van mijn eigen Y.M.C.A.-pagina. Ik wilde de technieken uit de uitleg toepassen op mijn ontwerp en onderzoeken hoe ik met de plaatsing en beweging van tekst een speels resultaat kon maken.

Ik heb mijn pagina steeds lokaal geopend in Safari, terwijl ik daarnaast in Visual Studio Code werkte. Hierdoor kon ik na een aanpassing meteen bekijken wat er veranderde. Van de verschillende stappen heb ik screenshots gemaakt. Daarop is niet alleen het resultaat te zien, maar ook hoe mijn ontwerp zich tijdens het werken ontwikkelde.

#### Het lokale lettertype toepassen

Als basis heb ik het lettertype Seraphs gekoppeld met @font-face. Het fontbestand staat in mijn eigen projectmap, in assets/type. Vanuit mijn CSS-bestand verwijs ik naar dit bestand.

Daarna heb ik het lettertype op de body toegepast, met sans-serif als fallback. Zo kreeg de pagina een gezamenlijke typografische basis. In deze eerste uitwerking heb ik vooral gewerkt aan de layout en de draaiende tekst. Het verder aanpassen van de eigenschappen van het variabele font kan ik daarna onderzoeken.

#### De eerste indeling met Grid

Ik ben begonnen met een indeling waarbij de titel, liedtekst en footer onder elkaar staan. Hiervoor heb ik op de body display: grid gebruikt en met gap: 2em ruimte tussen de onderdelen gemaakt.

Daarna heb ik een mediaquery toegevoegd voor schermen breder dan 50em. Binnen deze mediaquery krijgt de pagina twee kolommen. De eerste kolom is voor de titel en de tweede voor de liedtekst.

Met grid-column en grid-row heb ik de header en de hoofdinhoud een plek gegeven. De header staat in de eerste kolom en de main in de tweede kolom, allebei in dezelfde rij. De footer heb ik met grid-column: 1 / -1 over de volledige breedte van het grid geplaatst.

Hiermee heb ik een basis gemaakt die reageert op de beschikbare schermruimte. Op een smaller scherm staan de onderdelen onder elkaar. Op een breder scherm komt er ruimte om de titel naast de tekst te zetten.

#### De titel aan de linkerkant zetten

Vervolgens heb ik op brede schermen writing-mode: sideways-lr aan de header toegevoegd. Hierdoor loopt de titel aan de linkerkant van beneden naar boven.

Dit veranderde de compositie van mijn pagina. De titel stond nu naast de liedtekst en werd een afzonderlijk onderdeel van de indeling. Door het browservenster smaller en breder te maken, heb ik bekeken wanneer deze vormgeving werd toegepast.

Op de screenshots is het verschil zichtbaar: in het smallere venster staat de header bovenaan, terwijl in het brede venster de titel langs de linkerkant loopt. Zo kon ik controleren wat mijn mediaquery deed.

#### De titel en artiest uit elkaar halen

In mijn eerste versie stonden Y.M.C.A. en Village People samen in de hoofdkop. Daarna heb ik deze uit elkaar gehaald. Y.M.C.A. bleef in de h1 staan en de artiestennaam kreeg een eigen p binnen de header.

Hierdoor kon ik de titel en artiestennaam afzonderlijk vormgeven. In het resultaat is Y.M.C.A. groter dan Village People, waardoor de titel duidelijk meer nadruk krijgt.

Deze stap hielp mij om de hiërarchie te verbeteren. De bezoeker ziet eerst de naam van het liedje en daarna de artiest. Op het smallere scherm staan deze onderdelen boven elkaar; op het bredere scherm staan ze naast elkaar binnen de verticale header.

#### Het voorbeeld van Sanne als basis gebruiken

Tijdens de les op woensdag had mijn docent Sanne een animatie van draaiende letters gemaakt voor Jip, die tegenover mij zat. Sanne heeft dit voorbeeld op CodePen gezet onder de naam ‘rondje voor jip’.

Ik heb zijn voorbeeld gebruikt als basis voor het rondje in mijn eigen ontwerp. In de code heb ik bekeken hoe hij met Grid de letters hetzelfde middelpunt geeft en hoe hij met rotate(), translateY() en verschillende animation-delay-waarden de letters in een cirkel laat bewegen.

Vanuit deze basis heb ik het voorbeeld aangepast naar de tekst Y.M.C.A. Village People. Daarna heb ik geëxperimenteerd met de afstand tot het middelpunt en de animatieduur om te onderzoeken welke grootte en snelheid bij mijn pagina passen.

Bron: Sanne, rondje voor jip, CodePen — voorbeeld gemaakt tijdens de les op woensdag 7 oktober 2026.

[Codepen Sanne](https://codepen.io/editor/shooft/pen/01a11591-95f0-72eb-97b9-0c4f621666e0)

#### Eerst het hele woord laten draaien

Ik heb eerst geëxperimenteerd met een versie waarbij een volledig woord als één geheel ronddraait. Hiervoor heb ik een aside toegevoegd als apart onderdeel naast de liedtekst.

Binnen dit onderdeel heb ik gewerkt met een centraal geplaatste tekst en een tekst die daaromheen beweegt. Met Grid kon ik beide onderdelen hetzelfde middelpunt geven. De animatie combineerde een draaiing van 0deg naar 360deg met een verplaatsing via translateY().

#### De letters afzonderlijk plaatsen

Daarna heb ik geprobeerd om Y, M, C en A afzonderlijk te laten bewegen. In een tussenstap zette ik ze in losse p-elementen. In het resultaat kwamen de tekens nog op dezelfde plek terecht, waardoor ze elkaar bedekten.

Vervolgens heb ik de tekst Y.M.C.A. Village People in één p gezet, met ieder teken in een eigen span. Ook de punten en spaties kregen een eigen span. Voor de spaties gebruikte ik &nbsp;, zodat er een apart teken tussen de woorden bleef staan.

Met deze structuur kon ik ieder teken dezelfde basisvormgeving geven en vervolgens per teken de positie in de animatie laten verschillen.

Bij het draaiende onderdeel heb ik een aria-label toegevoegd met de volledige tekst. De losse, visuele tekens staan binnen een paragraaf met aria-hidden="true". Hiermee wilde ik voorkomen dat de decoratieve herhaling als een reeks losse letters wordt voorgelezen. Dit moet ik nog met een screenreader controleren.

#### De animatie op de losse spans toepassen

Na het aanpassen van de HTML heb ik de animatie op de afzonderlijke spans gezet. Hiervoor gebruikte ik de selector aside > p > span. Zo richtte ik de CSS op de tekens van het draaiende onderdeel.

De paragraaf kreeg display: grid en place-items: center. Alle spans kregen grid-area: 1 / 1, zodat ze hetzelfde startpunt hadden.

Op dat moment stonden de letters nog boven op elkaar. Omdat ze allemaal dezelfde animatie op hetzelfde moment uitvoerden, bleven ze ook tijdens het draaien samenvallen. In de browser zag ik daardoor een klein donker groepje tekens in plaats van een leesbare cirkel.

Deze tussenstap maakte duidelijk waarom alleen losse spans niet genoeg zijn. Ik moest ook zorgen dat iedere span op een andere plek in de animatie begon.

#### De letters over de cirkel verdelen

Daarna heb ik een animation-delay toegevoegd met een berekening waarin sibling-index() voorkomt. Hiermee kan ieder teken een andere vertraging krijgen op basis van zijn volgorde binnen de paragraaf.

Ik gebruikte negatieve vertragingen. Daardoor wachten de letters niet eerst voordat ze beginnen, maar starten ze alsof hun animatie al een stukje bezig is. Elke letter komt zo op een andere positie in de draaiing terecht.

Na deze aanpassing ontstond er een cirkelvorm. De letters stonden niet meer allemaal op dezelfde plek. In de eerste versie was de cirkel nog klein en zaten sommige tekens dicht op elkaar. Daarom ben ik verder gaan experimenteren met de grootte en het tempo.

#### De grootte van de cirkel onderzoeken

Om de cirkel groter te maken, heb ik de waarde van translateY() aangepast. Deze waarde bepaalt in mijn animatie hoe ver de letters van het gezamenlijke middelpunt worden geplaatst.

Ik heb verschillende afstanden uitgeprobeerd:

- Bij 1.5em was de cirkel klein en stonden de letters dicht bij elkaar.

- Bij 2.5em kwam er meer ruimte tussen de tekens.

- Bij 3.5em werd de cirkel groter en duidelijker zichtbaar.

- Bij 5em kreeg het onderdeel veel meer ruimte, maar kwam een deel in het smallere browservenster buiten beeld.

Door deze waarden stap voor stap te veranderen, kon ik het effect van de afstand goed vergelijken. Een grotere cirkel geeft meer ruimte aan de letters, maar moet ook passen binnen de pagina.

Hierbij merkte ik dat de zichtbare animatie groter kan worden dan het vak dat ik ervoor heb gereserveerd. Het aanpassen van de beweging betekent dus niet automatisch dat de omliggende layout ook meer ruimte krijgt.

#### Het tempo aanpassen

Naast de grootte heb ik ook de duur van de animatie aangepast. In mijn tussenversies heb ik onder andere 2, 5 en 10 seconden geprobeerd. In de laatste screenshot staat de animatie op 12 seconden.

Met een langere duur draaien de letters langzamer rond. Dat geeft meer tijd om de tekst te herkennen. Met linear blijft de draaisnelheid gelijk en met infinite blijft de animatie zich herhalen.

In de laatste versie is de tekst duidelijker over de cirkel verdeeld. Bij het aanpassen van het tempo moet ik ook rekening houden met de berekening van de delays. De duur en de onderlinge vertragingen bepalen samen hoe de letters over de cirkel staan.

#### Wat ik tijdens het uitwerken heb geleerd

Tijdens deze uitwerking heb ik geleerd dat een kleine wijziging in CSS veel invloed kan hebben op het resultaat. Het aanpassen van de schrijfrichting veranderde de compositie van de pagina. Het aanpassen van translateY() veranderde de grootte van de cirkel en het aanpassen van de animatieduur veranderde het tempo.

Ook heb ik het verschil onderzocht tussen een heel woord animeren en afzonderlijke letters animeren. Bij een heel woord beweegt de tekst als één blok. Bij losse spans kan ik ieder teken een andere positie geven, maar moet ik ook nadenken over de verdeling en onderlinge ruimte.

De versies waarin de letters overlapten, waren daarom ook nuttig. Door telkens één onderdeel aan te passen en het resultaat in de browser te bekijken, kon ik beter begrijpen waardoor het effect ontstond.

<img src="./assets/images-readme/beginvan-YMCA.png" alt="" />
Foto: Verschillende foto's van mijn begin van YMCA

### Deep dive variabele fonts

#### De opdrachten uitwerken

Na de voorbereiding heb ik de opdrachten van de deep dive gemaakt. Hierbij heb ik verschillende variabele fonts lokaal gekoppeld met @font-face en met CSS hun eigenschappen aangepast. Door de waarden zelf in te vullen, kon ik oefenen met de mogelijkheden van de verschillende lettertypes.

#### Opdracht 1: eigenschappen en kleurpaletten

In de eerste opdracht heb ik gewerkt met Dyna Puff, Honk en Rocher Color. Bij Dyna Puff heb ik verschillende waarden voor het gewicht en de breedte ingesteld. Bij Honk heb ik met custom assen gewerkt om de lettervorm te veranderen.

Bij Rocher Color heb ik daarnaast verschillende kleurpaletten ingesteld met @font-palette-values en font-palette. Deze opdracht liet mij zien dat je bij sommige fonts ook kleuren en effecten binnen het lettertype kunt aanpassen.

<img src="./assets/images-readme/opdracht1-deepdivef.png" alt="" />
Foto: Opdracht 1 van de Deep dive

#### Opdracht 2: vloeiende veranderingen

Daarna heb ik geoefend met transitions bij Saira Stencil, Kablammo, Plastic en Cheeeze. Ik heb een beginstand en een andere stand bij :hover ingesteld. Met een transition kan de verandering tussen deze standen vloeiend verlopen.

Hierbij heb ik gewerkt met lettergewicht, breedte en custom assen. Zo heb ik onderzocht hoe tekst kan veranderen wanneer je er met de muis overheen gaat.

<img src="./assets/images-readme/opdracht2-deepdivef.png" alt="" />
Foto: Opdracht 2 van de Deep dive

#### Extra theorie lezen

Naast de opdrachten heb ik theorie gelezen over transitions, staggered transitions en animaties. Ik heb geleerd hoe je met @keyframes verschillende stappen van een animatie beschrijft en hoe je deze aan een element koppelt.

Ook heb ik gelezen dat je variabele fonts met JavaScript dynamisch kunt aanpassen. Dit onderdeel heb ik nog niet zelf uitgewerkt. Mijn aandacht lag eerst bij het begrijpen en toepassen van de CSS.

<img src="./assets/images-readme/extratheorie.ddf.jpg" alt="" />
Foto: Aantekeningen van de extra theorie.

#### Wat ik meeneem naar mijn project

Door de opdrachten heb ik meer mogelijkheden ontdekt om met typografie te spelen. Vooral het afzonderlijk laten veranderen van letters sluit aan bij mijn ideeën voor Y.M.C.A.

Ik wil nu onderzoeken hoe ik deze technieken kan gebruiken om steeds een andere letter nadruk te geven. Daarbij wil ik blijven letten op de leesbaarheid en het tempo van de beweging.

### Deep dive variabele fonts: voorbereiding

#### Zelfstandig inhalen

Omdat ik vanwege mijn gesprek met Walter niet bij de deep dive aanwezig kon zijn, haal ik deze zelfstandig in. Ik heb eerst de voorbereiding doorgenomen en aantekeningen gemaakt. Hierna ga ik aan de slag met de opdrachten om de uitleg zelf toe te passen.

#### Wat ik heb geleerd

Tijdens de voorbereiding heb ik geleerd dat een variabel font meerdere varianten in één bestand kan bevatten. Je kunt bijvoorbeeld het lettergewicht aanpassen en ook waarden tussen dun en dik gebruiken, zolang het font die ondersteunt.

Ook heb ik gekeken naar de verschillende assen van een lettertype. Daarmee kun je eigenschappen aanpassen, zoals gewicht, breedte of cursief. Sommige fonts hebben daarnaast speciale assen waarmee je bijvoorbeeld de lettervorm of een 3D-effect kunt veranderen. Niet ieder font heeft dezelfde mogelijkheden.

#### Een font koppelen en onderzoeken

Ik heb doorgenomen hoe ik een variabel font lokaal kan koppelen met @font-face. Daarbij geef ik aan welk bestand ik gebruik en welk gewichtsbereik het ondersteunt. Ook heb ik geleerd dat een cursieve variant soms een apart bestand nodig heeft.

Met Wakamai Fondue kan ik onderzoeken welke assen een font heeft en welke waarden daarbij horen. Zo kan ik eerst bekijken wat mogelijk is voordat ik ermee ga experimenteren in mijn CSS.

<img src="./assets/images-readme/aantekeningen-varfonts.png" alt="" />
Foto: Mijn aantekeningen voor de voorbereiding van de deepdive.

### deep dive interessante layouts

#### De deep dive zelfstandig inhalen

Omdat ik dinsdag niet bij de deep dive aanwezig kon zijn door citytrip, heb ik deze zelfstandig ingehaald. Ik heb de uitleg over interessante layouts doorgenomen en aantekeningen gemaakt. Hierbij heb ik gekeken hoe ik de technieken kan gebruiken voor mijn Y.M.C.A.-pagina.

#### Meeschalende tekst

Een onderdeel van de deep dive ging over tekst die zich aanpast aan de beschikbare ruimte. Met vw kan ik de lettergrootte laten reageren op de schermbreedte. Met clamp() kan ik daar een minimale en maximale grootte aan toevoegen.

Ook heb ik gekeken naar cqi. Hiermee reageert de tekst op de grootte van een container. Dat kan handig zijn wanneer een tekstvak smaller is dan het scherm, bijvoorbeeld als mijn coupletten naast de titel staan.

#### Spelen met de indeling

Daarnaast heb ik gekeken hoe ik met Grid en mediaqueries de indeling kan aanpassen aan verschillende schermgroottes. Op een breed scherm kan ik de titel naast de liedtekst plaatsen, terwijl deze op een telefoon boven de tekst kan staan.
Ik had dt ookal gebruikt in mijn website.

Met writing-mode kan ik de titel op zijn kant zetten. Dit geeft een andere compositie en biedt een nieuwe mogelijkheid om met mijn typografie te experimenteren. Ook kwam position: sticky aan bod, waarmee de titel tijdens het scrollen tijdelijk op dezelfde plek kan blijven staan.

#### Wat ik meeneem voor mijn ontwerp

Deze deep dive heeft mij meer mogelijkheden gegeven om mijn pagina vorm te geven. Ik wil vooral onderzoeken hoe ik een grote, meeschalende titel kan combineren met een interessante indeling van de coupletten.

Daarbij wil ik blijven controleren of de tekst leesbaar is en de layout ook op een kleiner scherm goed werkt. De technieken uit de deep dive kan ik gebruiken om mijn schetsen verder uit te werken en verschillende composities in de browser te vergelijken.

<img src="./assets/images-readme/aanekeningen-layouts.png" alt="" />

Foto: mijn aantekeningen over de Deep Dive.

<img src="./assets/images-readme/experimenten-layouts.png" alt="" />
Foto: Van mijn experimenten tijdens de Deep Dive.

### Van muziek naar typografie

### Luisteren naar nadruk in het liedje

Ik heb Y.M.C.A. opnieuw geluisterd (eigenlijk wel een paar keer😅) en gelet op welke woorden en zinnen de meeste nadruk krijgen. Daarbij heb ik gekeken naar herhaling en naar woorden die tijdens het zingen extra opvallen. Deze nadruk wil ik ook terug laten komen in de vormgeving van mijn tekst.

### De liedtekst verdelen in HTML

Daarna heb ik mijn liedtekst verdeeld in verschillende onderdelen. De coupletten en de twee delen van het refrein staan ieder in een eigen 'article'. Zo kan ik straks per onderdeel onderzoeken welke plaatsing en vormgeving het beste passen.

Woorden die ik wil benadrukken, heb ik tussen 'span'-elementen gezet. Dit zijn bijvoorbeeld ‘Young man’, ‘down’, ‘fun’ en ‘Y.M.C.A.’. Hiermee kan ik deze stukjes tekst apart vormgeven met CSS.

Ook heb ik in de titel de letters Y, M, C en A ieder in een eigen 'span' gezet. Daardoor kan ik met elke letter afzonderlijk spelen, zoals in mijn schetsen.

### Experimenteren met CSS

Nu de structuur staat, wil ik met CSS gaan experimenteren met de typografie. Ik wil onderzoeken wat verschillende groottes, diktes, afstanden en gedraaide woorden met de tekst doen.

Daarbij wil ik de vormgeving laten aansluiten bij de nadruk en het gevoel van het liedje. De woorden die tijdens het luisteren opvallen, kunnen ook op de pagina meer aandacht krijgen. Zo gebruik ik de muziek als uitgangspunt voor mijn ontwerp en kan ik stap voor stap kijken welke ideeën uit mijn schetsen goed werken in de browser.

## Na de les

### learning log en nieuwe schetsen

#### Learning log aanvullen

Na de les kon ik helaas niet bij de deep dive aanwezig zijn, omdat ik om 15.00 uur een gesprek met Walter had. De tijd tussen de les en het gesprek heb ik wel goed gebruikt om mijn learning log aan te vullen. Ik heb opgeschreven wat ik tijdens de les had gedaan en waar ik aan had gewerkt.

#### Aantekeningen opnieuw bekijken

Thuis heb ik mijn aantekeningen van vandaag nog een keer rustig bekeken. Met de uitleg over typografie in mijn achterhoofd keek ik opnieuw naar mijn eerste ideeën. Ik dacht dat ik het ook anders kon aanpakken en wilde onderzoeken of ik ontwerpen kon bedenken die beter bij de opdracht passen.

#### Zes nieuwe schetsen en wireframes

Daarom heb ik zes nieuwe schetsen en wireframes gemaakt. Hierbij heb ik het woord Y.M.C.A. als uitgangspunt genomen, omdat ik met deze letters wil spelen in mijn typografie.

Met deze nieuwe schetsen onderzoek ik verschillende manieren om de letters vorm te geven en te plaatsen. Ik wil kijken hoe ik van het woord een interessante compositie kan maken en hoe de vormgeving kan aansluiten bij het liedje.

#### Verder onderzoeken

De nieuwe schetsen zijn een aanvulling op mijn eerste tien ideeën. Door na de uitleg opnieuw te schetsen, kan ik verschillende mogelijkheden vergelijken en bewuster kiezen wat ik verder wil uitwerken. Mijn volgende stap is om te bekijken welk idee het beste bij de opdracht past en hoe ik dit kan vertalen naar HTML en CSS.
Ook wil ik een paar user testen doen om te kijken welke de mensen om mij heen het leukste vinden.

<img src="./assets/images-readme/6-ymca.jpg" alt="" />
Foto: Mijn 6 nieuwe schetsen voor de vormgeveing van Y.M.C.A.

### Feedback op mijn schetsen

#### Favorieten en het Y.M.C.A. gevoel

Ik heb mijn zes schetsen laten bekijken en feedback verzameld. De meeste reacties wijzen naar ontwerp 2, groot en klein. Dit ontwerp geeft volgens de testers het sterkste Y.M.C.A.gevoel. Doordat steeds een andere letter groter wordt, lijkt het alsof de letters één voor één worden uitgebeeld, net zoals bij het bekende dansje.

Ook ontwerp 3, de dansende letters, wordt positief ontvangen. De verschillende richtingen en bewegingen geven de letters een vrolijke uitstraling die goed aansluit bij muziek en dans. Daarnaast wordt de draaiende tekst als favoriet genoemd, omdat dit een speels effect geeft.

#### Sterke punten en aandachtspunten

Uit de feedback blijkt dat het verschil tussen grote en kleine letters bij ontwerp 2 een duidelijk aandachtspunt creëert. Het woord blijft herkenbaar, terwijl steeds een andere letter de aandacht krijgt.

Bij de dansende en draaiende letters spreekt vooral de beweging aan. Een aandachtspunt is wel dat het woord leesbaar moet blijven. Als alle letters tegelijk veel bewegen of draaien, kan het ontwerp druk worden. Ook moet er genoeg ruimte zijn om letters groter te maken zonder dat ze elkaar bedekken.

#### Wat ik met de feedback wil doen

Op basis van de reacties wil ik ontwerp 2 als uitgangspunt nemen. De vergelijking met het uitbeelden van de letters tijdens het dansje vind ik een sterke onderbouwing voor deze keuze.

Daarnaast wil ik onderzoeken of ik iets van de dansende of draaiende letters kan toevoegen. Ik wil eerst uitproberen of deze combinatie het ontwerp versterkt en of het woord goed herkenbaar blijft.

Zodra ik een werkende versie heb, wil ik opnieuw testen. Met de schetsen heb ik vooral reacties op het idee verzameld. In de browser kan ik ook testen hoe de daadwerkelijke beweging overkomt en of het tempo prettig is.

## woensdag 7 oktober

### Weer aansluiten bij de lessen

Tijdens de les merkte ik dat ik door mijn afwezigheid best veel had gemist. Daardoor moest ik weer even uitzoeken waar we mee bezig waren en wat er van mij werd verwacht voor deze sprint.

Ik ga kijken welke uitleg en opdrachten ik nog moet inhalen. Zo kan ik beter bepalen waar ik moet beginnen en stap voor stap weer bij komen. Mijn aantekeningen kan ik hierbij gebruiken om de uitleg rustig terug te lezen.

### retrospectief afmaken

Aan het begin van de les kregen we eerst tijd om rustig zelfstandig te werken. Dit moment heb ik gebruikt om mijn retrospectief verder af te maken. Ik had hier in het vliegtuig al aan gewerkt en heb tijdens de les de laatste onderdelen afgerond.
Na een klein halfuurtje begon de les echt.

<img src="./assets/images-readme/retroaf.jpg" alt="" />

Foto: mijn retrospectief af gemaakt.

### Uitleg van Diederik over typografie

Als eerste heb ik geluisterd naar de uitleg van Diederik over typografie. Tijdens zijn uitleg heb ik aantekeningen gemaakt. Het ging niet alleen over het kiezen van een lettertype, maar ook over hoe je tekst vormgeeft met grootte, dikte, afstand en plaatsing.

Onderwerpen die aan bod kwamen waren visuele hiërarchie, ritme, contrast en samenhang. Met hiërarchie kun je duidelijk maken welke informatie het belangrijkste is. Met herhaling kun je ritme creëren en met contrast kun je bepaalde woorden of onderdelen laten opvallen.

Ook ging de uitleg over het gebruik van een grid. Een grid geeft structuur en helpt om tekst en andere onderdelen uit te lijnen. Binnen die structuur kun je vervolgens experimenteren, bijvoorbeeld door woorden te draaien of onderdelen anders te plaatsen. Wat ik hiervan meeneem, is dat een duidelijke basis juist ruimte kan geven om met het ontwerp te spelen.

<img src="./assets/images-readme/typografie-diederik.png" alt="" />
Foto: aantekeningen over de uitleg van Diederik.

### Een liedje kiezen: YMCA

Na de uitleg heb ik het liedje YMCA gekozen voor mijn opdracht. Vanuit dit liedje ben ik begonnen met het bedenken van ideeën voor een typografisch ontwerp.

Bij deze opdracht kijk ik naar hoe ik een zin visueel kan vormgeven. Het gaat dus niet alleen om de tekst zelf, maar ook om wat de vormgeving eraan toevoegt. Door letters anders te plaatsen, groter te maken of een andere richting te geven, kan dezelfde zin steeds anders overkomen.

### Een nieuwe projectmap aanmaken

Voor deze opdracht heb ik een nieuw mapje aangemaakt met de bestanden voor mijn HTML, CSS en het lettertype. Daarmee heb ik een begin gemaakt aan de technische basis van mijn project.

In de HTML komt de inhoud en structuur van de pagina. In de CSS kan ik vervolgens werken aan de vormgeving, zoals de tekstgroottes, afstanden en plaatsing. Het lettertype hebben we gekregen en alleen deze mogen we gebruiken dus hiermee moet ik goed gaan experimenteren

### Tien schetsen met verschillende ideeën

Daarna heb ik tien schetsen gemaakt met ideeën om één zin uit het liedje vorm te geven. Ik heb eerst verschillende mogelijkheden onderzocht, zodat ik meerdere richtingen had om uit te kiezen.

In de schetsen heb ik gekeken naar de plaatsing, grootte en richting van de letters. Hiermee kon ik onderzoeken wat er gebeurt als ik de tekst op verschillende manieren indeel.

Het schetsen hielp mij om mijn ideeën zichtbaar te maken zonder meteen alles in code te hoeven bouwen. Zo kan ik eerst de ontwerpen vergelijken en daarna bepalen welke ideeën ik verder wil uitwerken.

<img src="./assets/images-readme/10schetsenYMCA.jpg" alt="" />
Foto: Mijn 10 schetsen voor de vormgeveing voor Y.M.C.A.

### Live coderen met Justus

Na het schetsen ging Justus live coderen. Tijdens zijn uitleg heb ik opnieuw aantekeningen gemaakt. Zo kan ik later rustig terugkijken welke code hij gebruikte en hoe de verschillende onderdelen samenwerken.

Bij het voorbeeld ging het onder andere over het plaatsen van tekst met CSS Grid en het draaien of vervormen van onderdelen met transforms. Ook heb ik aantekeningen gemaakt over CSS-variabelen en het instellen van een lettertype.

De uitleg liet zien hoe je met HTML en CSS een typografische compositie kunt opbouwen. Mijn aantekeningen kunnen mij helpen wanneer ik mijn eigen schetsen ga vertalen naar een ontwerp in de browser.

### Wat ik meeneem en mijn volgende stap

Wat ik uit deze les meeneem, is dat typografie meer is dan alleen een mooi lettertype kiezen. Ook de grootte, plaatsing en ruimte rondom tekst hebben invloed op hoe een ontwerp overkomt.

Daarnaast heb ik gezien dat structuur en experimenteren samen kunnen gaan. Een grid kan houvast geven, terwijl je binnen het ontwerp toch speelse keuzes maakt.

Mijn volgende stap is om mijn schetsen te bekijken en te kiezen welke ideeën ik verder wil uitwerken. Daarna wil ik onderzoeken hoe ik die met HTML en CSS kan bouwen. Tegelijkertijd ga ik kijken wat ik nog heb gemist, zodat ik gericht kan werken aan het inhalen van de uitleg en opdrachten.

### Check-out 7 oktober

1. Waarom is het goed om een grid in je ontwerp toe te passen? Noem een reden voor de ontwerper en een voor de bezoeker.

Voor de ontwerper geeft een grid houvast bij het plaatsen en uitlijnen van tekst en afbeeldingen. Hierdoor kan ik makkelijker een samenhangende indeling maken.

Voor de bezoeker zorgt een grid voor overzicht. Informatie staat op herkenbare plekken, waardoor de bezoeker makkelijker door de pagina kan kijken en informatie kan vinden.

2. Noem drie manieren om chaos in je ontwerp te voorkomen.

Een grid gebruiken, zodat onderdelen goed uitgelijnd zijn.

Een duidelijke visuele hiërarchie maken met bijvoorbeeld grotere koppen en kleinere tekst. Zo is duidelijk wat het belangrijkste is.

Rust en samenhang creëren door voldoende witruimte te gebruiken en kleuren, lettertypes en stijlen consequent toe te passen.

3. Hoeveel gekkigheid moet er in je werk zitten?

Ik vind het leuk als mijn werk iets speels en onverwachts heeft, zodat het persoonlijk en herkenbaar wordt. Hoeveel gekkigheid past, hangt af van het doel en de doelgroep. Het mag de aandacht trekken, maar de tekst moet leesbaar blijven en de bezoeker moet begrijpen hoe het ontwerp werkt. Ik wil dus ruimte houden om te experimenteren, terwijl de basis duidelijk blijft.

## voorbereiding voor woensdag 7 oktober

Van 1 tot en met 6 oktober was ik afwezig vanwege een geplande verrassingsstedentrip. Omdat ik laat thuiskwam, heb ik minder tijd gehad om de les van woensdag voor te bereiden.

Wel heb ik in het vliegtuig gewerkt aan mijn retrospectief voor vrijdag. Ik had de bladen hiervoor in het hotel laten printen, zodat ik onderweg verder kon werken. Tijdens de les heb ik de laatste onderdelen afgemaakt.

<img src="./assets/images-readme/retrospectief.png" alt="" />
Foto: Mijn retro spectief.

## Werk inhalen

Deze week wil ik zoveel mogelijk werk inhalen, zodat ik weer bij ben. Daardoor kunnen sommige onderdelen in mijn learning log bij een andere dag staan dan de dag waarop de opdracht oorspronkelijk gepland was.

# Sprint 2:

## i.v.m. een geplande verassings stedentrip ben ik afwezig van 1 tot 6 oktober.

## wat neem ik mee naar de volgende sprint

In de volgende sprint wil ik vooral zorgen dat mijn website goed werkt en eruitziet op een telefoonscherm. Ik merk dat nog niet alle onderdelen goed passen op een klein scherm. Doordat ik de teksten van mijn links langer en duidelijker heb gemaakt, vallen sommige gifjes eronder weg. Ik wil onderzoeken hoe ik dit kan oplossen.

Daarnaast wil ik het lettertype van mijn alinea’s aanpassen. Dit ben ik deze sprint vergeten, maar ik wil hier alsnog naar kijken om de tekst prettiger leesbaar te maken.

Ook wil ik met JavaScript de keuze voor de lichte of donkere weergave bewaren. Zo hoeven bezoekers hun voorkeur niet opnieuw in te stellen wanneer ze naar een andere pagina gaan.

Verder wil ik mijn website blijven uitbreiden en de vormgeving verbeteren. Ik wil ook onderzoeken hoe ik meer persoonlijke elementen kan toevoegen, zodat de website nog beter bij mij past. Hoe ik dat precies ga doen, weet ik nog niet. Daarmee wil ik in de volgende sprint experimenteren.

## Woensdag 30 september

### Mijn privacyonderdeel laten testen

Mijn website is nog niet perfect, maar vanwege tijdsdruk heb ik besloten de vormgeving voorlopig zo te laten. Ik wilde wel controleren of anderen mijn privacyonderdeel konden vinden en gebruiken. Daarom heb ik mensen in mijn omgeving gevraagd mijn website te testen, met extra aandacht voor de pop-up.

Ik heb iedereen drie vragen gesteld:

1. Kun je vinden wat er met jouw gegevens gebeurt?

2. Kun je meer informatie vinden over Digitaal Tuintje?

3. Kun je terugkeren naar de hoofdpagina?

Daarnaast heb ik gevraagd of de informatie en de bediening duidelijk waren. Gelukkig kon iedereen de drie taken zonder moeite uitvoeren. Dit geeft mij vertrouwen dat de privacyinformatie vindbaar is en dat bezoekers hun weg terug kunnen vinden.

Er zijn nog dingen die ik aan de vormgeving wil verbeteren, maar ik ben blij dat dit onderdeel tijdens deze test goed te gebruiken was.

#### De vormgeving aanpassen aan kleinere schermen

Toen ik mijn website op mijn telefoon bekeek, ontdekte ik dat het gifje over de tekst heen viel. Hierdoor was de tekst minder goed leesbaar. Ik heb daarom gekeken of ik hetzelfde principe kon gebruiken als bij het aanpassen van mijn kolommen aan de schermgrootte.

Dit is gelukt: op een klein scherm wordt het gifje nu verborgen. Wanneer er genoeg ruimte is, verschijnt het naast de inhoud. Zo blijft de tekst op mijn telefoon goed leesbaar en is het gifje op grotere schermen wel zichtbaar.

Hetzelfde principe heb ik toegepast op mijn navigatie. Op kleinere schermen is de ruimte tussen de links kleiner, zodat de navigatie beter op het scherm past.

<img src="./assets/images-readme/verschilgenkscherm.png" alt="" />
Foto: aanpassingen voor een groot en klein scherm

#### Experimenteren met een koekje dat wordt opgegeten

Ik wilde onderzoeken of het leuk was om een gifje toe te voegen waarin een koekje langzaam wordt opgegeten. Dit leek mij een speelse toevoeging die bij het privacyonderdeel van mijn website past.

Tijdens het uitwerken liep ik tegen een vraag aan: hoe kon ik met CSS alleen dit gifje aanpassen, zonder dat de andere gifjes op mijn website ook veranderden? Ik had zelf al bedacht welke vormgeving ik wilde en welke code ik daarvoor wilde gebruiken. Alleen het selecteren van deze specifieke afbeelding lukte mij nog niet.

Vanwege tijdsdruk heb ik ChatGPT om hulp gevraagd. Ik heb mijn code en mijn gewenste resultaat meegestuurd en gevraagd hoe ik de CSS alleen op dit gifje kon laten toepassen. Mijn hulpvraag ging dus specifiek over de selector waarmee ik de afbeelding kon bereiken.

Chatgpt prompt:
Ik heb op mijn privacypagina een GIF van een gehaakt koekje staan. Ik wil dit GIFje kleiner maken en rechtsonder in beeld plaatsen. Het moet op deze plek blijven staan wanneer iemand door de pagina scrolt.

De andere afbeeldingen en gifjes op mijn website en in mijn andere HTML-bestanden mogen niet veranderen.

position: fixed;
right: 1em;
bottom: 1em;
width: 10em;
height: auto;
margin: 0;

Voor deze opdracht mag ik geen class gebruiken waardoor ik nu even niet weet hoe ik dit kan doen.

Dit is de code die ik al gemaakt heb.
Ik moet alleen kijken hoe ik het kan koppelen aan alleen dit ene gifje.

Antwoord: main > img[src*="koekje-wordt-opgegeten"]

#### De koekjesafbeeldingen aanpassen

Ik ben begonnen met het aanpassen van mijn oude koekjesafbeeldingen. Ik wilde het woord ‘Privacy’ in het koekje verwerken, alsof het erop gehaakt is. Zo past de tekst beter bij de uitstraling van mijn haakwebsite en wordt duidelijk waarvoor het koekje bedoeld is.

Daarna heb ik het koekje met het hapje een paar keer aangepast. Deze afbeelding verschijnt wanneer de privacyinformatie geopend is. Ik wilde hier ook een kruisje aan toevoegen, om duidelijker aan te geven dat bezoekers via het koekje de informatie weer kunnen sluiten.

Ik heb verschillende versies gemaakt om te kijken hoe ik het kruisje mooi en herkenbaar in de afbeelding kon verwerken. Hierbij wilde ik de gehaakte uitstraling behouden, terwijl de functie van het koekje duidelijker werd.

Hieronder laat ik de oude afbeeldingen en de verschillende nieuwe versies zien als bewijs van mijn proces.

<img src="./assets/images-readme/oudennieuw.png" alt="" />
Foto: oude afbeeldingen en nieuwe afbeeldingen

### De vormgeving verder verbeteren

Ik ben nu tevreden met de informatie op mijn privacypagina. De onderwerpen staan erop en bezoekers kunnen zelf kiezen welke uitleg ze willen openen. Daarom ga ik nu verder kijken naar de vormgeving.

### Meer informatie toeveogen

#### Een aparte privacypagina maken

Ik heb mijn privacyonderdeel uitgebreid met een link naar een nieuwe pagina: privacy.html. In de pop-up staat nu ‘Meer informatie’, zodat bezoekers zelf kunnen kiezen of ze de uitgebreidere uitleg willen lezen.

Op de nieuwe pagina heb ik de informatie verdeeld over uitklapbare onderwerpen. Hiervoor gebruik ik 'details' en 'summary', zoals behandeld in de deep dive. De vraag blijft zichtbaar en de uitleg verschijnt pas wanneer je het onderwerp opent. Zo krijgt de bezoeker niet meteen een lange lap tekst te zien.

Ik ben begonnen met ‘Wat zijn cookies?’ en heb daarna uitleg toegevoegd over het privacykoekje, het laden van mijn lettertypes en de gegevensverwerking door GitHub Pages. Bij GitHub Pages heb ik ook een link naar de officiële uitleg geplaatst, zodat bezoekers de bron kunnen bekijken.

De pagina gebruikt dezelfde vormgeving als de rest van mijn website, inclusief de keuze voor licht en donker. Daarnaast heb ik een link ‘Terug naar de hoofdpagina’ toegevoegd, zodat bezoekers makkelijk terug kunnen gaan.

Tijdens het uitwerken heb ik ook met het toetsenbord getest. Met Tab heb ik de uitklapbare onderdelen geselecteerd en gekeken hoe ze geopend en gesloten worden. De zichtbare focusrand laat zien welk onderdeel op dat moment geselecteerd is.

<img src="./assets/images-readme/meerinfo.png" alt="" />
Foto: Het verloop van het toevoegen van meer informatie

<img src="./assets/images-readme/tabmeerinfo.png" alt="" />
Foto: testen of je met tab open en dicht kon klappen

#### Meer ademruimte

Ik ben verdergegaan met de indeling van het tekstvlak in mijn pop-up. De tekst stond eerst dicht tegen de rand, waardoor het geheel nog niet prettig leesbaar was. Met display: grid heb ik de titel en alinea’s onder elkaar gezet. Met gap heb ik ruimte tussen deze onderdelen toegevoegd.

Daarna heb ik verschillende waarden voor de margin rondom de titel uitgeprobeerd: 3em, 1.5em en 0.75em. Bij 3em ontstond veel lege ruimte en werd de titel over meer regels verdeeld. Door de margin steeds kleiner te maken, kon ik goed vergelijken wat dit met de vormgeving deed. Uiteindelijk heb ik gekozen voor 0.75em rondom de titel en 1em rondom de alinea’s.

Hierbij gebruik ik margin om de tekst ademruimte te geven, niet om het koekje of de pop-up op een bepaalde plek te positioneren. Ook heb ik met line-height: 1.5 meer ruimte tussen de tekstregels gemaakt.

Door de waarden aan te passen en het resultaat telkens in de browser te bekijken, begrijp ik beter hoe de ruimte rondom tekst invloed heeft op de leesbaarheid en de grootte van mijn pop-up.

<img src="./assets/images-readme/testenmetmaat.png" alt="" />
Foto: Testen welke waardes ik het beste vond

#### CSS ordenen en de vormgeving verder aanpassen

I heb mijn CSS voor het privacyonderdeel opnieuw georganiseerd. Alle bijbehorende code staat nu bij elkaar onder MARK: Privacyinformatie. Bij ieder stukje heb ik een korte opmerking gezet, zodat ik later makkelijker kan terugvinden waarvoor de code bedoeld is.

Daarna heb ik de vormgeving verder aangepast. Het koekje blijft rechtsonder in beeld staan, terwijl alleen het tekstvlak een gekleurde achtergrond, rand en afgeronde hoeken krijgt. Hierdoor staat de afbeelding los van het informatievak.

Verder heb ik het standaard driehoekje van 'summary' in Safari verborgen en het koekje en de knoptekst onder elkaar gecentreerd. Voor het geopende bericht heb ik een breedte en een maximale breedte ingesteld. Daarnaast heb ik de titelgrootte en de regelafstand van de alinea’s aangepast.

Door mijn CSS zo te ordenen, krijg ik meer overzicht en begrijp ik beter welke regels de plaatsing, vormgeving en verschillende toestanden bepalen. Hieronder voeg ik een screenshot toe van deze tussenstap. De uitwerking is nog niet perfect maar het is een begin.

<img src="./assets/images-readme/tussenstand.png" alt="" />
Foto: Nette css en begin aan een mooie vormgeving van de pop-up.

#### Zelf experimenteren met wisselende afbeeldingen

Ik wilde zelf uitzoeken hoe ik twee afbeeldingen kon gebruiken, terwijl er steeds maar één zichtbaar is. Mijn idee was om een heel koekje te tonen wanneer de privacyinformatie gesloten is en een koekje met een hapje eruit wanneer deze openstaat.

Daarvoor heb ik een tweede afbeelding toegevoegd aan mijn HTML. Vervolgens heb ik in CSS geprobeerd deze apart te selecteren met img:nth-of-type(2). Met display: none heb ik de tweede afbeelding standaard verborgen. Wanneer het details-element openstaat, verberg ik de eerste afbeelding met img:first-of-type en laat ik de tweede juist zien.

Voor het zichtbaar maken heb ik zelf display: block geprobeerd. Ik dacht dat dit misschien zou werken als tegenhanger van display: none, en tijdens het testen bleek dat inderdaad te werken. Bij het openen verschijnt nu het koekje met het hapje; bij het sluiten komt het hele koekje weer terug.

Ik wist vooraf niet zeker of mijn aanpak zou werken. Door kleine aanpassingen te doen en steeds het resultaat in de browser te bekijken, heb ik zelf een werkende oplossing gevonden. Ik weet niet of dit de juiste manier is maar het werkt.

<img src="./assets/images-readme/test2cookies.png" alt="" />
Foto: De test of ik 2 afbeeldingen er in kon zetten.

#### afbeedling toeveoegen

Ik ben begonnen met het toevoegen van een afbeelding van een gehaakt koekje aan mijn privacyonderdeel. Dit past bij de stijl en het haakthema van mijn website. Toen ik de afbeelding voor het eerst toevoegde, was deze alleen veel te groot en bedekte het koekje een groot deel van de pagina.

Daarna heb ik in CSS verschillende afmetingen uitgeprobeerd. Ik heb steeds in de browser gekeken hoe het koekje eruitzag, zowel wanneer de privacyinformatie gesloten was als wanneer deze openstond. Uiteindelijk heb ik gekozen voor een breedte van 6em, met height: auto, zodat de afbeelding haar oorspronkelijke verhoudingen behoudt.

Ook heb ik de plaatsing van het koekje en de tekst ‘Privacy’ aangepast. Deze staan nu gecentreerd onder elkaar. Daarnaast heb ik de titel in het geopende informatievak kleiner gemaakt en de ruimte eromheen aangepast. Zo heb ik stap voor stap gezocht naar een formaat en indeling die bij mijn website passen.

Bij de verschillende stukjes CSS zet ik opmerkingen voor mezelf. Daarin schrijf ik kort waarvoor de code bedoeld is. Hierdoor kan ik later makkelijker terugvinden wat ik moet aanpassen en begrijp ik beter wat iedere regel doet.

Tot slot heb ik met de Tab-toets gekeken hoe het privacyonderdeel eruitziet wanneer het toetsenbordfocus krijgt. Er verschijnt dan een rand om het aanklikbare onderdeel. Daardoor kan ik zien waar ik ben op de pagina, ook zonder mijn muis te gebruiken.

<img src="./assets/images-readme/eersteopzetafbeelding.png" alt="" />
Foto: De eerste aanpassingen van mijn afbeelding

### Begin maken aan de pop-up in HTML

#### Kleurvarianten vergelijken en feedback verzamelen

Ik heb verder gewerkt aan de vormgeving van mijn privacy-pop-up. Eerst gebruikte ik een donkere achtergrond voor de pop-up op de donkere pagina en een lichte achtergrond op de lichte pagina. Dit paste bij de website, maar ik vond dat de pop-up daardoor te weinig opviel.

Daarom heb ik de kleuren omgedraaid: een lichte pop-up op de donkere pagina en een donkere pop-up op de lichte pagina. Hierdoor onderscheidt het privacyonderdeel zich duidelijker van de rest van de website.

Om mijn keuze te onderzoeken, heb ik twee mensen uit mijn omgeving de varianten op de donkere pagina laten vergelijken. Irene vond dat de lichte pop-up het meest opviel en dat de donkere variant meer wegviel in de achtergrond. Laura vond de donkere variant mooier en rustiger voor haar ogen, maar gaf ook aan dat ze voor de lichte variant zou kiezen als het onderdeel moest opvallen.

Deze feedback liet mij zien dat een rustige uitstraling en zichtbaarheid niet altijd tot dezelfde voorkeur leiden. Omdat ik wil dat bezoekers de privacyinformatie makkelijk kunnen vinden, heb ik de omgedraaide kleuren gehouden.

<img src="./assets/images-readme/usertestkleurenpopup.png" alt="" />
Foto: de user test

<img src="./assets/images-readme/gekozenkleuren.png" alt="" />
Foto: de gekozen kleuren.

#### Privacyinformatie toevoegen aan mijn website

k heb een eerste versie van mijn privacyonderdeel gemaakt met HTML en CSS. Hiervoor heb ik een 'aside gebruikt met daarin 'details' en 'summary'. De bezoeker ziet eerst alleen de tekst ‘Privacy’ en kan deze aanklikken om de uitleg over gegevensverwerking te openen. Zo blijft de informatie beschikbaar zonder dat deze meteen helemaal in beeld staat.

Met CSS heb ik dit onderdeel rechtsonder in het scherm geplaatst. Door position: fixed blijft het op dezelfde plek staan tijdens het scrollen. Met right en bottom heb ik ruimte tot de schermrand ingesteld. De z-index zorgt ervoor dat het onderdeel boven elementen met een lagere stapelvolgorde kan verschijnen.

Daarnaast heb ik onderzocht hoe ik het privacyonderdeel een herkenbare naam kan geven voor een schermlezer. Hiervoor heb ik de uitleg van NL Design System over naam, rol en waarde gebruikt. Bij het 'aside' heb ik aria-label="Privacyinformatie" toegevoegd. Hiermee krijgt dit aanvullende onderdeel een naam voor gebruikers van een schermlezer. De 'summary' heeft al de zichtbare tekst ‘Privacy’ als naam en heeft daarom geen extra aria-label nodig.

Voor het benoemen van een 'aside' heb ik ook het voorbeeld van html5doctor over aanvullende paginaonderdelen geraadpleegd. Door deze bronnen begrijp ik beter hoe HTML-elementen en toegankelijke namen samenwerken.

Bronnen:
[html5doctor](https://html5doctor.com/element-index/#aside)
[NL Design System](https://nldesignsystem.nl/wcag/4.1.2/?utm)

<img src="./assets/images-readme/nlds2.png" alt="" />
--- 
<img src="./assets/images-readme/html5doctor.png" alt="" />
Foto's: van de websites

<img src="./assets/images-readme/aria-label.png" alt="" />
Foto: van mijn code die ik heb aangepast met de nieuwe informatie.

<img src="./assets/images-readme/privacysticky.png" alt="" />
Foto: verschillende foto's waarbij zichtbaar is dat die blijft plakken op de website.

### Afbeeldingsbeschrijvingen toevoegen en testen met Voiceover.

Om mijn website toegankelijker te maken, heb ik eerst per afbeelding gekeken of deze informatie toevoegt of vooral bedoeld is als decoratie. Het rollende bolletje wol en de GIF’s van de diertjes zorgen voor sfeer, maar voegen op die plek geen belangrijke informatie toe. Daarom heb ik hiervoor bewust een lege alt-tekst gebruikt: alt="". Zo hoeft een schermlezer deze afbeeldingen niet apart voor te lezen.

Voor de andere afbeeldingen heb ik zo duidelijk mogelijk beschreven wat erop te zien is. Bij de foto’s heb ik bijvoorbeeld de herkenbare kenmerken van de diertjes genoemd. Bij de afbeeldingen in de haakpatronen heb ik beschreven welke onderdelen klaarliggen of welke handeling wordt uitgevoerd. Daarbij heb ik geprobeerd de beschrijvingen kort te houden en vooral informatie te geven die bij het patroon past.

Daarna heb ik mijn website op mijn laptop getest met VoiceOver. Ik heb geluisterd hoe de teksten, links en afbeeldingen werden voorgelezen. Tijdens het testen hoorde ik mijn toegevoegde afbeeldingsbeschrijvingen terug. Hierdoor kon ik controleren of de beschrijvingen begrijpelijk waren zonder naar de foto te kijken.

Het navigeren met VoiceOver vond ik soms nog lastig. Vooral het verdergaan binnen de pagina en het verplaatsen van de banner naar de hoofdinhoud kostte moeite.

Door deze test heb ik geleerd dat toegankelijkheid niet alleen gaat over hoe mijn website eruitziet, maar ook over hoe iemand de inhoud kan begrijpen en bedienen zonder die te zien. Hieronder voeg ik screenshots van mijn VoiceOver-test toe als bewijs.

<img src="./assets/images-readme/voiceovertest.png" alt="" />
Foto: van mijn test dat ik mijn website laat voor lezen met behulp van de Voiceover.

### De taal en navigatie toegankelijker maken

Als eerste heb ik gekeken welke onderdelen van mijn code ik kon verbeteren. Ik heb de taal van mijn pagina’s aangepast van lang="en" naar lang="nl", omdat mijn website in het Nederlands geschreven is. Daarmee geef ik aan welke taal de inhoud heeft, zodat een screenreader de juiste uitspraak kan gebruiken.

Ook heb ik de omschrijving van de links aangepast. Bijv. 'terug' ben ik veranderd naar 'terug naar de home pagina'. en 'patroon' heb ik aangepast naar 'bekijk het haakpatroon van Flappie'

Tijdens mijn onderzoek kwam ik bij de uitleg van NL Design System over naam, rol en waarde. Daar las ik dat je met aria-current="page" in de navigatie kunt aangeven op welke pagina de bezoeker zich bevindt. Een screenreader kan die informatie bij de link voorlezen.

Ik heb dit toegevoegd aan de navigatielink van de huidige pagina. Op de homepage hoort het bijvoorbeeld bij ‘Home’. Op een andere pagina staat het bij de link naar die pagina. Zo krijgt de bezoeker meer informatie over waar die zich op mijn website bevindt.

Dit was een aanvulling op wat we in de les hebben behandeld. Door verder te onderzoeken, heb ik geleerd dat kleine aanpassingen in HTML kunnen helpen om mijn website begrijpelijker te maken voor mensen die een screenreader gebruiken.

Bron: [NL Design System](https://nldesignsystem.nl/wcag/4.1.2/?utm)

<img src="./assets/images-readme/nlds.png" alt="" />
Foto: van de website.
---

<img src="./assets/images-readme/aria-current.png" alt="" />
Foto: van mijn code die ik heb aangepast aan de hand van de nieuwe informatie.

### niet aanwezig bij de les

Omdat ik mijn werk woensdag al moet inleveren omdat ik daarna weg ben, redde ik het niet om naar de les te gaan en heb ik er voor gekozen om thuis verder te werken aan alle opdrachten.

Ik wil eerst kijken of ik mijn website zo kan maken dat je hem kan gebruiken met een Voiceover. Daarna wil ik kijken of ik mijn pop-up kan maken over prvaicy.

## Voorbereiding voor woensdg 30 september

### Mijn website testen zonder muis

Na de Deep Dive over buttons en states wilde ik controleren of mijn website ook zonder muis te gebruiken is. Daarom heb ik in mijn CSS een :focus-visible-regel toegevoegd aan mijn links. Deze regel geeft een duidelijke rand aan de link die op dat moment met het toetsenbord is geselecteerd. Zo kan een bezoeker zien waar die zich op de pagina bevindt.

Daarna heb ik mijn website getest door mijn muis weg te leggen en met het toetsenbord door de pagina te gaan. In Chrome kon ik met Tab langs de links navigeren en met Enter een pagina openen. Ook heb ik gecontroleerd of ik met Shift + Tab weer terug kon gaan.

In Safari dacht ik eerst dat het niet werkte, omdat ik met alleen Tab niet langs de links ging. Toen ontdekte ik dat ik daar Option + Tab moest gebruiken. Daarna kon ik ook in Safari de links selecteren en de focusrand zien. Bij mijn keuze tussen licht en donker ontdekte ik nog iets nieuws: omdat dit radioknoppen in één groep zijn, wissel je daartussen met de pijltjestoetsen. Met Tab ga je daarna verder naar het volgende onderdeel.

Door dit te testen heb ik geleerd dat het toevoegen van een focusstijl pas de eerste stap is. Ik moet ook zelf controleren of alle onderdelen bereikbaar zijn, of ik steeds kan zien waar de focus staat en of de bediening in verschillende browsers werkt.

<img src="./assets/images-readme/zondermuistest.png" alt="" />
Foto: van mijn test dat het bruikbaar is zonder muis.

### Mijn knoppen en links verbeteren

Ik had het gevoel dat mijn code voor de knoppen op mijn website niet helemaal goed was. Daarom ben ik eerst begonnen met de Deep Dive Buttons, states en selectors. Ik hoopte daarin een antwoord te vinden op mijn vraag. De Deep Dive ging vooral over de verschillende toestanden van interactieve elementen, maar hielp mij ook om beter na te denken over het verschil tussen een button en een link.

Bij het bekijken van mijn eigen code zag ik dat ik voor de teruglink een 'button' binnen een 'a' had gezet. Dat voelde voor mij al niet logisch: de link zorgt er namelijk voor dat je naar een andere pagina gaat, terwijl een button bedoeld is om een handeling uit te voeren. Ik heb de button daarom uit de HTML gehaald en alleen de link laten staan.

Toen ik dat voor het eerst deed, zag de teruglink er ineens anders uit. Op de eerste screenshot is te zien hoe de oude code een klein wit knopje binnen een grotere bruine vorm liet zien. Nadat ik de 'button' weghaalde, moest ik ook mijn CSS aanpassen. De vormgeving stond namelijk nog bij button en werd daardoor niet meer op de link toegepast. Ik heb de selector veranderd naar a, waarna de link er weer uitzag zoals ik wilde en nog steeds werkte.

Daarna heb ik ook mijn andere navigatielinks bekeken om te controleren of ik daar het juiste HTML-element gebruikte. Hierdoor begrijp ik nu beter dat ik eerst moet bepalen wat een element doet en daarna pas met CSS bepaal hoe het eruitziet.

<img src="./assets/images-readme/oudecode-29-9.png" alt="" />
Foto: mijn oude HTML code.
---

<img src="./assets/images-readme/knopnabuttonweg.png" alt="" />
Foto: het uiterlijk vóór de aanpassing in de css

### Deep Dive: Buttons, states en selectors

Tijdens deze Deep Dive heb ik geleerd dat je met CSS ook de interactie van een website vormgeeft. Een link of knop kan er anders uitzien wanneer iemand er met de muis overheen gaat, er met het toetsenbord naartoe navigeert of hem indrukt. Zo krijgt de bezoeker feedback op wat die doet.

Ik leerde eerst het verschil tussen een link en een button. Een link brengt je naar een andere pagina of bron, terwijl een button een handeling uitvoert. Mijn navigatie met Home, Flappie, Vonkje en Simba bestaat uit links, omdat je daarmee naar andere pagina’s gaat. Ik heb de vier states uit de Deep Dive daarom op deze navigatielinks uitgeprobeerd.

De normale vormgeving heet de default state. Met :hover verander ik de vormgeving als de muis boven een link staat. Met :focus-visible laat ik duidelijk zien welke link iemand met de Tab-toets heeft geselecteerd. Dat vind ik belangrijk, omdat de navigatie ook zonder muis te gebruiken moet zijn. Met :active geef ik feedback op het moment dat iemand een link indrukt.

Ik heb de verschillende states getest met mijn muis en toetsenbord. Vooral het effect van :active vind ik leuk: de link wordt tijdens het indrukken heel even kleiner, alsof je hem echt indrukt. Dit effect wil ik ook toepassen in mijn eigen website, omdat het de interactie duidelijker en leuker maakt.

In het tweede deel van de Deep Dive heb ik geleerd hoe 'details' en 'summary' werken. Daarmee kun je informatie laten uitklappen zonder JavaScript. Ook een summary kan een normale, focus-, hover- en active-toestand krijgen. Met details:open kun je daarnaast de vormgeving veranderen zodra de informatie is uitgeklapt. Dit kan ik later gebruiken om extra uitleg overzichtelijk aan te bieden, zonder meteen een lange lap tekst te tonen.
Dit wil ik toepassen in mijn cookie over privacy.

<img src="./assets/images-readme/4states.png" alt="" />
Foto: mijn code met de 4 states.

### Laatste feedback en mijn keuze

Ik heb de drie nieuwe varianten opnieuw aan mensen in mijn omgeving laten zien. Ik vroeg welke zij het beste vonden en waarom. Zo kon ik zien of de combinatie van het koekje, het hapje en het informatiebericht duidelijker was geworden.

Lars koos variant 2, omdat de andere twee hem minder aanspraken. De vijf anderen kozen allemaal variant 3, de zachte tekstvorm. Desirée vond dat het koekje en het bericht daarin één geheel vormen. René vond het de mooiste combinatie en zei dat het bericht er vloeiend uitkomt. Annet vond deze variant het leukst en duidelijk. Irene zei dat het echt lijkt alsof het bericht uit het koekje komt. Laura vond vooral sterk dat alles als één geheel oogt.

Die reacties sluiten aan bij wat ik met het ontwerp wilde bereiken. Ik wilde dat het informatiebericht niet als een los kaartje naast het koekje staat, maar er zichtbaar uit voortkomt. Daarom kies ik variant 3 om verder uit te werken. De vorm loopt door van het gehaakte koekje naar het bericht, terwijl het losse hapje boven op het bericht terugkomt.

Deze feedback helpt mij bij mijn keuze voor de vormgeving. Bij de verdere uitwerking wil ik ook controleren of bezoekers zonder uitleg begrijpen dat ze op het koekje kunnen klikken om privacyinformatie te openen. De foto van mijn feedbackaantekeningen voeg ik hieronder toe.

<img src="./assets/images-readme/feedback-cookie3.jpg" alt="" />
Foto: de feedback die ik heb gekregen over de 3 laatste variaties.

## Na de les van maandag 28 september

### Van feedback naar nieuwe ontwerpvarianten

Op maandag heb ik de feedback op mijn ideeën voor de privacyinformatie verwerkt. Ik heb de suggesties van Lars en Isabeau gecombineerd: een gehaakt koekje dat na een klik een hapje mist, met een informatiekaartje dat via draadjes aan het koekje vastzit. Het losse hapje komt in sommige varianten terug op het kaartje.

Ik heb dit idee eerst in zes globale varianten verkend. Daarna heb ik dezelfde varianten uitgebreider uitwerken, zodat ik beter kon vergelijken waar het kaartje verschijnt en hoe de verbinding met het koekje werkt. Tot slot heb ik ze in kleur gevisualiseren via canva pro.

Ik wil de zes varianten nu aan mensen in mijn omgeving laten zien. Ik vraag welke zij het duidelijkst en het leukst vinden, of ze begrijpen dat het koekje een knop is en of het kaartje logisch uit het koekje lijkt te komen. De reacties en mijn uiteindelijke keuze beschrijf ik in een volgend onderdeel.

<img src="./assets/images-readme/schetsencookie2.png" alt="" />
Foto: de schetsen van mijn variaties van de cookies na de feedback

### Feedback verwerken en drie nieuwe varianten maken

Ik heb de zes varianten van het gehaakte koekje opnieuw aan mensen in mijn omgeving laten zien. Ik wilde weten welk ontwerp zij het duidelijkst en het mooist vonden. De reacties liepen uiteen. Het hangende koekje sprak sommige mensen aan, maar zelf vind ik dat minder goed passen bij de vormgeving van mijn website. Bij de andere varianten werd vooral positief gereageerd op de manier waarop het kaartje en het koekje samen één geheel vormen. Ook het idee van een tekstballon viel op, omdat het bericht daardoor op een speelse manier uit het koekje lijkt te komen.

Met die feedback ben ik verdergegaan met variant 2, 4 en 6. Ik heb de sterke punten daarvan gecombineerd in drie nieuwe ontwerpen. In alle drie verschijnt het informatiekaartje direct naast het koekje, zonder dat het los hangt. Wanneer iemand op het koekje klikt, verdwijnt er een hapje. Dat stukje komt terug boven op het bericht. Zo is te zien dat het bericht bij het koekje hoort.

De drie ontwerpen laten elk een andere beweging zien. Bij de eerste variant vouwt het kaartje uit het koekje. Bij de tweede lijkt het kaartje door de opening naar buiten te schuiven. Bij de derde loopt de vorm van het koekje door in een zachte tekstvorm. Door deze verschillen naast elkaar te zetten, kan ik beter beoordelen welke interactie het duidelijkst is en het beste bij mijn website past.

Ik wil deze drie varianten nog één keer laten testen in mijn omgeving. Daarbij vraag ik of mensen begrijpen dat ze op het koekje kunnen klikken, of het bericht echt uit het koekje lijkt te komen en welke variant zij het prettigst vinden. Met die laatste feedback kan ik een onderbouwde keuze maken voor het ontwerp dat ik op mijn website ga uitwerken. De uitkomst van die test beschrijf ik in een volgend onderdeel.

Voor de nieuwe varianten heb ik weer eerst een schets gemaakt en daarna weer met canva kleur gegeven. Aangezien ik al de juiste vormgeving hasd voor het koekje ging dit een stuk makkelijker en sneller.

<img src="./assets/images-readme/cookievariatie2.png" alt="" />
Foto: De nieuwe varianten na de feedback.

## Maandag 28 september

### Bi-weekly Geek 2 – Het web en de wet

Vandaag begonnen we met de Bi-weekly Geek. Ik werkte samen met Massimo, Eva, Isabeau en Joy aan de vragen: 'Kan een machine onderscheid maken tussen informatie, prpagagana en desinformatie?' en ‘Kun je vrijheid van informatie hebben zonder bescherming tegen desinformatie?’ De opdracht was verdeeld over twee teams. Het andere team bedacht eerst deelvragen die nodig zijn om de hoofdvraag te kunnen beantwoorden. Daarna bekeek een ander team welke onderzoeksmethoden bij die deelvragen passen.

We kwamen op verschillende manieren om informatie te verzamelen, zoals literatuuronderzoek, interviews met experts, een focusgroep en een enquête. Ook dachten we aan het vergelijken van bestaande regels en voorbeelden. Ik merkte hierdoor dat je niet meteen een antwoord op een grote vraag hoeft te geven. Door de vraag eerst op te delen, kun je gerichter onderzoeken wat begrippen als vrijheid van informatie en desinformatie betekenen en welke gevolgen bescherming daartegen kan hebben.

Hieronder voeg ik de foto’s van onze ingevulde opdrachtbladen toe.

<img src="./assets/images-readme/weeklygeek2.png" alt="" />
Foto: De ingevulde opdracht bladen van de weekly geek 2.

### Toegankelijkheid testen met het toetsenbord en VoiceOver

#### Waarom hebben we dit gedaan?

Vandaag hebben we onderzocht hoe je een website gebruikt zonder muis of trackpad. Een website moet ook te bedienen zijn voor mensen die bijvoorbeeld minder goed zien of moeite hebben met fijne motoriek. Daarom hebben we geoefend met twee manieren van navigeren: alleen met het toetsenbord en met VoiceOver, de screenreader op een Mac.

Het doel van de opdracht was om op NS.nl een reis naar Maastricht te plannen. Daarbij moesten we vertrekken vanaf onze huidige locatie, de reis voor morgen instellen, om 12.00 uur vertrekken en een overstaptijd van minimaal tien minuten kiezen. We deden de opdracht twee keer: één keer met alleen het toetsenbord en één keer met VoiceOver.

#### Het POUR-principe

Tijdens de les hebben we het gehad over het POUR-principe. De vier letters beschrijven wat een toegankelijke website nodig heeft:

- Waarneembaar: bezoekers moeten de informatie kunnen zien, horen of op een andere manier meekrijgen. Een screenreader moet bijvoorbeeld kunnen vertellen wat een belangrijke afbeelding betekent.

- Bedienbaar: bezoekers moeten alle functies kunnen gebruiken, ook zonder muis. Je moet bijvoorbeeld met het toetsenbord bij knoppen en invulvelden kunnen komen.

- Begrijpelijk: de tekst en de bediening moeten duidelijk zijn. Bij een formulier moet je begrijpen wat je moet invullen en wat er gebeurt als je op een knop drukt.

- Robuust: de website moet goed werken met verschillende browsers en hulpmiddelen, zoals een screenreader.

Ik begrijp nu beter dat toegankelijkheid uit meerdere onderdelen bestaat. Een knop kan er duidelijk uitzien, maar alsnog lastig te gebruiken zijn als je er niet met het toetsenbord bij kunt komen of als VoiceOver niet vertelt wat de knop doet.

#### De niveaus A, AA en AAA

We hebben ook de WCAG-niveaus besproken. Dit zijn niveaus waarmee je kunt beoordelen aan welke toegankelijkheidseisen een website voldoet:

- A is het eerste niveau met belangrijke basiseisen.

- AA bevat de eisen van A en aanvullende eisen. Dit is het niveau waaraan onze website voor de opdracht moet voldoen.

- AAA bevat ook de eisen van A en AA, met nog strengere eisen. Waar het bij mijn website mogelijk is, wil ik ook aan zulke extra eisen denken.

Een voorbeeld is het contrast tussen tekst en achtergrond. Als kleuren te weinig van elkaar verschillen, wordt tekst moeilijker leesbaar. Ook een zichtbare focus is belangrijk: wanneer iemand op Tab drukt, moet duidelijk zijn welk onderdeel op dat moment geselecteerd is.

#### Test 1: NS.nl met alleen het toetsenbord

Voor de eerste test gebruikten we (deed deze opdracht met Jesse) geen muis of trackpad. Ik navigeerde met Tab langs de onderdelen van de pagina en met Shift + Tab terug. Met Enter of Spatie kon ik een onderdeel activeren. Zo probeerde ik de reis stap voor stap in te vullen.

Tijdens het testen lette ik niet alleen op de vraag of ik de reis kon plannen. Ik keek ook of ik kon zien waar ik op de pagina was en of ik zonder muis verder kon wanneer er bijvoorbeeld een keuzelijst verscheen. Hierdoor merkte ik hoe belangrijk de zichtbare focus en een duidelijke volgorde van invulvelden zijn.

Het lukte niet in 1 keer omdat ik op safari zat en daar deed niet alles het goed. ik ben daarna over gegaan op Chrome en daar deed alles het wel.

<img src="./assets/images-readme/alleentoetenbord.png" alt="" />
Foto: Ik testte of ik op NS.nl een reis kon plannen zonder mijn muis of trackpad te gebruiken.
Bron: [NS.nl](https://www.ns.nl)

---

<img src="./assets/images-readme/spiekbriefje-toetsenbord.png" alt="" />
Foto: Spiekbriefje 1: alleen het toetsenbord

#### Test 2: NS.nl met VoiceOver

Daarna voerde we de opdracht opnieuw uit met VoiceOver. VoiceOver leest onderdelen van de website voor en vertelt bijvoorbeeld of iets een kop, link, knop of invulveld is. Daardoor kon ik op een andere manier door dezelfde reisplanner navigeren.

Bij deze test lette ik op de informatie die werd voorgelezen. Begrijp je wat een invulveld vraagt? Is de naam van een knop duidelijk? En kun je horen waar je in het proces bent? De test maakte voor mij duidelijk dat een visueel ontwerp niet genoeg informatie geeft over hoe een website werkt voor iemand die een screenreader gebruikt.

<img src="./assets/images-readme/voiceover.png" alt="" />
Foto: Ik gebruikte VoiceOver om de reisplanner van NS.nl met een screenreader te testen.
Bron: [NS.nl](https://www.ns.nl)

<img src="./assets/images-readme/spiekbriefje-voice.png" alt="" />
Foto: Spiekbriefje 2: VoiceOver op de Mac

#### Wat neem ik mee voor mijn eigen website?

Door deze opdracht kijk ik anders naar mijn eigen website. Bij het maken en aanpassen van de site wil ik controleren of ik alle links, knoppen en menu’s met alleen het toetsenbord kan gebruiken. Ik wil ook testen of de focus goed zichtbaar is en of de volgorde waarin ik door de pagina ga logisch is.

Met VoiceOver wil ik nagaan of de koppen een duidelijke structuur vormen, of links en knoppen begrijpelijke namen hebben en of belangrijke afbeeldingen goed worden beschreven. Ik kan de spiekbriefjes bij mijn voortgangsgesprek gebruiken om te laten zien hoe ik dit test. De foto’s hierboven laten zien dat ik beide manieren van bedienen tijdens de les zelf heb uitgeprobeerd.

## Check-out maandag 28 september

Na het testen van NS.nl besprak ik samen met Lars drie vragen over semantiek, beperkingen en screenreaders. We gebruikten daarbij wat we tijdens de opdracht met het toetsenbord en VoiceOver hadden geleerd.

1. Wat bedoelt Vasilis met de uitspraak: “Semantiek doet mij niet zo veel, ik ben liever bezig met de UX van HTML”?

Volgens ons bedoelt hij dat hij minder bezig is met wat een HTML-woord letterlijk betekent en vooral kijkt naar wat je met het element kunt doen. Hij vindt het belangrijk hoe iemand de website in de praktijk ervaart en bedient.

Door de opdracht begrijp ik wel dat die twee dingen met elkaar te maken hebben. Als je bijvoorbeeld een echte HTML-knop gebruikt, kunnen bezoekers die meestal met het toetsenbord bedienen en herkent een screenreader dat het een knop is. De keuze van een HTML-element heeft dus invloed op de gebruikservaring.

2. Wat voor type beperkingen hebben invloed op het gebruiken van websites?

We bespraken vier soorten beperkingen:

- Visuele beperkingen: iemand ziet de website minder goed of niet en kan bijvoorbeeld een screenreader gebruiken.

- Auditieve beperkingen: iemand hoort geluid of gesproken informatie minder goed of niet.

- Motorische beperkingen: iemand kan moeite hebben met een muis of kleine klikvlakken en gebruikt bijvoorbeeld het toetsenbord.

- Cognitieve beperkingen: iemand kan moeite hebben met ingewikkelde teksten, veel informatie tegelijk of een onduidelijke indeling.

Daarom is het belangrijk om een website op verschillende manieren te testen. Als iets voor mij met een muis werkt, betekent dat nog niet dat iedereen het kan gebruiken.

3. Noem drie manieren om door een website te navigeren met jouw screenreader.

Op mijn Mac gebruik ik VoiceOver. Daarmee kan ik op verschillende manieren door een website gaan:

1. Onderdeel voor onderdeel: met Control + Option + <- of Control + Option + -> ga ik naar het vorige of volgende onderdeel.

2. Via de koppen: met de VoiceOver-rotor kan ik een lijst met koppen openen en naar een bepaald gedeelte van de pagina springen.

3. Via links of formuliervelden: in dezelfde rotor kan ik ook een lijst met links of formuliervelden kiezen. Dat is handig als ik snel iets wil vinden of een formulier wil invullen.

Door dit samen met Lars te bespreken, kon ik beter uitleggen waarom de opbouw van HTML belangrijk is. Duidelijke koppen, links, knoppen en invulvelden helpen bezoekers om hun weg te vinden, vooral wanneer ze een screenreader gebruiken.

## voorbereiding maandag 28 september

### Verantwoordelijkheid van digitale platforms en AI

Ik heb drie artikelen gelezen en een video bekeken over de verantwoordelijkheid van digitale platforms. In het NOS-artikel las ik over een rechtszaak tegen Meta. Amerikaanse staten stellen dat functies zoals automatisch afspelende video’s, stories en likes jongeren lang op Instagram en Facebook houden. Meta spreekt die beschuldigingen tegen. Het artikel liet mij nadenken over de invloed die kleine ontwerpkeuzes kunnen hebben op het gedrag van gebruikers.

Het artikel van Euronews ging over een onderzoek naar AI-chatbots die soms Russische propaganda als bron gebruikten. Ik leerde hiervan dat een antwoord betrouwbaar kan lijken, zelfs wanneer er een bron bij staat. Het blijft belangrijk om te controleren waar informatie vandaan komt en of die bron geloofwaardig is.

In het artikel van de Financial Times las ik dat ChatGPT volgens de Europese Commissie onder strengere regels van de Digital Services Act (DSA) gaat vallen. Grote online diensten krijgen extra verplichtingen, bijvoorbeeld rond illegale inhoud en de bescherming van minderjarigen. De video van de Europese Commissie hielp mij om de DSA beter te begrijpen. Daarin werd uitgelegd dat platforms duidelijker moeten zijn over hun aanbevelingen, jongeren beter moeten beschermen en meer verantwoordelijkheid moeten nemen voor verkopers op hun platform. Ook dark patterns kwamen aan bod: ontwerpen die mensen ongemerkt naar een bepaalde keuze sturen.

Deze bronnen waren nuttig voor mijn eigen ontwerpwerk. Ze lieten mij zien dat ik niet alleen moet nadenken over hoe een website eruitziet en werkt, maar ook over de gevolgen voor de bezoeker. Ik wil duidelijke informatie geven, bezoekers zelf keuzes laten maken en kritisch blijven op de bronnen die ik gebruik. Onder deze tekst voeg ik foto’s van mijn handgeschreven aantekeningen toe als bewijs van wat ik heb gelezen en bekeken. Omdat die foto’s niet overal goed leesbaar zijn, heb ik de belangrijkste inzichten en wat ik eraan had hierboven ook in tekst beschreven.

<img src="./assets/images-readme/aantekeningen28-9.png" alt="" />
Foto: Mijn aantekeningen van de artikelen en de video

### Feedback over mijn ideeen voor de privacyinformatie.

Na mijn eerdere voorbereiding heb ik de zes ideeën voor de vormgeving van mijn privacyinformatie aan mensen in mijn omgeving laten zien. Ik vroeg welk idee hen het meest aansprak en waarom. Ik schreef hun reacties op, zodat ik mijn keuze niet alleen op mijn eigen voorkeur zou baseren.

Bij het bolletje wol met draadje viel op dat het goed aansluit bij de titel en de sfeer van mijn website. Alleen René zei ook dat het juist verwarrend kan zijn als ik daar de zelfde vormgeving voor gebruik. Het gehaakte koekje werd gekozen omdat mensen het meteen met cookies associëren. Het garenlabel vond Annet passend omdat er op mijn website ook haakpatronen staan en op een garenlabel staan ook altijd alle informatie over dat garen. De rest van de varianten vielen niet zo erg in de smaak waardoor ik de keuze heb genomen om met deze varianten niet verder te gaan.

Ik kreeg ook feedback op hoe ik ideeën kon combineren. Lars stelde voor om het bolletje wol en het gehaakte koekje samen te gebruiken: het koekje blijft het herkenbare beeld en de tekst van het bericht wordt met een draadje aan het koekje verbonden. Isabeau bedacht daar een speelse reactie op. Wanneer je op het koekje klikt, lijkt er een hapje uit te verdwijnen. Dat losse stukje komt aan het informatiebericht te zitten.

Die twee reacties wil ik samenbrengen in één ontwerp. Eerst ziet de bezoeker een gehaakt koekje met het woord ‘Privacy’ erbij. Na een klik verschijnt een kort informatiekaartje dat met touwtjes aan het koekje vastzit. Het koekje mist dan een hapje en dat stukje zit aan de bovenkant van het kaartje. Zo horen het koekje en de uitleg zichtbaar bij elkaar. Op het kaartje komen de korte uitleg, ‘Meer informatie’ en ‘Sluiten’. Sluiten betekent alleen dat het kaartje verdwijnt; het koekje blijft staan zodat de informatie later opnieuw te openen is.
En ik ben nog aan het twijfelen of ik een knop erbij voeg met 'begrepen'. Maar hiervoor zal ik later een user test deoen om te kijken welke stijl van de pop-up de voorkeur heeft van gebruikers.

Ik vind deze combinatie leuk omdat de feedback mijn ideeën verder heeft gebracht dan de losse wireframes. Het koekje is herkenbaar, terwijl het draadje en het gehaakte uiterlijk bij mijn website passen. In een volgende schets wil ik kijken of het kaartje en het hapje ook op een klein scherm duidelijk blijven. Daarbij moet meteen zichtbaar zijn dat het om privacyinformatie gaat en niet om een vraag om cookies te accepteren.

Ik ga na de les nieuwe varianten maken op mijn gecombineerde cookie en deze weer testen mt mijn omgeving.

<img src="./assets/images-readme/feedback-cookie-1.png" alt="" />
Foto: de feedback die ik heb gekregen om mijn wireframes.

## Vrijdag 25 september

Door privé omstandigheiden kon ik helaas niet bij de les zijn.

Wel heb ik deze tijd gebruikt om mijn README aan te vullen (want daar liet ik erg bij achter) en verder te gaan met het bedenken hoe ik mijn cookie wil vormgeven.

Ook heb ik gekeken naar de checkout vragen en. heb ik bekeken welke ik kan beantwoorden.

### Ideeën voor de vormgeving van mijn privacyinformatie

Nadat ik had onderzocht welke gegevens er bij een bezoek aan mijn website worden verwerkt, ben ik gaan nadenken over de vormgeving van de privacyinformatie. Mijn eerste schetsen waren gebaseerd op een cookiemelding met knoppen voor ‘Accepteren’ en ‘Afwijzen’. Uit mijn onderzoek bleek dat die knoppen op mijn website geen echte keuze zouden bieden. Daarom wilde ik mijn ideeën aanpassen: de bezoeker moet de informatie gemakkelijk kunnen vinden en lezen, zonder eerst ergens mee te hoeven instemmen.

Ik heb zes mogelijke vormen bedacht die passen bij het haakthema van mijn website. Het eerste idee is een bolletje wol met een draadje. Wat het zelfde is als het bolletje wol die uit de tittel komt, maar het draadje leidt nu naar de privacyuitleg. Bij het tweede idee staat er een gehaakt koekje op de pagina. Als je erop klikt, verschijnt de uitleg naast het koekje. Daarmee kan ik het koekje idee uit mijn eerdere ontwerp behouden, terwijl het geen toestemmingsknop meer is.

Mijn derde idee is een haakpatroonkaartje dat openvouwt wanneer je erop klikt. Dit past bij de haakpatronen op mijn website en maakt het openen van informatie visueel herkenbaar. Bij het vierde idee hangt een koekje aan een draadje aan de rand van de pagina. Na een klik verschijnt de uitleg onder het koekje, alsof het draadje het informatiekaartje tevoorschijn haalt. Het vijfde idee is een garenlabel dat openklapt. Op zo’n label staat normaal informatie over wol; daarom leek het mij een passende plek voor informatie over de website. Tot slot bedacht ik een ontwerp met een rij haaksteken, waarbij een opvallende steek de ingang naar de privacyuitleg is. De steken passen bij elkaar, net zoals de verschillende onderdelen van de website met elkaar samenhangen.

Om de ideeën beter te kunnen vergelijken, heb ik digitaal zwart-witte wireframes gemaakt. In elk wireframe is te zien hoe het onderdeel eruitziet voor en na een klik. Deze schetsen gebruik ik als hulpmiddel om te bepalen welke vorm het duidelijkst werkt. Mijn eigen aantekeningen met de zes schetsen voeg ik hieronder ook toe.
<img src="./assets/images-readme/wireframes-cookie.png" alt="" />
Foto: mijn korte wireframes over de cookie vromgeving.

### Ideeën kiezen en feedback vragen

Na het bekijken van de zes wireframes spraken drie ideeën mij het meest aan: het bolletje wol met draadje, het gehaakte koekje en het koekje aan een draadje. Het bolletje wol vind ik leuk omdat het aansluit op mijn tittel gif, maar nu een andere functie heeft. Het draadje kan de bezoeker op een natuurlijke manier naar de privacyuitleg leiden. Bij het gehaakte koekje vind ik vooral leuk dat ik een herkenbaar onderdeel uit mijn eerdere ontwerp kan behouden en het is een knipoog naar een cookie. Het koekje aan een draadje spreekt mij aan vanwege de manier waarop het informatiekaartje tevoorschijn kan komen.

Ik wilde mijn keuze niet alleen baseren op wat ik zelf mooi vind. Daarom heb ik de ideeën ook aan mensen in mijn omgeving laten zien en gevraagd welke variant zij het beste vinden. Daarbij wilde ik niet alleen weten welk ontwerp ze het leukst vonden, maar ook of ze begrepen dat ze erop konden klikken voor privacyinformatie. Hun reacties kan ik gebruiken om een ontwerp te kiezen en het waar nodig duidelijker te maken.

## Check-out van vrijdag 25 september

Omdat ik tijdens deze les niet aanwezig was, ben ik niet aan iemand gekoppeld en heb ik gekeken of ik het zelf kon opzoeken

1. Wat is HTML-validatie, waarom is het belangrijk en hoe heb je dat vandaag uitgevoerd?

HTML-validatie is het controleren van de HTML-code op fouten en waarschuwingen. Hiermee kun je bijvoorbeeld ontdekken of elementen verkeerd zijn geplaatst, niet goed zijn afgesloten of op een verkeerde manier zijn gebruikt.

Dit is belangrijk omdat correcte HTML ervoor zorgt dat een website goed werkt in verschillende browsers. Ook maakt het de website beter begrijpelijk voor zoekmachines en hulpmiddelen zoals screenreaders.

Ik heb zelfstandig onderzocht hoe HTML-validatie werkt.
Bron: [HTML-validatie](https://frontend.webontwerp.ucll.be/HTML_validatie/)

2. Welke dingen vielen je op?

Ik heb het niet uitgevoerd dus ik ga de vraag wat aanpassen naar: Welke dingen kunnen opvallen wanneer je HTML-validatie uitvoert?

Wanneer je HTML-validatie uitvoert, kan opvallen dat een validator heel precies naar de code kijkt. De validator kan bijvoorbeeld aangeven dat een element niet goed is afgesloten, op de verkeerde plek staat of dat een verplicht onderdeel ontbreekt.

Ook kan een website er in de browser goed uitzien, terwijl er toch fouten of waarschuwingen in de HTML staan. Bij iedere melding laat de validator meestal zien om welke regel en welk onderdeel het gaat. Hierdoor kun je de fouten makkelijker terugvinden en stap voor stap verbeteren.

3. Welke feedback heb je ontvangen tijdens het gesprek met je docenten?

Omdat ik tijdens deze les niet aanwezig was, heb ik geen gesprek met de docenten gehad en daarom ook geen persoonlijke feedback ontvangen. Ik ben niet aan iemand gekoppeld, maar heb de opdracht vooral zelfstandig bekeken en onderzocht. Hierdoor heb ik zelf onderzocht wat HTML-validatie is en wat je zou kunnen opvallen na zo' contole.

## voorbereinding voor vrijdag 25 september

### Dieper onderzoek naar gegevens van bezoekers

Mijn website wordt gehost met GitHub Pages. Hierover had ik al informatie van GitHub opgezocht over wat er gebeurt wanneer iemand een GitHub Pages-website bezoekt. Ik vond de uitleg moeilijk om helemaal zelfstandig te begrijpen, omdat er veel tekst en technische termen in stonden. Hierdoor wilde ik toch wat meer onderzoek doen naar alle data dat wordt opgeslagen.
Hiervoor heb ik ChatGPT gebruikt om die informatie in begrijpelijkere taal uit te leggen en om mij te helpen onderscheid te maken tussen wat GitHub doet en wat ik eventueel zelf aan mijn website toevoeg. Daarna kon ik de uitleg weer naast de informatie van GitHub leggen.

Ik wil nog controleren of mijn eigen website daarnaast iets toevoegt, zoals externe inhoud, scripts of niet-noodzakelijke cookies. Pas wanneer ik weet wat mijn eigen website daadwerkelijk doet, kan ik bepalen of er een toestemmingsvraag nodig is en waarover die dan moet gaan. Ook wil ik duidelijk kunnen uitleggen welke informatie bij GitHub Pages hoort en welke keuzes de bezoeker wel of niet heeft.

#### De prompt die ik heb gebruikt voor Chatgpt:

Mijn website staat op GitHub Pages. Ik wil voor mijn learning log onderzoeken welke gegevens van bezoekers worden verwerkt wanneer zij mijn website openen, en of ik daarvoor een cookiemelding met knoppen voor accepteren en afwijzen nodig heb.

Gebruik eerst de officiële documentatie en privacyverklaring van GitHub. Maak daarna in eenvoudig Nederlands onderscheid tussen:

1. gegevens die GitHub Pages automatisch verwerkt om de website aan te bieden of te beveiligen;

2. cookies of gegevens die pas een rol spelen als ik zelf extra scripts, externe inhoud of diensten aan mijn website toevoeg;

3. wat een bezoeker daadwerkelijk kan accepteren of afwijzen via een knop op mijn eigen website.

Leg moeilijke termen uit, vermeld bij iedere conclusie de exacte bronlink en zeg duidelijk wat je zonder mijn volledige websitecode niet kunt vaststellen. Controleer ook of mijn idee eerlijk is: bij afwijzen wil ik nu een zwart scherm tonen met de tekst dat de website niet beschikbaar is. Leg uit of dat technisch klopt en wat een duidelijker alternatief zou zijn.

Hierna vroeg chat nog wat extra informatie over mijn code voor eventuele externe links. Hier kwam hij de link van Justus tegen dus hier heb ik aan Chat uitgelegd dat die link van mijn docent is en dat mijn docent de informatie niet opslaat.
Bron: [Chatgpt](https://chatgpt.com)

Antwoord van ChatGPT:
<img src="./assets/images-readme/chapgpt-1.png" alt="" />

<img src="./assets/images-readme/chatgpt-2.png" alt="" />
Foto's: Het antwoord wat Chat GPT mij gegeven heeft.

### Effect van mijn diepere onderzoek naar de data

Voor de opdracht over human consent had ik twee schetsen gemaakt rondom het thema haken. In de ene schets lag er een bolletje wol met een haakpatroon van een cookie in de hoek van de website. In de andere schets stond een gehaakt koekje met een spandoek waarop ‘cookies’ stond. Bij beide ideeën kon de bezoeker kiezen tussen accepteren en afwijzen. Als iemand zou afwijzen, wilde ik een zwart scherm laten zien met de boodschap dat de website niet beschikbaar was.

Nadat ik mijn onderzoek met behulp van ChatGPT verder had onderzocht, ben ik anders naar deze schetsen gaan kijken. Ik had eerst vooral nagedacht over hoe ik een originele cookiemelding kon ontwerpen. Door het onderzoek besefte ik dat ik eerst moest weten waar de bezoeker eigenlijk toestemming voor zou geven. Mijn website staat op GitHub Pages. GitHub geeft aan dat bij een bezoek aan een GitHub Pages-website het IP-adres van de bezoeker voor beveiliging wordt vastgelegd. Dat gebeurt al wanneer de pagina wordt opgevraagd. Een knop op mijn website kan die verwerking dus niet aan- of uitzetten.

Ook moest ik beter onderscheid maken tussen de algemene privacyverklaring van GitHub en wat er op mijn eigen website gebeurt. In de algemene verklaring staan verschillende gegevens en cookies genoemd, maar dat betekent niet automatisch dat mijn website al die cookies gebruikt. De Google Fonts die ik gebruik, heb ik zelf gedownload en in mijn assets-map gezet. Voor die lettertypen hoeft de browser dus geen verbinding met Google Fonts te maken. Op mijn homepage staat daarnaast een onderdeel van Digitaal Tuintje waarvoor de browser wel verbinding maakt met een andere website. Daarover wil ik duidelijk zijn tegenover mijn bezoekers. Ookal weet ik dat hier geen data bij wordt opgeslagen.

Op basis van de onderdelen die ik heb onderzocht, heb ik geen optionele cookies of analysetool gevonden waarvoor ik bezoekers op dit moment een keuze tussen accepteren en afwijzen moet geven. Mijn oorspronkelijke knoppen zouden daardoor een keuze suggereren die er niet echt is. Ook het zwarte scherm na ‘Afwijzen’ past niet meer bij wat ik nu weet: de website kan gewoon worden getoond, terwijl GitHub het IP-adres dan al heeft verwerkt. Ik wil bezoekers niet het gevoel geven dat ze ergens mee moeten instemmen om mijn website te kunnen bekijken. Voor uitsluitend strikt noodzakelijke cookies hoeft volgens de [Autoriteit Persoonsgegevens](https://www.autoriteitpersoonsgegevens.nl) geen toestemming te worden gevraagd.

Daarom ga ik mijn twee schetsen niet in hun oorspronkelijke vorm gebruiken. Ik wil het haakthema wel behouden omdat dat goed past bij mijn website, maar de functie veranderen. In plaats van een koekje dat om toestemming vraagt, kan bijvoorbeeld het bolletje wol verwijzen naar een korte privacyuitleg. Bezoekers kunnen die informatie lezen zonder eerst op ‘Accepteren’ of ‘Afwijzen’ te moeten klikken. Zo blijft het ontwerp bij mijn website passen en geef ik tegelijk een eerlijker beeld van wat er met gegevens gebeurt. Als ik later nieuwe externe diensten of optionele cookies toevoeg, moet ik opnieuw onderzoeken of een toestemmingskeuze nodig is.

### Welke informatie ik op mijn website wil laten zien.

Ik wil een korte, begrijpelijke privacyuitleg op mijn website zetten, met de mogelijkheid om meer informatie te lezen. Daarin wil ik vertellen dat mijn website via GitHub Pages wordt gepubliceerd en dat GitHub bij een bezoek het IP-adres vastlegt voor beveiliging. Ik wil er ook bij uitleggen dat mijn eigen knoppen die verwerking niet kunnen uitschakelen.

Daarnaast wil ik benoemen dat de lettertypen lokaal vanaf mijn website worden geladen en dat op de homepage een onderdeel van Digitaal Tuintje staat waarvoor een verbinding met digitaaltuintje.nl wordt gemaakt. ALs we Justus moeten geloven worden hierbij geen gegevens opgeslagen of gebruikt voor andere doeleindes.

Tot slot wil ik duidelijk maken dat ik in de onderzochte onderdelen van mijn website geen optionele cookies of analysetool heb gevonden waarvoor ik nu toestemming vraag. Ik voeg een link toe naar de uitleg van GitHub Pages over gegevensverzameling. Zo kan een bezoeker zelf verder lezen en is de informatie op mijn website concreter dan een algemene melding over ‘cookies’.

Ik heb aan Chatgpt voor de zekerheid gevraagd of ik een externe link kan toevoegen zonder dat daarna meet data verwerkt wordt.

#### De prompt die ik heb gebruikt voor Chatgpt:

als ik een externe link naar GitHub er inzet heb ik dan niet gezeur met eventueel meer data die GitHub verzameld?

Antwoord van ChatGPT:
<img src="./assets/images-readme/chatgpt-3.png" alt="Antwoord van Chatgpt" />
Foto: Antwoord van Chatgpt over extra data met een externe link.

### Eerste opzet van de cookie tekst

#### Korte tekst op de cookie pop-up zelf:

Hoe zit het met mijn gegevens?

Deze website staat op GitHub Pages. Bij een bezoek legt GitHub uw IP-adres vast voor beveiliging. Op deze website vraag ik u niet om toestemming voor optionele cookies.

Met twee knoppen: meer informatie en begrepen.

#### De tekste bij het klikken op meer infomatie:

Privacy op deze website

Wat gebeurt er als u mijn website bezoekt?
Mijn website wordt gepubliceerd via GitHub Pages. GitHub legt het IP-adres van bezoekers vast voor beveiliging, ook als u geen GitHub-account hebt. Een IP-adres is een nummer waarmee uw apparaat verbinding maakt met internet.

Gebruikt deze website andere diensten?
De lettertypen staan als bestanden op mijn eigen website. Uw browser hoeft daarvoor geen verbinding met Google Fonts te maken. Op de homepage staat ook een onderdeel van Digitaal Tuintje Om dat te tonen, maakt uw browser verbinding met digitaaltuintje.nl. Hierbij wordt geen data opgeslagen.

Waarom zie ik geen knop ‘Accepteren’ of ‘Afwijzen’?
In de onderdelen die ik heb onderzocht, gebruik ik geen optionele cookies of analysetool waarvoor ik u nu om toestemming vraag. De verwerking door GitHub Pages kan ik niet met zo’n knop aan- of uitzetten. Daarom geef ik u uitleg in plaats van een keuze die niets zou veranderen.

Wilt u meer weten over de hosting? Lees dan [GitHubs uitleg over gegevensverzameling bij GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages).

## Woensdag 23 september

### Gast spreker

De les begon met een gastspreker over privacy. Ik heb tijdens de presentatie aantekeningen gemaakt. Het onderwerp sloot goed aan op ons onderzoek naar cookies: als bezoeker geef je soms gegevens door zonder dat je precies weet welke gegevens dat zijn of wat ermee gebeurt. Ik vond het interessant om daar bewuster over na te denken, omdat ik zelf ook een website maak.

<img src="./assets/images-readme/aantekeningen-gastspreker-23-9.png" alt="Aantekening over de gastspreker" />
Foto: Aantekeningen van de gast spreker.

### Wire-frames

Na de gastspreker kregen we uitleg over het maken van een wireframe. Een wireframe is een eenvoudige schets van de indeling en werking van een pagina. Je hoeft nog niet alle kleuren, afbeeldingen en details uit te werken. Eerst kijk je welke informatie en knoppen nodig zijn, waar ze komen te staan en wat er gebeurt als iemand erop klikt. Dat vond ik een handige manier om mijn idee uit te proberen voordat ik het in code maak.

Daarna moesten we zelf een dark pattern op een bestaande website zoeken en de werking ervan schetsen. Ik onderzocht een voorbeeld op Eneba waarbij extra kosten pas later in het bestelproces zichtbaar worden. Ik tekende hoe de bezoeker eerst een prijs ziet en daarna bij het doorgaan een hoger totaalbedrag tegenkomt. Door de opeenvolgende schermen te schetsen, kon ik duidelijker laten zien wanneer die kosten verschijnen en waarom een bezoeker ze in het begin gemakkelijk kan missen. Deze wireframe voeg ik hieronder toe.

<img src="./assets/images-readme/wireframe-23-9.png" alt="Uit werking van de wireframe opdracht" />
Foto: Uitwerkingen van de wire frame opdracht

### Welke data wordt er opgeslagen an mijn bezoekers?

Vervolgens moesten we onderzoeken welke informatie we zelf aan bezoekers van onze website moeten uitleggen. Mijn website staat op GitHub Pages. Daarom heb ik de informatie van GitHub bekeken. Ik maakte aantekeningen over gegevens die bij een bezoek aan een website een rol kunnen spelen, zoals een IP-adres, gegevens over de browser en het apparaat, en informatie over welke pagina wordt opgevraagd. Ik wil daarbij precies blijven onderscheiden wat GitHub verwerkt en wat mijn eigen website eventueel zelf zou verzamelen. De foto van mijn onderzoeksaantekeningen voeg ik hieronder toe.

Met die informatie heb ik eerste ideeën geschetst voor hoe ik bezoekers hierover wil informeren en een keuze wil laten maken. Ik heb twee schetsen gemaakt waarin bij 1 schets een gehaakt koekje verandert afhankelijk van de keuze van de bezoeker. Bij accepteren blijft het koekje heel en bij afwijzen verandert de afbeelding in een gebroken koekje die op een zwart scherm staat met daarop de teskt excuus deze website is niet beschikbaar.

Ik wilde daarmee de keuze zichtbaar en passend bij de sfeer van mijn website maken. Tegelijkertijd moet ik in een volgende versie goed opletten dat de tekening de bezoeker niet ongemerkt richting ‘accepteren’ stuurt. Beide keuzes moeten even duidelijk blijven en de tekst moet uitleggen wat ze werkelijk betekenen. Foto’s van deze eerste schetsen voeg ik hieronder toe.

<img src="./assets/images-readme/variatiecookie-1.png" alt="" />
Foto: Variantie 1: een haak patroon van een cookie die goed is gegaan als je hem acceptert en fout gaat als je hem hebt afgewezen die op een zwart scherm staat met daarop de teskt excuus deze website is niet beschikbaar.

<img src="./assets/images-readme/variantie2-cookie.jpg" alt="" />
Foto: variantie 2: een cookie dat lekker gaat haken als hem accepteerd en stuk gaat als je hem hebt afgewezen die op een zwart scherm staat met daarop de teskt excuus deze website is niet beschikbaar.

---

<img src="./assets/images-readme/informatie-github.jpg" alt="Aantekeningen van mijn onderzoek naar github" />
Foto: mijn aantekeningen naar mijn onderzoek naar Github.

### Wat neem ik mee?

Ik neem uit deze les mee dat ik bij een cookiemelding niet meteen met de vormgeving moet beginnen. Eerst moet ik weten welke informatie klopt, wat een bezoeker moet begrijpen en welke keuzes ik daadwerkelijk kan aanbieden. De wireframes hielpen mij om het verschil tussen een idee en de werking ervan te zien. In een volgende stap wil ik mijn schetsen verder uitwerken en controleren of de uitleg en de keuzes eerlijk en begrijpelijk zijn.

## Chech-out woensdag 23 september

1. Wat is een wireflow en wat heb je eraan?

Een wireflow combineert eenvoudige schetsen van schermen met pijlen die laten zien hoe iemand van het ene scherm naar het andere gaat. Je ziet dus zowel wat de bezoeker ziet als wat er na een klik gebeurt. Dat is handig om een interactie uit te denken voordat je gaat coderen. Ik kan er bijvoorbeeld mee laten zien wat er op mijn website verandert wanneer iemand cookies accepteert of afwijst. media.nngroup.com

2. Wat zijn dark UX patterns? Geef drie voorbeelden.

Dark UX patterns zijn ontwerpkeuzes die bezoekers sturen naar iets wat ze misschien niet zelf zouden kiezen. De website kan er voordeel van hebben, terwijl de bezoeker belangrijke informatie mist of onder druk wordt gezet. Drie voorbeelden zijn:

1. Verborgen kosten: je ziet eerst een lage prijs, maar pas later in het bestelproces verschijnen extra kosten. Dit heb ik ook onderzocht in mijn schets van Eneba.
2. Confirmshaming: de tekst bij ‘nee’ geeft je een vervelend gevoel, bijvoorbeeld: “Nee, ik wil geen voordeel.” Daardoor wordt weigeren minder aantrekkelijk.
3. Nagging: een website blijft je onderbreken met hetzelfde verzoek, ook nadat je het hebt weggeklikt.

Ik wil bij mijn eigen ontwerp opletten dat de bezoeker de gevolgen van een keuze begrijpt en zich vrij voelt om die keuze te maken.

3. Waar moet je als ontwerper rekening mee houden bij het maken van een human consent component?

Een human consent component is voor mij een toestemmingsvraag die rekening houdt met de persoon die de keuze moet maken. Ik moet eerst onderzoeken waarvoor ik daadwerkelijk toestemming vraag en daarna in gewone taal uitleggen welke gegevens worden gebruikt, met welk doel en wat de keuzes betekenen. Accepteren en afwijzen moeten allebei duidelijk te vinden zijn. Ook mag ik iemand niet met een opvallende knop, schuldgevoel of een misleidende afbeelding naar één antwoord duwen.
Bij mijn schets verandert een koekje na het accepteren of afwijzen. Dat maakt de reactie zichtbaar, maar ik moet goed opletten dat het koekje bij afwijzen geen straf of schuldgevoel uitbeeldt. Beide keuzes moeten eerlijk blijven en de uitleg moet belangrijker zijn dan het grapje in de afbeelding.

## voorbereiding woensdag 23 september

### Opdracht afmaken

Als voorbereiding op woensdag heb ik de codeeroefening van Justus van maandag thuis afgemaakt. Tijdens de les ging het live coderen voor mij te snel om alles meteen goed te volgen. Thuis kon ik de code op mijn eigen tempo opnieuw bekijken en de onderdelen die nog niet af waren verder uitwerken.

Ik heb ook extra uitleg voor mezelf bij de code gezet. Ik wilde niet alleen een werkende uitwerking hebben, maar later ook kunnen begrijpen waarom iets op die manier is geschreven. Als ik een vergelijkbaar onderdeel in mijn eigen website wil gebruiken, kan ik mijn uitleg erbij pakken en het zelf opnieuw toepassen. Dat hielp mij meer dan de code alleen overnemen.

Omdat het niet echt lukt met mijn inhoud heb ik de inhoud van Justus gekopieerd en geplakt zodta ik echt alles goed kon mee doen.

<img src="./assets/images-readme/opdracht-justus.png" alt="Uitwerkingen opdracht van Justud." />
Foto: Uitwerkingen van de opdracht van Justus

### Onderzoek naar dark patterns

Daarnaast heb ik ter voorbereiding twee video’s bekeken en een artikel van UX Design Institute gelezen over dark patterns. Daarbij ging het over ontwerpkeuzes die bezoekers in een bepaalde richting sturen, bijvoorbeeld bij het delen van gegevens of het maken van een keuze. Ik ben hierdoor bewuster gaan letten op de woorden bij knoppen, de uitleg die een website geeft en hoe makkelijk verschillende keuzes te vinden zijn. Dat sluit ook aan bij de cookiepop-ups die we maandag hebben onderzocht.

Tijdens het lezen en kijken heb ik aantekeningen gemaakt. Foto’s van deze aantekeningen voeg ik hieronder toe. Zo kan ik later terugvinden wat ik uit de bronnen heb gehaald en welke punten ik wil onthouden wanneer ik zelf interactieve onderdelen ontwerp.
<img src="./assets/images-readme/Aantekeningen-huiswerk21-9.png" alt="Aantekeningen van het huiswerk voor woensdag 23-9" />
Foto: Aantekeningen van het huiswerk voor woensdag 23-9

## maandag 21 september

### live coderen

Aan het begin van sprint 2 ging Justus live coderen. We konden meekijken hoe hij een voorbeeld stap voor stap opbouwde, maar het tempo lag voor mij erg hoog. Ik probeerde tegelijk te begrijpen wat hij deed, aantekeningen te maken en zelf mee te werken. Daardoor lukte het mij niet om de hele opdracht tijdens de les af te ronden. Ik heb opgeschreven wat ik kon volgen en ben er later thuis rustig mee verdergegaan.

In de code van deze opdracht werkte ik onder andere met de opbouw van een HTML-pagina en een cookiemelding in een dialog-element. Ik vond het leerzaam om te zien hoe HTML-onderdelen samen een werkend geheel moeten vormen. Thuis kon ik de stappen opnieuw bekijken en in mijn eigen tempo uitproberen. Daardoor had ik meer ruimte om te begrijpen wat de code deed en om de opdracht af te maken. Mijn aantekeningen en de code van deze oefening voeg ik hieronder toe.
<img src="./assets/images-readme/aantekening-justus-livecode.jpg" alt="Aantekeningen van het live coderen van Justus." />
Foto: Aantekingen van het live coderen.

### cookiepop-ups onderzoeken

Daarna kregen we een opdracht over cookie consent. Ik heb deze samen met Massimo en Eva gemaakt. We onderzochten cookiebanners van de Volkskrant en Paradiso. Op het werkblad keken we niet alleen naar de knoppen, maar ook naar de uitleg: wat gebeurt er met je gegevens, wie kunnen die gegevens krijgen en kun je je keuze later nog veranderen? Ook bekeken we of ‘accepteren’ en ‘weigeren’ even duidelijk en makkelijk waren, en welke keuze de websites het liefst lijken te willen.

Tijdens het vergelijken viel ons op dat er verschil zit tussen een keuze aanbieden en iemand helpen een goed geïnformeerde keuze te maken. Een cookiebanner kan meerdere knoppen hebben, terwijl je toch moet zoeken naar wat die keuzes precies betekenen. Bij de Volkskrant zagen we bijvoorbeeld een uitgebreidere uitleg, maar ook veel informatie over partijen die gegevens kunnen ontvangen. Bij Paradiso keken we onder meer naar de verschillende keuzeopties en hoe duidelijk de gevolgen daarvan werden uitgelegd. De foto van ons ingevulde werkblad voeg ik hieronder toe en ook de bronnen van de websites.

<img src="./assets/images-readme/groepsopdracht 21-9.jpg" alt="Uitwerking van de opdracht over cookie onderzoek.." />
Foto: groeps opdracht over het onderzoek naar cookies.

Bronnen:
[Paradiso](https://www.paradiso.nl)
[Volkskrant](https://www.volkskrant.nl)

### Wat neem ik mee uit de les

Ik neem uit deze les mee dat ik bij interactieve onderdelen niet alleen moet nadenken over hoe ze eruitzien en of ze technisch werken. De woorden op een knop, de uitleg eromheen en hoe makkelijk je een keuze kunt maken, bepalen ook hoe eerlijk en duidelijk de ervaring voor een bezoeker is. De live-codeeroefening liet mij zien dat ik soms meer tijd nodig heb om code te begrijpen. De groepsopdracht hielp mij om kritischer te kijken naar de keuzes die een website aan bezoekers voorlegt.

## Check-out maandag 21 september

Ik heb deze samen met Eva geaakt.

1. Wat zijn HTML landmark role elements?
HTML landmark role elements zijn elementen die een webpagina verdelen in duidelijke onderdelen. Ze geven aan welke functie een bepaald gedeelte van de pagina heeft. Hierdoor kunnen mensen, zoekmachines en hulpmiddelen zoals screenreaders de structuur van een website beter begrijpen.
Voorbeelden zijn:
<header>: de bovenkant van een pagina, vaak met een titel of logo.
<nav>: het gedeelte met de navigatie en links.
<main>: de belangrijkste inhoud van de pagina.
<aside>: extra informatie die naast de hoofdinhoud staat.
<footer>: de onderkant van de pagina, bijvoorbeeld met contactgegevens.
<section>: een onderdeel van de pagina met een eigen onderwerp.
<form>: een gedeelte waarin een formulier staat.
Door deze elementen te gebruiken, wordt een website overzichtelijker en toegankelijker. Een gebruiker met een screenreader kan bijvoorbeeld direct naar de navigatie of de hoofdinhoud springen.

2. Wat zijn heading-elementen en hoe horen deze ‘genest’ te worden?
Heading-elementen zijn de koppen en tussenkoppen van een webpagina. In HTML gebruik je hiervoor <h1> tot en met <h6>.
De <h1> is de belangrijkste titel van de pagina. Een <h2> gebruik je voor de belangrijkste onderdelen onder deze titel. Wanneer een onderdeel binnen een <h2> weer een eigen tussenkop heeft, gebruik je een <h3>. Daarna kun je verdergaan met <h4>, <h5> en <h6>.
De koppen moeten in een logische volgorde worden gebruikt. Je hoort dus niet zomaar van een <h1> naar een <h4> te springen.
Bijvoorbeeld:
<h1>Mijn creatieve website</h1>

<h2>Haken</h2>
<h3>Mijn haakprojecten</h3>
<h3>Mijn haakpatronen</h3>

<h2>Binder art</h2>
<h3>Pokémon binder art</h3>
In dit voorbeeld is “Mijn creatieve website” het hoofdonderwerp. “Haken” en “Binder art” zijn onderwerpen binnen de website. De projecten en patronen zijn weer kleinere onderwerpen binnen deze onderdelen.
De heading-elementen hoeven niet letterlijk in elkaar geplaatst te worden. Met ‘nesten’ wordt hier vooral bedoeld dat de koppen inhoudelijk onder elkaar vallen en samen een duidelijke hiërarchie vormen.

3. Hoe ga jij met cookies om? Beschrijf jouw beweegredenen en of die zijn veranderd na het volgen van dit college.
   Voor het volgen van dit college accepteerde ik cookies meestal zonder goed te lezen waarvoor ze werden gebruikt. Ik klikte vaak op “alles accepteren”, omdat dit de snelste manier was om verder te gaan naar de website. Ik dacht toen niet veel na over welke informatie een website verzamelde en met welke partijen deze informatie gedeeld kon worden.
   Na dit college ben ik mij bewuster geworden van de verschillende soorten cookies. Noodzakelijke cookies zijn bijvoorbeeld nodig om een website goed te laten werken. Voorkeurscookies onthouden bepaalde instellingen. Analytische cookies verzamelen informatie over het gebruik van een website. Marketingcookies kunnen mijn gedrag op verschillende websites volgen om persoonlijke advertenties te laten zien.
   Mijn gedrag is hierdoor veranderd. Ik kijk nu beter naar de mogelijkheden in de cookiemelding. Wanneer het mogelijk is, accepteer ik alleen de noodzakelijke cookies en wijs ik marketing- en trackingcookies af. Soms accepteer ik analytische cookies wanneer deze alleen worden gebruikt om de website te verbeteren.
   Mijn belangrijkste beweegreden is mijn privacy. Ik wil meer controle hebben over welke gegevens van mij worden verzameld. Het college heeft mij laten zien dat cookies niet alleen handig zijn, maar ook gebruikt kunnen worden om mijn online gedrag te volgen. Daarom maak ik nu bewustere keuzes voordat ik cookies accepteer.

## Voorbereiding maandag 21 september

### verder werken aan mijn website

Voor de les van maandag hoefden we geen aparte voorbereidende opdracht te maken. Ik heb die tijd gebruikt om verder te coderen aan mijn eigen website. Na de inlevering van sprint 1 zag ik nog onderdelen die ik wilde aanvullen en verbeteren. Daarom ben ik verdergegaan met de uitwerking, zodat ik met een actuelere versie van mijn website aan sprint 2 kon beginnen.

Tijdens het coderen keek ik steeds wat er al werkte en wat nog aandacht nodig had. Ik maakte aanpassingen in mijn HTML en CSS en bekeek het resultaat in de browser. Zo kon ik zien of de veranderingen deden wat ik verwachtte. Als iets niet meteen goed stond, moest ik opnieuw naar mijn code kijken en een andere oplossing proberen.

Ik heb een paar foto’s gemaakt van de website terwijl ik eraan werkte. Die voeg ik hieronder toe, zodat zichtbaar is hoe mijn website er op dit moment uitzag en waar ik mee bezig was. Deze voorbereiding bestond dus vooral uit zelf verder bouwen en mijn werk stap voor stap verbeteren.
<img src="./assets/images-readme/21-9.png" alt=" Meerdere HTML's aangemaakt." />
Foto: Verder gewerkt aan mijn website.

# Sprint 1:

## Vrijdag 18 september (eerste DEADLINE!)

### Vrijdag – retrospectief en voortgangsgesprek

Voor de les had ik mijn website ingeleverd voor de deadline. Tijdens de les keken we terug op sprint 1 en bespraken we onze voortgang. Ik had ook het overzicht van de beoordelingspunten erbij. Daarin stond onder andere dat er gekeken werd naar onze website, de manier waarop we ons proces in de learning log hebben vastgelegd, onze ontwerpkeuzes en de uitwerking in HTML en CSS. Het hielp mij om te zien waarop ik feedback zou krijgen.

#### Retrospectief

Tijdens de les werkten we aan een retrospectief. Dat is een opdracht waarbij je terugkijkt op wat er de afgelopen twee weken is gebeurd, wat goed ging en wat lastig was. We gebruikten hiervoor _visual thinking_: je probeert je ervaringen en gedachten zichtbaar te maken met tekeningen. We begonnen met kleine tekenoefeningen, zoals kronkels in vogels veranderen en voorwerpen tekenen met basisvormen. Daardoor lag de nadruk minder op mooi kunnen tekenen en meer op een idee duidelijk overbrengen.

Daarna maakten we een piek- en daltekening van de afgelopen twee weken. Hiermee kon ik terugkijken op de momenten waarop ik vooruitgang voelde en op de momenten waarop het moeilijker ging. Bij die momenten keken we ook naar de competenties waaraan we hadden gewerkt en welke nog aandacht nodig hebben. Als laatste maakten we een metafoor met een titel voor onze ervaring van sprint 1. Ik vond het een andere manier van reflecteren dan alleen tekst schrijven: door te tekenen moest ik nadenken over hoe de verschillende gebeurtenissen met elkaar samenhingen. De afbeeldingen van mijn uitwerkingen voeg ik hieronder toe.
<img src="./assets/images-readme/aantekeningen-beoordelen.jpg" alt="Aantekeningen beoordelen op onder andere visuele hiërarchie." />
Foto: groeps opdracht het beoordelen van de aantekeningen.

<img src="./assets/images-readme/retrospectief-1.jpg" alt="Opdracht 1: van ronkels naar vogels" />
Foto: Opdracht 1: van ronkels naar vogels

<img src="./assets/images-readme/retrospectief-2.jpg" alt="Opdracht 2: simpele elementen tekenen" />
Foto: Opdracht 2: simpele elementen tekenen

<img src="./assets/images-readme/retrospectief-3.jpg" alt="Opdracht 3:Diek en daal tekening" />
Foto: Opdracht 3:Diek en daal tekening

<img src="./assets/images-readme/retrospectief-4.jpg" alt="Opdracht 4: een metafoor van sprint 1" />
Foto:Opdracht 4: een metafoor van sprint 1

#### beoordelingsgesprek

Terwijl we aan de retrospectief werkten, werden we één voor één naar een ander lokaal geroepen voor een voortgangsgesprek. Mijn gesprek was met Diederik. We bespraken mijn website en mijn voortgang aan de hand van de beoordelingspunten. Diederik gaf aan dat hij het knap vond hoeveel ik had gedaan, omdat ik door ziekte en privéomstandigheden niet altijd bij de lessen kon zijn en ook minder tijd had om aan mijn werk te besteden. Dat was fijn om te horen. Ik kreeg tijdens het gesprek het gevoel dat er met respect met mijn situatie werd omgegaan en dat er ook werd gezien hoeveel werk ik ondanks die omstandigheden had verzet.

Ik heb een positieve beoordeling en feedback gekregen. Dit was een formatieve beoordeling, dus ik kreeg geen eindcijfer. Het gesprek gaf mij wel een beter beeld van waar ik nu sta en of ik met mijn website op de goede weg ben. Dat stelde me gerust, zeker omdat ik zelf nog veel onderdelen zie die ik wil verbeteren.

Wat ik uit deze dag meeneem, is dat ik naast de dingen die nog niet af zijn ook mag kijken naar wat ik al heb bereikt. De retrospectief hielp mij om de afgelopen sprint als geheel te bekijken. Het voortgangsgesprek hielp mij om mijn werk door de ogen van een docent te zien. Met de feedback kan ik gerichter kiezen wat ik in de volgende sprint verder wil uitwerken en verbeteren.

## check-out vrijdag 18 september:

### Oriënteren en begrijpen

#### Waarom geven de docenten deze opdracht?

Volgens mij willen de docenten dat ik leer hoe ik een eigen idee omzet in een werkende website. Ik leer daarbij niet alleen HTML en CSS gebruiken, maar ook nadenken over mijn inhoud, ontwerpkeuzes en de mensen die mijn website bezoeken. Doordat de website over mijn eigen interesse gaat, moet ik zelf keuzes maken en kunnen uitleggen waarom ik die maak.

#### Welke technieken gebruik ik?

Ik gebruik HTML om mijn pagina’s en inhoud op te bouwen en CSS om de website vorm te geven. In CSS heb ik onder andere gewerkt met kleuren, lettertypes, afstanden en een lichte en donkere weergave. Door die technieken op mijn eigen website toe te passen, begrijp ik beter wat ze doen dan wanneer ik alleen voorbeelden uit een les overneem.

#### Wat zijn de randvoorwaarden?

Ik moet een werkende website inleveren en mijn proces en bronnen inzichtelijk maken. Ook moet ik rekening houden met wat we binnen de opdracht wel en niet mogen gebruiken. Mijn beschikbare tijd en mijn huidige kennis zijn voor mij ook randvoorwaarden: doordat ik ziek ben geweest en er privéomstandigheden waren, moest ik bepalen welke onderdelen ik eerst zou uitwerken. Daarbij wil ik blijven controleren of mijn website duidelijk en toegankelijk is.

#### Waar gebruik je HTML/CSS voor?

Met HTML geef ik betekenis en structuur aan de inhoud, bijvoorbeeld door titels, paragrafen, afbeeldingen en links op de juiste plek te zetten. Met CSS bepaal ik hoe die inhoud eruitziet en op het scherm wordt geplaatst. Ik merk dat ik beide nodig heb: een mooi ontwerp helpt weinig als de inhoud onduidelijk is, en goede inhoud wordt lastiger te gebruiken als de vormgeving niet helpt.

#### Wat kan er allemaal met CSS?

Ik ontdek steeds meer mogelijkheden van CSS. Ik kan er niet alleen kleuren en lettertypes mee aanpassen, maar ook onderdelen plaatsen, ruimte maken en verschillende weergaven ontwerpen. De light- en dark-mode-deep dive liet mij zien dat ik met CSS ook kan reageren op een gekozen thema. Tijdens het bouwen ontdek ik welke mogelijkheden ik voor mijn eigen website wil leren gebruiken. Ik vind het ook leuk dat je elke keer wat nieuws leert.

### Verbeelden en conceptualiseren

#### Lukt het om verschillende ideeën te bedenken?

Ja, ik heb tijdens mijn ontwerpproces meerdere ideeën voor de inhoud en vormgeving onderzocht. Ik heb bijvoorbeeld nagedacht over hoe ik mijn creatieve interesse kan laten zien en hoe bezoekers door de website kunnen gaan. Niet elk idee is uiteindelijk in de ingeleverde versie terechtgekomen. Het vergelijken van ideeën hielp mij wel om een richting te kiezen.

#### Lukt het om je ideeën te schetsen?

Schetsen helpt mij om ideeën die in mijn hoofd zitten zichtbaar te maken. Tijdens het schetsen zie ik sneller of een indeling logisch is en welke onderdelen nog ontbreken. Ik heb ook geleerd dat een schets niet netjes of definitief hoeft te zijn. Het is juist een manier om te denken, iets uit te proberen en daarna een andere versie te maken.

#### Wat doet deze CSS-property?

Bij het coderen probeer ik steeds beter te begrijpen wat een CSS-regel verandert. Soms zie ik meteen het verwachte resultaat, maar soms beïnvloedt een regel ook een ander onderdeel van de pagina. Dan kijk ik opnieuw naar mijn code en probeer ik stap voor stap te achterhalen waardoor dat gebeurt. Op die manier leer ik niet alleen welke waarde werkt, maar ook waarom.

#### Welke content, en welke HTML heb ik nodig?

Ik wil dat bezoekers begrijpen waar mijn website over gaat en dat ze verder kunnen klikken naar de inhoud die hen interesseert. Daarom heb ik nagedacht over welke teksten, afbeeldingen, navigatie en pagina’s daarvoor nodig zijn. Vlak voor de deadline wilde ik graag meerdere HTML-pagina’s hebben, zodat mijn idee duidelijker werd dan op één losse pagina. Tijdens het maken merk ik ook dat de inhoud invloed heeft op hoe ik de HTML moet indelen.

#### Hoe kan ik dit soort content vormgeven?

Ik onderzoek hoe ik tekst en beelden zo kan plaatsen dat de website duidelijk blijft en tegelijk bij mijn onderwerp past. Daarbij let ik op verschillen tussen een grote titel, een kopje en een paragraaf. Ook denk ik na over kleur en ruimte tussen onderdelen. Ik wil dat bezoekers eerst de belangrijkste informatie zien en daarna makkelijk verder kunnen lezen of klikken.

#### Wat als ik hier nu eens 1000 invul?

Deze vraag herinnert mij eraan dat ik tijdens het ontwerpen soms best een extreme waarde mag proberen. Als ik een formaat of afstand veel groter maak, zie ik duidelijker welk effect die keuze heeft. Ik hoef die extreme versie niet te houden, maar het experiment kan mij helpen om een betere keuze te maken dan wanneer ik steeds maar een heel klein beetje verander.

### Prototypen en uitwerken

#### Begrijpen bezoekers de site?

Ik kan zelf bedenken hoe iemand mijn website zou gebruiken, maar ik weet pas meer wanneer iemand anders hem probeert. Mijn zussen hebben mijn website getest. Tijdens dat testen zag ik een foutje dat ik zelf nog niet had opgemerkt en dat heb ik meteen opgelost. Dat liet mij zien hoe waardevol het is om anderen naar een werkende versie te laten kijken. Ik maak zelf ook altijd vaak gebruik van gebruikers testen op andere onderdelen bijv. op mijn schetsen dan vraag ik in mijn omgeving welke ze het makkelijkste vinden. Ik heb het ook gedaan bij mijn typografie, ik had verschillende fontsen ze laten zien en als eerste gevraagd welke hun het beste vonden qua duidelijkheid en leesbaarheid daarna had ik ze uitgelegd wat mijn doel was voor het lettertype. Het grappige hieraan is dat je dan ziet dat ze heel anders gaan kijken naar de lettertypes en dan geven ze soms hele andere feedback dan als ik niet die tweede vraag heb gevraagd.

#### Wat vindt de opdrachtgever ervan?

Bij deze opdracht geven de docenten feedback op mijn werk en mijn voortgang. Tijdens mijn gesprek met Diederik kreeg ik terug dat hij het knap vond hoeveel ik had gedaan, gezien ik ziek ben geweest en mijn privéomstandigheden. De beoordeling gaf mij het gevoel dat ik op de goede weg ben. Ik zie de feedback als informatie waarmee ik kan bepalen wat in een volgende versie nog aandacht nodig heeft.

#### Werkt dit wel?

Tijdens het bouwen merk ik soms pas of een idee in mijn website werkt. Een voorbeeld is de automatische stand die ik eerst naast light en dark mode had toegevoegd. Die gaf soms een probleem in combinatie met mijn gifje. Daarom heb ik de automatische stand weggehaald en gekozen voor een lichte en een donkere stand. Door het echt te bouwen, kon ik die keuze maken op basis van wat er gebeurde.

#### Oooooh, kan dit óók?!

Tijdens het toepassen van de light- en dark-mode-deep dive ontdekte ik dat ik dezelfde onderdelen met verschillende kleuren kan laten werken. Ik moest daardoor verder kijken dan alleen de achtergrond: ook tekst en knoppen moesten in beide standen kloppen. Dat vond ik interessant aan coderen. Een techniek die ik eerst als één kleine toevoeging zag, had invloed op mijn hele ontwerp.

### Evalueren

#### Wat wilde ik weten of bereiken?

Ik wilde een website maken waarop mijn idee en mijn creatieve interesse (haken) herkenbaar zijn. Voor de deadline wilde ik vooral dat er genoeg werkte om de bedoeling van de website te laten zien. Daarom vond ik het belangrijk om verder te komen dan één HTML-pagina en om mijn gekozen vormgeving ook echt in de code te verwerken.

#### Wat heb ik gedaan?

Ik heb ideeën geschetst, informatie gelezen, aantekeningen gemaakt en mijn website gebouwd met HTML en CSS. Ik heb de deep dive over light en dark mode toegepast en problemen die ik tijdens het coderen tegenkwam aangepakt. Ook heb ik mijn zussen de website laten testen (en andere mensen in mijn omgeveing hebben kleine onderdelen bekeken en getest of mening over gegeven) en mijn voortgang met Diederik besproken. In mijn learning log leg ik die stappen en mijn keuzes vast.

#### Wat was het resultaat?

Voor de deadline heb ik een versie van mijn website op tijd kunnen inleveren. Daarin was meer van mijn idee te zien doordat ik ook aan meerdere pagina’s had gewerkt. De lichte en donkere stand waren onderdeel van mijn website geworden. Tegelijkertijd was nog niet alles zoals ik het uiteindelijk wil hebben en was mijn README nog niet up-to-date. Dat laatste heb ik als notitie bij het inleveren gemeld.

#### Wat weet je nu wel en nog niet?

Ik begrijp beter hoe ik HTML gebruik voor de opbouw van mijn pagina’s en CSS voor de vormgeving. Ook heb ik geleerd dat testen een fout zichtbaar kan maken die ik zelf niet meer zie. Ik wil nog beter worden in het zelfstandig oplossen van CSS-problemen en in het controleren van mijn hele website op verschillende schermen en manieren van bedienen.

#### Wat vond je wel en niet leuk?

Ik vind het leuk om te zien hoe een idee langzaam verandert in een werkende website. Vooral het moment waarop iets dat ik heb bedacht ook echt in de browser verschijnt, motiveert mij. Het is minder leuk wanneer de code anders reageert dan ik verwacht of wanneer ik door tijdgebrek niet alles kan afmaken. Toch leer ik juist op die momenten om keuzes te maken en problemen stap voor stap te onderzoeken.
En heel eerlijk haal ik niet zo veel plezier uit het coderen zelf. Maar ik probeer er wel zo veel mogelijk van te leren en er uit te halen. Want ik heb zware dyslexie en daardoor is het voor mij echt heel lastig om goed te coderen. ALs ik een letter mis of een m=punt verkeerd heb staan dan zie ik dat gewoon niet alleen mijn code doet het dan natuurlijk ook niet.

#### Voldoet het nog aan de eisen?

Ik heb tijdens het werken naar de beoordelingspunten gekeken. Ik heb bijvoorbeeld gewerkt aan mijn procesdocumentatie, mijn ontwerpkeuzes en de lichte en donkere weergave. Ik weet ook dat er nog punten zijn om na te lopen. Mijn README was bij de deadline niet bijgewerkt; dat heb ik bij mijn inlevering aangegeven. Voor een volgende versie wil ik de eisen opnieuw naast mijn website leggen en per onderdeel controleren wat al klopt en wat nog werk vraagt.

#### Is mijn HTML nog valide?

Ik wil mijn HTML opnieuw controleren met een validator. Daarmee kan ik fouten vinden die ik niet meteen in de browser zie. Ik wil daarbij ook kijken of ik de juiste HTML-elementen gebruik en of de volgorde van mijn koppen logisch is. Een pagina die er goed uitziet, hoeft in de code namelijk nog niet helemaal goed opgebouwd te zijn.

#### Is mijn website toegankelijk?

Ik wil controleren of ik mijn website ook met een toetsenbord kan bedienen en of afbeeldingen passende alt-teksten hebben. Daarnaast wil ik het contrast van tekst en achtergrond in zowel de lichte als de donkere stand nakijken. Ik heb hier al over geleerd, maar ik wil niet doen alsof één snelle blik genoeg is om te weten dat de hele website toegankelijk is.

#### Is mijn website nog adaptief?

Ik heb een lichte en een donkere stand toegevoegd, maar ik wil nog controleren of alle onderdelen in beide standen goed zichtbaar blijven. Ook wil ik mijn pagina’s op verschillende schermgroottes bekijken. Omdat ik een gifje gebruik, wil ik verder onderzoeken wat er gebeurt als iemand minder beweging op het scherm heeft ingesteld.

#### Voldoet mijn website nog aan de wet?

Ik wil goed nagaan welke afbeeldingen en andere materialen ik op mijn website gebruik en of ik die mag gebruiken en correct vermeld. Ook wil ik nadenken over privacy als ik later onderdelen toevoeg die gegevens van bezoekers verwerken. Dit is voor mij nog een controlepunt; ik wil geen conclusie trekken zonder eerst mijn website en de gebruikte bronnen goed na te lopen. Ik weet dat we volgende sprint hier dieper op in duiken.

#### Zie ik mezelf nog terug in wat ik doe?

Ja! Mijn website gaat over een onderwerp dat bij mij past en ik maak zelf keuzes in de sfeer, beelden en vormgeving. Daardoor voelt het als mijn eigen project, ook wanneer nog niet alles af is. Ik wil bij volgende aanpassingen blijven kijken of ze mijn idee duidelijker maken, in plaats van iets toe te voegen alleen omdat het technisch mogelijk is.
Het gaat namelijk ook echt over mijn haak beestjes, het enige jammere is dat ik mijn afbeeldingen mooier en beter laat maken oor AI. Ik heb er over na gedacht om alles zelf te tekenen maar dan krijgen ze niet de uitstraling die ik ze wil geven. De beste oplossing is alles nog een keer zelf haken en dan mooie foto's maken alleen daar heb ik helaas de tijd niet voor. Ik zou dit zeker wel doen als het echt mijn eigen eigen website is buiten school om zodat ik te tijd heb om echt alles zelf te maken en mooi te fotograferen.
Alleen voor dit blok leek het mij de beste oplossing om de foto's te laten bijwerken door AI. Ik zet ook netjes op de foto aan AI teken zodat iedereen kan zien dat het AI gegenereerd is.

## voorbereiding vrijdag 18 september

### Vrijdag – voorbereiding en deadline

Voor vrijdag had ik minder voorbereidingstijd dan normaal. Donderdagochtend moest ik werken en in de middag en avond was ik op school voor mijn propedeuse-uitreiking. Gelukkig hoefden we deze keer geen artikelen te lezen of andere opdrachten voor te bereiden. De belangrijkste voorbereiding was om mijn website zo goed mogelijk af te maken voor de deadline en mijn README bij te werken.

Ik was nog niet helemaal tevreden met mijn website. Een website is natuurlijk nooit écht af, maar ik wilde wel dat bij het inleveren duidelijk werd wat mijn idee was en hoe bezoekers erdoorheen konden gaan. Na de uitreiking heb ik daarom nog kort iets gedronken bij Fest en ben ik daarna naar huis gegaan om ’s avonds verder te coderen.

Mijn belangrijkste doel voor die avond was om meerdere HTML-pagina’s te maken. Ik wilde dat de website meer zou zijn dan één losse pagina, zodat je bij het bekijken beter kon zien welke richting ik ermee op wilde. Door mijn lange reistijd had ik uiteindelijk minder tijd om te coderen dan ik vooraf dacht. Ik moest daarom kiezen wat ik voor de deadline nog kon afronden.

Het is gelukt om nog stappen te zetten en mijn website op tijd in te leveren. Mijn README heb ik helaas niet meer up-to-date kunnen maken. Dat heb ik meteen eerlijk vermeld in een notitie bij mijn inlevering, zodat duidelijk was dat de README nog niet de laatste stand van mijn website beschreef.

Ik merk dat ik kritisch blijf kijken naar mijn eigen werk en daardoor steeds nieuwe dingen zie die ik wil verbeteren. Voor deze deadline heb ik geleerd om keuzes te maken in de tijd die ik had. De README bijwerken en de onderdelen waar ik nog niet tevreden over ben, neem ik mee als volgende stappen.

## Woensdag 16 september

### Zelfstandig werken aan je website

Tijdens de les hebben we vooral zelfstandig aan onze eigen websites gewerkt. Het doel van deze dag was om zo veel mogelijk af te krijgen voor de deadline op vrijdag. Er was ruimte om in mijn eigen tempo door te werken. Als ik ergens tegenaan liep, kon ik rustig een vraag stellen aan de docenten.

Ik heb deze werktijd gebruikt om verder te kijken naar wat mijn website nog nodig had en om onderdelen te verbeteren. Omdat de deadline dichtbij kwam, moest ik keuzes maken: welke dingen waren belangrijk om nu werkend en duidelijk te krijgen, en welke details/informatie konden later nog aangepast worden? Het was prettig dat ik tijdens het werken meteen hulp kon vragen als ik vastliep, maar ook zelf eerst kon proberen een probleem op te lossen.

Deze les liet mij zien dat een website richting de deadline niet alleen afgemaakt, maar ook gecontroleerd moet worden. Ik wil daarom bij de laatste aanpassingen letten op de structuur van mijn pagina’s, de leesbaarheid van de tekst en of onderdelen op verschillende pagina’s consequent zijn vormgegeven.

## Check-out woensdag 16 september

1. Noem 3 Gestalt- of Design principes op en laat de ander uitleggen wat ze betekenen en doen.

Ik kies visuele hiërarchie, contrast en nabijheid:

- Visuele hiërarchie: je laat zien welke informatie het belangrijkst is. Een grote titel valt bijvoorbeeld eerder op dan een kleine paragraaf. Zo weet de bezoeker waar die eerst moet kijken.
- Contrast: je maakt een duidelijk verschil tussen onderdelen, bijvoorbeeld met lichte en donkere kleuren. Dat kan belangrijke onderdelen laten opvallen en helpt om tekst leesbaar te houden.
- Nabijheid: onderdelen die dicht bij elkaar staan, zien we als een groep. Een kopje moet daarom dichter bij de tekst staan waar het bij hoort dan bij het volgende onderdeel.

2. Een grid biedt ruimte om te spelen (vrijheid), maar tegelijkertijd ook eenheid en structuur (vastigheid). Wat wordt hiermee bedoeld?

Een grid is een soort onzichtbare indeling van een pagina, bijvoorbeeld met kolommen en vaste afstanden. Het geeft vastigheid, omdat je onderdelen netjes kunt uitlijnen en pagina’s daardoor bij elkaar passen. Binnen die indeling heb je toch vrijheid: een afbeelding kan bijvoorbeeld meer kolommen innemen dan een tekstblok. Je hoeft dus niet alles precies hetzelfde te maken, maar de pagina blijft wel overzichtelijk.

3. Welk principe neem je mee in een laatste iteratie van je eigen Garden?

Ik neem visuele hiërarchie mee. Bij mijn laatste aanpassingen wil ik controleren of meteen duidelijk is wat de titel is, welke kopjes bij welke tekst horen en welke knoppen belangrijk zijn. Daarvoor kijk ik naar de grootte van de tekst, de ruimte tussen onderdelen en het kleurcontrast. Zo kan ik mijn Garden duidelijker maken zonder de hele vormgeving opnieuw te veranderen.

## voorbereiding woensdag 16 september

### Verder werken aan mijn website: visueel ontwerp, light/dark mode en testen

Ik heb gelezen over visueel ontwerp en consistentie. Daarnaast heb ik verder gewerkt aan mijn website, een deep dive toegepast in mijn code en mijn website door mijn zussen laten testen. Ik merkte dat deze onderdelen met elkaar samenhangen: de artikelen hielpen mij bewuster naar mijn ontwerp te kijken, terwijl ik tijdens het coderen en testen ontdekte of mijn keuzes ook echt werkten.

#### Wat ik heb gelezen

Ik heb het artikel 5 Principles of Visual Design in UX van Nielsen Norman Group gelezen. Hierin worden vijf principes uitgelegd: schaal, visuele hiërarchie, balans, contrast en Gestalt. Wat ik hier vooral uit meenam, is dat vormgeving bezoekers helpt om informatie te begrijpen. Door een belangrijk onderdeel groter te maken, valt het eerder op. Met kleur, grootte en ruimte kun je laten zien waar iemand eerst naar moet kijken. Ook de afstand tussen onderdelen is belangrijk: als een kopje dicht bij een tekst staat, zie je sneller dat ze bij elkaar horen.

Daarna heb ik de Design Consistency Guide van UXPin gelezen. Dit artikel gaat over het consequent gebruiken van onderdelen in een ontwerp. Als dezelfde soort knop op iedere pagina een andere kleur of vorm heeft, moet een bezoeker telkens opnieuw nadenken over wat die knop doet. Hetzelfde geldt voor lettertypes, afstanden en de opbouw van pagina’s. Ik wil daarom beter opletten of ik mijn ontwerpkeuzes overal op dezelfde manier toepas.

Tijdens het lezen heb ik aantekeningen gemaakt. Hieronder voeg ik foto’s van mijn aantekeningen toe. Die laten zien welke punten ik uit de artikelen heb gehaald en wil gebruiken bij het verder ontwerpen van mijn website.
<img src="./assets/images-readme/aantekeningen-woe-16-9.png" alt="Aantekeningen van artikelen: 5 principes of visual design in UX en UXPin design consistency guide" />

#### Verder werken aan mijn website

Naast het lezen ben ik verdergegaan met mijn website. De website krijgt steeds meer vorm, maar er zijn ook nog onderdelen die ik moet uitwerken en verbeteren. Ik probeer daarbij niet alleen te kijken of iets er mooi uitziet, maar ook of de tekst duidelijk is, onderdelen bij elkaar horen en bezoekers begrijpen waar ze op kunnen klikken. De artikelen gaven mij woorden voor dingen waar ik tijdens het ontwerpen al mee bezig was, zoals hiërarchie, contrast en consistentie.

Ik loop op dit moment wat achter, omdat ik ziek ben geweest en er privé ook dingen speelden. Daardoor lukt het mij niet om helemaal gelijk te lopen met alle deep dives. Ik heb ervoor gekozen om gericht verder te werken aan mijn website en één deep dive meteen toe te passen. Mijn keuze viel op light en dark mode, omdat ik daar direct iets mee kon toevoegen aan mijn eigen ontwerp en tegelijkertijd kon oefenen met CSS.

#### Light en dark mode toepassen

Met behulp van de deep dive heb ik een lichte en een donkere weergave in mijn website gezet. Daarvoor heb ik de kleuren in mijn CSS vastgelegd en aangegeven welke kleur in de lichte en welke in de donkere stand gebruikt moet worden. Ik moest niet alleen nadenken over de achtergrondkleur, maar ook over de tekst, de knoppen en wat er gebeurt wanneer iemand over een knop beweegt. In beide standen moeten die onderdelen bij elkaar passen en leesbaar blijven.

Het toevoegen lukte niet meteen zonder problemen. Soms werkte iets anders dan ik verwachtte en moest ik opnieuw naar mijn code kijken. Door de uitleg uit de deep dive erbij te pakken en stap voor stap dingen aan te passen, heb ik die problemen kunnen oplossen. Dat vond ik leerzaam, omdat ik zo beter begreep wat de code doet in plaats van alleen een voorbeeld over te nemen.

Eerst had ik naast licht en donker ook een automatische stand toegevoegd. Daarbij kwam soms een fout naar voren in combinatie met mijn gifje. Ik heb geprobeerd te begrijpen waar het misging en heb uiteindelijk besloten de automatische stand weg te halen. Mijn website heeft nu een lichte en een donkere stand waaruit de bezoeker kan kiezen. Dat werkte op dit moment beter voor mijn website.

Van de stappen tijdens het coderen heb ik helaas geen foto’s gemaakt. In mijn code is wel terug te zien hoe ik de kleuren voor light en dark mode heb toegevoegd en welke keuze ik uiteindelijk heb gemaakt.

<img src="./assets/images-readme/aantekeingen-deepdive-lightanddark.png" alt="Aantekeningen van de Depp-dive over light and dark + aantekeningen/ opmerkingen na het coderen." />
Foto: Aantekeningen van de Depp-dive over light and dark + aantekeningen/ opmerkingen na het coderen

#### Testen met mijn zussen

Mijn zussen hebben mijn website ook getest. Ik heb daar wél 2 foto’s van gekregen en voeg die hieronder toe. Door hen de website te laten bekijken, kon ik zien hoe anderen ermee omgaan. Tijdens het testen zag ik nog een foutje dat mij eerder niet was opgevallen. Dat heb ik meteen opgelost.

Dit liet mij zien waarom het belangrijk is om een website niet alleen zelf te controleren. Als ik er lang aan werk, weet ik al hoe alles bedoeld is en kijk ik soms over een fout heen. Iemand die de website voor het eerst ziet, kijkt er anders naar. Ik wil daarom vaker tussendoor laten testen, ook wanneer de website nog niet helemaal af is.

<img src="./assets/images-readme/testen-lauwendees.png" alt=" Foto's van het bewijs dat ze getest hebben en hoe het er uit ziet." />
Foto: bewijs van testing + resultaat op mijn website.

## Maandag 14 september

### Bi-Weekly geek 1

Tijdens de eerste Bi-Weekly Geek stond de werking, betrouwbaarheid en verantwoordelijkheid van het internet centraal. We gingen in groepjes aan de slag met verschillende hoofdvragen. Het doel was om te leren hoe je een grote vraag kunt opdelen in kleinere deelvragen en daar vervolgens passende onderzoeksmethoden bij kunt zoeken.

#### Onze hoofdvraag

Mijn groepje bestond uit Eva, Seb, Massimo en mij. Wij kregen de volgende hoofdvraag:
Moeten kritieke internetdiensten in handen zijn van commerciële bedrijven?

Deze vraag sluit aan bij de voorbereiding over cloudbedrijven en de macht van grote technologiebedrijven. Veel websites en apps zijn afhankelijk van commerciële bedrijven zoals Amazon, Microsoft en Google. Wanneer één van deze bedrijven een grote storing heeft, kunnen veel verschillende diensten tegelijk uitvallen.

Voordat we de hoofdvraag konden beantwoorden, moesten we eerst bedenken welke informatie we nodig hadden. Daarom hebben we de hoofdvraag opgesplitst in kleinere deelvragen.

#### Onze deelvragen

Samen bedachten we de volgende deelvragen:

1. Wat zijn kritieke internetdiensten?
2. Welke bedrijven vallen onder commerciële bedrijven?
3. Over welke data beschikken kritieke internetdiensten?
4. Wat zijn de voor- en nadelen van kritieke internetdiensten in handen van commerciële bedrijven?
5. Wie heeft de kritieke internetdiensten op dit moment in bezit of onder controle?

Deze deelvragen bekijken de hoofdvraag vanuit verschillende kanten. We moeten eerst begrijpen wat kritieke internetdiensten zijn en welke bedrijven ze beheren. Daarna kunnen we onderzoeken welke gegevens deze diensten verwerken en wat de mogelijke voordelen en risico’s van commercieel beheer zijn.

 <img src="./assets/images-readme/bi-weekly1.jpg" alt="" />
 Foto: Ons werkblad van de opdracht.

#### Werkblad uitwisselen

Nadat iedere groep deelvragen had bedacht, wisselden we onze werkbladen uit. Iedere groep kreeg daardoor het blad van een andere groep.

Bij het tweede onderdeel moesten we niet zelf nieuwe deelvragen bedenken. We bekeken de deelvragen van de andere groep en zochten bij iedere vraag een passende onderzoeksmethode. Hiermee onderzochten we hoe de groep informatie kon verzamelen om de hoofdvraag uiteindelijk zo goed mogelijk te beantwoorden.

We dachten bijvoorbeeld na over methoden zoals:

- deskresearch;
- artikelen en betrouwbare bronnen vergelijken;
- experts interviewen;
- verschillende bedrijven of diensten vergelijken;
- bestaande gegevens en onderzoeken analyseren.

Door het werkblad uit te wisselen, kregen we een andere kijk op de vragen. We moesten niet alleen nadenken over wat iemand wilde weten, maar vooral over hoe die informatie onderzocht kon worden.

Van het tweede werkblad heb ik helaas geen foto gemaakt. Daarom beschrijf ik deze stap in mijn Learning Log.

#### Het verband met mijn voorbereiding

De opdracht sloot goed aan bij de bronnen die ik vooraf had bekeken. In het artikel over de cloudstoring werd duidelijk dat veel internetdiensten afhankelijk zijn van een klein aantal commerciële cloudbedrijven.

Deze bedrijven kunnen voordelen bieden. Ze beschikken bijvoorbeeld over veel technische kennis, grote datacenters en voldoende geld om hun systemen te onderhouden. Tegelijkertijd kan deze afhankelijkheid ook risico’s veroorzaken. Een storing, verandering in voorwaarden of verkeerde beslissing van één bedrijf kan gevolgen hebben voor veel gebruikers en organisaties.

Het artikel over Tim Berners-Lee liet daarnaast zien dat grote technologiebedrijven niet alleen veel infrastructuur beheren, maar ook veel macht hebben over persoonsgegevens, platforms en de manier waarop mensen het web gebruiken.

Door de hoofdvraag begreep ik beter dat de betrouwbaarheid van het internet niet alleen een technisch probleem is. Het is ook een vraag over eigendom, verantwoordelijkheid, privacy en macht.

#### Wat heb ik geleerd?

Tijdens deze les heb ik geleerd dat een brede hoofdvraag niet direct te beantwoorden is. Door de vraag op te delen in kleinere deelvragen wordt duidelijker welke informatie nodig is.

Ook heb ik geleerd dat iedere deelvraag een passende onderzoeksmethode nodig heeft. Een feitelijke vraag kan bijvoorbeeld onderzocht worden met deskresearch, terwijl een vraag over ervaringen of meningen beter onderzocht kan worden met interviews.

Het uitwisselen van de werkbladen vond ik nuttig, omdat een andere groep met een frisse blik naar de vragen keek. Hierdoor zag ik dat onderzoek niet alleen draait om goede vragen bedenken, maar ook om bewust kiezen hoe je betrouwbare antwoorden verzamelt.

## Check-out maandag 14 sept.

1. Leg uit wanneer een website ‘lelijk’ wordt en geef voorbeelden van wat je kan doen om deze ‘lelijke’ onderdelen te fixen.
   Een website wordt ‘lelijk’ wanneer de vormgeving op bepaalde schermformaten niet meer goed werkt. Tekst kan bijvoorbeeld te breed worden, afbeeldingen kunnen buiten het scherm vallen en onderdelen kunnen over elkaar heen komen te staan. Dit kan ik oplossen met flexibele eenheden, max-width, flex-wrap en media queries.

2. Vertel welke volgende stap je neemt om je website responsive te maken.
   Mijn volgende stap is om mijn website op verschillende schermformaten te testen. Daarna pas ik onderdelen die niet goed meeschalen aan en voeg ik waar nodig media queries toe voor grotere schermen.

3. Kun je het ontwerp en de bouw van je eigen Garden uit je hoofd onderbouwen in Webby vocabulary?
   Mijn digital garden is responsive, omdat de indeling zich aanpast aan verschillende schermformaten. De website is ook interactief en dynamisch door de navigatie, knoppen, links en animaties. Met semantische HTML, duidelijke koppen, alt-teksten, voldoende contrast en toetsenbordfocus probeer ik de website daarnaast toegankelijk te maken. De kleuren, zachte vormen, afbeeldingen en typografie maken mijn website expressief en persoonlijk.

## Voorbereiding maandag 14 september

Voor de eerste Bi-Weekly Geek heb ik vooraf één video bekeken en twee artikelen gelezen. De bronnen gingen over de technische werking van het internet, de afhankelijkheid van grote cloudbedrijven en de oorspronkelijke bedoeling van het World Wide Web.

#### Hoe werkt het internet?

In de video van BBC werd uitgelegd dat het internet bestaat uit verschillende computers en apparaten die met elkaar verbonden zijn. Samen vormen deze apparaten een groot netwerk.

Om informatie op de juiste plaats te krijgen, gebruikt het internet vaste regels. Deze regels worden protocollen genoemd. Grote bestanden en berichten worden tijdens het versturen verdeeld in kleine stukjes. Deze stukjes heten pakketjes.

Ieder pakketje bevat informatie over:

- waar het vandaan komt;
- waar het naartoe moet;
- hoe het later weer moet worden samengevoegd.

Ieder apparaat op het internet heeft een eigen numeriek adres: een IP-adres. Een Domain Name System, oftewel DNS, werkt als een soort adresboek. Het vertaalt een herkenbare domeinnaam naar het bijbehorende IP-adres.

Vervolgens sturen routers de pakketjes door het netwerk. De pakketjes kunnen verschillende routes volgen. Wanneer ze op hun bestemming aankomen, worden ze weer in de juiste volgorde samengevoegd.

Door deze video begrijp ik beter dat het internet niet één onzichtbaar systeem is. Het bestaat uit veel apparaten, servers, kabels, adressen en afspraken die samenwerken om informatie te versturen.

#### The Guardian – The cloud crash

Het eerste artikel ging over een grote storing bij Amazon Web Services, ook wel AWS genoemd. AWS levert cloudservices aan veel verschillende bedrijven. Deze bedrijven huren bijvoorbeeld opslagruimte, servers en rekenkracht van Amazon.

Door de storing werkten veel websites en apps tijdelijk niet meer. Dit liet zien dat veel verschillende online diensten achter de schermen afhankelijk zijn van dezelfde grote cloudbedrijven.
De cloud klinkt alsof gegevens onzichtbaar ergens op het internet zweven, maar bestaat in werkelijkheid uit fysieke datacenters met computers en servers. Wanneer er bij een belangrijk datacenter een probleem ontstaat, kan dit wereldwijd gevolgen hebben.

De grootste cloudproviders zijn:

- Amazon Web Services;
- Microsoft Azure;
- Google Cloud.
  Overstappen naar een andere aanbieder is vaak moeilijk, duur en tijdrovend. Bedrijven bouwen hun systemen namelijk rondom de technieken van één aanbieder. Hierdoor kan een sterke leveranciersafhankelijkheid ontstaan.

Dit is ook belangrijk voor Europa. Veel Europese bedrijven, overheden en publieke diensten gebruiken infrastructuur van Amerikaanse technologiebedrijven. Hierdoor heeft Europa minder controle over belangrijke digitale voorzieningen.

Mogelijke oplossingen zijn:

- Meer Europese cloudinfrastructuur ontwikkelen;
- open standaarden gebruiken;
- meer met open-source technologie werken;
- het makkelijker maken om tussen aanbieders te wisselen.

 <img src="./assets/images-readme/aantekeingen-ma14-9-1.png" alt="Aantekeningen van artikel The Guardian" />
 Foto: aantekeningen van het artikel

#### Tim Berners-Lee en de toekomst van het web

Het tweede artikel ging over Tim Berners-Lee, de bedenker van het World Wide Web. Hij bedacht het web in 1989 als een open systeem waarmee mensen informatie konden delen en samenwerken.

Het internet en het web zijn niet precies hetzelfde. Het internet is de technische infrastructuur waarmee apparaten met elkaar verbonden zijn. Het World Wide Web is een systeem van websites en pagina’s dat gebruikmaakt van die infrastructuur.

Volgens Berners-Lee is een deel van het web steeds commerciëler geworden. Grote technologiebedrijven verdienen geld aan advertenties, aandacht en persoonsgegevens. Sociale media worden daarom vaak ontworpen om mensen zo lang mogelijk te laten kijken, klikken en scrollen.

Hierdoor heb ik geleerd dat technologie niet neutraal is. Ontwerpkeuzes kunnen het gedrag van gebruikers beïnvloeden. Voorbeelden hiervan zijn:

- eindeloos scrollen;
- meldingen;
- aanbevolen berichten;
- algoritmes die bepalen wat iemand ziet.
  Berners-Lee werkt daarom aan Solid. Dit project moet gebruikers meer controle geven over hun eigen gegevens. Bij Solid worden persoonlijke gegevens opgeslagen in een eigen digitale opslag, een zogenaamde pod. De gebruiker bepaalt vervolgens zelf wie toegang krijgt tot welke informatie.

In het artikel bespreekt Berners-Lee ook kunstmatige intelligentie. Hij vindt dat er meer onafhankelijke controle, duidelijke regels en internationale samenwerking nodig zijn. Hij vergelijkt dit met CERN, waar wetenschappers uit verschillende landen gezamenlijk onderzoek doen.

De belangrijkste boodschap die ik uit dit artikel haal, is dat het web opnieuw meer voor de gebruiker ontworpen moet worden. Mensen moeten meer controle krijgen over hun gegevens en grote technologiebedrijven moeten niet alle macht over het web en de data van gebruikers hebben.

<img src="./assets/images-readme/aantekeingen-ma14-9-2.png" alt="Aantekeningen van artikel Tim Barners-Lee" />
 Foto: aantekeningen van het artikel

#### Het verband tussen de bronnen

De drie bronnen bekijken het internet vanuit verschillende kanten.
De video van BBC legt uit hoe informatie technisch over het internet wordt verstuurd. Het artikel over de cloudstoring laat zien wie een groot deel van de technische infrastructuur beheert. Het artikel over Tim Berners-Lee gaat vooral over wie controle heeft over het web, digitale platforms en de gegevens van gebruikers.

De artikelen laten allebei zien dat het internet open en verspreid lijkt, terwijl veel macht bij een klein aantal grote technologiebedrijven ligt. Deze bedrijven beheren een groot deel van de infrastructuur, platforms en persoonsgegevens.

Hierdoor begrijp ik dat het internet niet alleen een technisch onderwerp is. Het gaat ook over macht, verantwoordelijkheid, privacy, betrouwbaarheid en onafhankelijkheid.

#### Wat heb ik geleerd?

Door deze voorbereiding begrijp ik beter hoe het internet technisch werkt en welke bedrijven een belangrijke rol spelen in de infrastructuur ervan.
Ik heb geleerd dat:

- gegevens als kleine pakketjes over het internet worden verstuurd;
- protocollen ervoor zorgen dat apparaten dezelfde regels gebruiken;
- IP-adressen en DNS nodig zijn om de juiste bestemming te vinden;
- veel websites afhankelijk zijn van enkele grote cloudproviders;
- een storing bij één aanbieder veel verschillende diensten kan raken;
- ontwerpkeuzes invloed hebben op het gedrag van gebruikers;
- gebruikers vaak weinig controle hebben over hun persoonsgegevens;
- het belangrijk is om na te denken over openheid, privacy en onafhankelijkheid.

De voorbereiding gaf mij genoeg achtergrondinformatie om tijdens de Bi-Weekly Geek mee te kunnen praten over vragen zoals: Wie heeft controle over het internet? en Wie is verantwoordelijk voor de betrouwbaarheid van het internet?

## Vrijdag 11 september

### korte samenvatting van de voorbereiding (bij het voorbereiden kopje staat het uitgebreid)

#### Mobile-first schermschetsen

Als voorbereiding werkte ik mijn gekozen ideeën eerst uit voor een mobiel scherm. Hierdoor moest ik goed nadenken over welke content het belangrijkste is en wat de gebruiker als eerste moet zien.

Voor het kiezen van een Pokémonkaart maakte ik twee varianten:

- Een horizontale waaier waarin de middelste kaart het grootste is. De gebruiker kan naar links of rechts swipen.
- Een verticale indeling waarin de kaarten onder elkaar staan. De gebruiker kan door de kaarten scrollen.

Voor mijn haakpatronen maakte ik ook twee galerij-indelingen. In de eerste schets staan grote afbeeldingen onder elkaar. In de tweede schets wisselen afbeeldingen en korte teksten elkaar af. Rond de afbeeldingen tekende ik zachte en wollige vormen om de sfeer van het haken terug te laten komen.
Bij de mobiele schetsen hield ik rekening met: een indeling in één kolom;

- de belangrijkste informatie bovenaan;
- grote klikvlakken;
- duidelijke koppen;
- realistische verhoudingen voor afbeeldingen en teksten;
- een ontwerp dat past bij een kleiner scherm.

#### Vertaling naar desktop

Daarna vertaalde ik dezelfde ideeën naar een groter laptopscherm. Ik maakte geen volledig nieuw ontwerp, maar onderzocht hoe ik de extra ruimte kon gebruiken.
Op een mobiel scherm staat de content vooral onder elkaar. Op een laptopscherm kunnen meerdere kaarten of projecten naast elkaar worden getoond. De belangrijkste Pokémonkaart kan centraal blijven staan, terwijl andere kaarten of binder-artvarianten eromheen worden geplaatst.

Bij de desktopversies lette ik erop dat:

- het belangrijkste onderdeel het meeste opvalt;
- de extra ruimte nuttig wordt gebruikt;
- meerdere afbeeldingen naast elkaar kunnen staan;
- de visuele hiërarchie hetzelfde blijft;
- hover- en focus-states mogelijk zijn;
- de mobiele en desktopversie herkenbaar bij elkaar horen.

De foto's staan bij de voorberiding.

### zelfstsandig verder werken + feedback moment.

Tijdens de les mochten we zelfstandig verder werken aan onze website. Tussendoor voerden we in kleine groepjes gesprekken met Justus of Sanne. Tijdens dit gesprek bekeken we hoe ver iedereen was, wat al goed ging en waar iemand nog tegenaan liep.

Ons groepje was als eerste aan de beurt. We lieten één voor één onze presentatie zien. Als iemand al iets in HTML had gebouwd, kon dit ook worden getoond.
Omdat ik eerder had verteld dat ik nog twijfelde over het onderwerp van mijn website, hebben we bij mij vooral naar mijn presentatie en schetsen gekeken. We onderzochten samen welk onderwerp de meeste mogelijkheden bood voor mijn digital garden.

#### Feedback op mijn onderwerp

Tijdens het bekijken van mijn presentatie merkte ik dat Justus vooral enthousiast werd van mijn haakprojecten. Daarna bekeken we mijn mobiele en desktop-schetsen. Aan de verschillende ideeën was duidelijk te zien dat ik nog niet helemaal zeker wist welke richting ik wilde kiezen.

Justus legde uit dat het onderwerp haken sterk is omdat het persoonlijk bij mij past. Ook sluit het goed aan bij mijn gekozen sfeerwoorden en bij de zachte, handgemaakte uitstraling die ik in mijn Visual Research had verzameld.

Deze feedback hielp mij om een duidelijkere keuze te maken. Ik besloot om mij voor mijn website vooral te richten op mijn haakwereld en haakcreaties. Hierdoor werd het makkelijker om keuzes te maken voor de inhoud, typografie, kleuren en vormgeving van mijn website.

De foto's van mijn schetsen en presentatie staat eerder in mijn learnig log.

#### Een passend lettertype onderzoeken

Na het gesprek kon ik weer zelfstandig verder. Ik begon met het zoeken naar een lettertype dat bij de gewenste uitstraling van mijn website past.

Ik wilde een lettertype vinden dat:

- creatief aanvoelt;
- past bij de handgemaakte uitstraling van haken;
- goed leesbaar blijft;
- aansluit bij mijn sfeerwoorden;
- gebruikt kan worden op mijn website.

Ik heb verschillende lettertypen bekeken. Een aantal lettertypen vond ik erg mooi, maar deze waren betaald. Daarom besloot ik deze niet te gebruiken.

Uiteindelijk koos ik een lettertype uit Google Fonts. Bij de verdere uitwerking wil ik onderzoeken of ik het lettertype lokaal in mijn website kan opslaan. Hierdoor hoeft de browser van een bezoeker niet iedere keer verbinding te maken met een externe fontservice. Dit past bij mijn doel om zo bewust mogelijk om te gaan met de privacy en dataverspreiding van mijn bezoekers.

 <img src="./assets/images-readme/fontsen.png" alt="De fontsen die ik heb bekeken en heb vergeleken voor mijn website" />

Foto" Lettertypes die ik intressant vond.

Bronnen:
[Twisted rope font](https://www.creativefabrica.com/product/twisted-rope)
[Abode fonts](https://fonts.adobe.com)
[Envato](https://elements.envato.com)
[Creative kitting font](https://www.creativefabrica.com/product/creative-knitting)
[Google fonts](https://fonts.google.com)

#### Kleurenpaletten maken

Naast de typografie heb ik verschillende kleurenpaletten samengesteld. Ik wilde onderzoeken welke kleuren het beste aansluiten bij mijn haakprojecten en mijn sfeerwoorden.

Ik keek daarbij naar:

- zachte en warme kleuren;
- kleuren die een cozy gevoel geven;
- voldoende contrast tussen tekst en achtergrond;
- kleuren die passen bij mijn afbeeldingen;
- accentkleuren voor knoppen en belangrijke onderdelen.

Door meerdere kleurenpaletten naast elkaar te zetten, kon ik beter vergelijken welke combinatie het beste bij mijn onderwerp past. Ik wilde voorkomen dat de website te druk zou worden. De haakcreaties moeten centraal blijven staan en de kleuren moeten deze afbeeldingen ondersteunen.

 <img src="./assets/images-readme/kleurpallets.png" alt="De kleuren pallets die ik heb gemaakt voor mijn webside." />
  <img src="./assets/images-readme/gekozen-pallet.png" alt="De kleuren die ik heb gekozen voor mijn website." />
  Foto's: Kleurpalleten

Bron: Adobe color
[Adobe color website](https://color.adobe.com/create/color-wheel)

#### Gebruik van AI voor mijn afbeeldingen

Voor de afbeeldingen op mijn website heb ik mijn eigen foto’s van de gehaakte dieren gebruikt. Wanneer ik zelf nog geen goede foto had, gebruikte ik de voorbeeldfoto van het dier uit het bijbehorende haakpatroon.

Ik heb deze foto’s aan ChatGPT gegeven en gevraagd om er een mooier en duidelijker beeld van te maken. Het was belangrijk dat de gehaakte dieren realistisch bleven en herkenbaar waren als hetzelfde dier. De kleuren, vorm, het gebruikte garen en de verschillende onderdelen moesten daarom hetzelfde blijven.

Daarnaast wilde ik dat alle afbeeldingen op mijn website dezelfde uitstraling kregen. Daarom heb ik bij iedere afbeelding gevraagd om een warme en gezellige omgeving, zachte belichting en natuurlijke materialen. Hierdoor vormen de afbeeldingen samen één geheel en passen ze beter bij de stijl van mijn website.

Voor de procesfoto’s heb ik de prompt aangepast door te beschrijven welke stap zichtbaar moest zijn. Ik vroeg bijvoorbeeld om een foto waarop een onderdeel werd gehaakt, alle losse onderdelen klaar lagen of het dier in elkaar werd gezet.

Na het maken van de afbeeldingen heb ik gecontroleerd of het dier nog overeenkwam met mijn eigen foto of de originele voorbeeldfoto. Wanneer onderdelen, kleuren of vormen niet klopten, heb ik de prompt aangepast en een nieuwe afbeelding laten maken.

##### De prompt's die ik heb gebruikt voor Chatgpt:

Gebruik de bijgevoegde foto van mijn gehaakte dier of de voorbeeldfoto uit het haakpatroon als basis. Maak hiervan een mooie en realistische foto. Het gehaakte dier moet hetzelfde blijven: behoud de vorm, kleuren, verhoudingen, het soort garen en alle herkenbare onderdelen. Plaats het dier in een warme en gezellige omgeving met zachte stoffen en natuurlijk daglicht. Gebruik rustige zand- en bruintinten, zodat de afbeelding past bij de andere foto’s op mijn website. Zorg voor een scherpe en professionele foto, maar laat het beeld wel natuurlijk en handgemaakt aanvoelen. Voeg geen tekst, logo of watermerk toe.

Aanvulling voor procesfoto’s:
Laat zien dat het gehaakte dier nog wordt gemaakt. Toon handen die bezig zijn met haken, vullen of het vastnaaien van een onderdeel. Zorg dat alleen de onderdelen zichtbaar zijn die op dat moment al af horen te zijn. Gebruik dezelfde warme, realistische stijl als bij de andere afbeeldingen.

 <img src="./assets/images-readme/voorenna.png" alt="Voor en na foto's" />
 Foto: het verschil tussen de foto's voor en na chat.

#### Wat heb ik geleerd?

Tijdens deze les heb ik geleerd hoe waardevol het is om mijn ideeën aan iemand anders te laten zien. Zelf bleef ik lang twijfelen tussen verschillende onderwerpen. Door het gesprek met Justus werd duidelijk welk onderwerp het persoonlijkste is en de meeste mogelijkheden biedt.

Ik heb ook geleerd dat mijn onderwerp invloed heeft op bijna alle ontwerpkeuzes. Nadat ik voor haken had gekozen, kon ik gerichter zoeken naar passende kleuren, lettertypen, vormen en afbeeldingen.

Daarnaast ben ik bewuster gaan nadenken over externe diensten. Een lettertype moet niet alleen mooi en leesbaar zijn, maar ook praktisch beschikbaar zijn en op een bewuste manier aan de website worden toegevoegd.

Aan het einde van de les had ik daardoor een veel duidelijkere richting voor mijn digital garden. Ik wist beter welk onderwerp centraal zou staan en welke uitstraling daarbij past.

## Chech-out vrijdag 11 september

Welke feedback heb gehad?
Ik heb alle ontvangen feedback hier boven beschreven.

## voorbereiding 11 september

#### Mobile-first schermschetsen

Ik werkte de gekozen ideeën eerst uit voor een mobiel scherm. Hierdoor moest ik goed nadenken over welke content het belangrijkste is en wat de gebruiker als eerste moet zien.
Voor het kiezen van een Pokémonkaart maakte ik twee varianten:

- Een horizontale waaier waarin de middelste kaart het grootste is en de gebruiker naar links of rechts kan swipen.
- Een verticale indeling waarin de kaarten onder elkaar staan en de gebruiker kan scrollen.
- Voor mijn haakpatronen maakte ik ook twee galerij-indelingen. In de eerste staan grote afbeeldingen onder elkaar. In de tweede worden afbeeldingen afgewisseld met korte teksten. Rond de afbeeldingen tekende ik zachte en wollige vormen om de sfeer van het haken terug te laten komen.

Bij de mobiele schetsen hield ik rekening met:

- een indeling in één kolom;
- de belangrijkste informatie bovenaan;
- grote klikvlakken;
- realistische afbeeldingen en tekst;
- duidelijke koppen;

 <img src="./assets/images-readme/mobielscherm-1.png" alt="" />
  <img src="./assets/images-readme/mobielscherm-2.png" alt="" />
   <img src="./assets/images-readme/mobielscherm-3.png" alt="" />
Foto's: mijn schetsen van de mobile- first schermschetsen.

#### Vertaling naar desktop

Daarna vertaalde ik dezelfde ideeën naar een groter laptopscherm. Ik maakte geen compleet nieuwe ontwerpen, maar onderzocht hoe ik de extra ruimte kon gebruiken.
Op mobiel staat de content vooral onder elkaar. Op desktop kunnen meerdere kaarten of projecten naast elkaar staan. De belangrijkste Pokémonkaart blijft centraal staan, terwijl andere kaarten of binder-artvarianten eromheen worden geplaatst.

Ik lette erop dat:

- het belangrijkste onderdeel het meeste opvalt;
- de extra ruimte nuttig wordt gebruikt;
- meerdere afbeeldingen naast elkaar kunnen staan;
- de visuele hiërarchie hetzelfde blijft;
- hover- en focus-states mogelijk zijn;
- mobiel en desktop herkenbaar bij elkaar horen.

## woensdag 9 september (online les NS-staking)

### Visual Research, Crazy 8 en schermschetsen

Tijdens deze les heb ik verder gewerkt aan de visuele stijl en indeling van mijn digital garden. Ik begon met Visual Research. Daarna maakte ik een Crazy 8, beoordeelde ik mijn ideeën en werkte ik de beste ideeën uit als mobiele en desktop-schetsen.

#### Mijn sfeerwoorden bepalen

Als uitgangspunt voor mijn Visual Research koos ik de sfeerwoorden:

- speels
- cozy
- fantasierijk

  Deze woorden passen bij mijn creatieve onderwerpen, zoals Pokémon binder art, haken, stickers en journalen. Ik wil dat mijn website persoonlijk, creatief en gezellig aanvoelt. De verschillende onderdelen mogen een eigen uitstraling hebben, maar moeten door het gebruik van kleuren en vormen wel bij elkaar passen.
  <img src="./assets/images-readme/9-9-opdracht1.png" alt="Mijn keuze voor mijn sfeerwoorden en de uitleg waarom ik hiervoor heb gekozen." />
  Foto: Mijn keuze voor mijn sfeerwoorden en de uitleg waarom ik hiervoor heb gekozen

#### Stap 1: directe beelden verzamelen

Eerst verzamelde ik afbeeldingen die direct passen bij mijn hobby’s en sfeerwoorden. Ik zocht onder andere naar Pokémon, binder art, haakprojecten, journals, stickers en andere creatieve producten.
Ik keek niet alleen naar het onderwerp van de afbeeldingen, maar ook naar kleur, vorm, materiaal en uitstraling. Ik zag vooral zachte vormen, vrolijke kleuren, handgemaakte materialen en fantasierijke illustraties terug.
<img src="./assets/images-readme/9-9-opdracht2.png" alt="De afbeeldingen die ik heb gebruikt in mijn presentatie" />
Foto:De afbeeldingen die ik heb gebruikt in mijn presentatie

#### Stap 2: abstracte beelden verzamelen

Daarna zocht ik naar abstractere beelden. Hierbij keek ik minder naar de hobby’s zelf en meer naar de visuele kenmerken die bij mijn sfeerwoorden passen.
Ik verzamelde voorbeelden van:
zachte en organische vormen;
afgeronde vlakken;
vrolijke kleuren en pastelkleuren;
collages en patronen;
speelse typografie;
onderdelen die in elkaar overlopen.
Hierdoor ontdekte ik dat niet alleen het onderwerp, maar ook de kleuren, vormen, typografie en plaatsing de sfeer van mijn website bepalen.
<img src="./assets/images-readme/9-9-opdracht3.png" alt="Inspiratie op zoeken om mijn sfeer woorden een vusieel beeld te geven." />
Foto: Inspiratie op zoeken om mijn sfeer woorden een vusieel beeld te geven.

#### Stap 3: visuele uitgangspunten bepalen

Uit mijn verzameling koos ik vier afbeeldingen die mij het meeste aanspraken. Per afbeelding beschreef ik waarom deze bij mijn sfeerwoorden past en welke kenmerken ik kan gebruiken.
Daaruit kwamen de volgende visuele uitgangspunten:

- Ik gebruik afgeronde en organische vormen.
- Ik werk met zachte kleuren en enkele fellere accenten.
- Onderdelen mogen speels worden geplaatst.
- Mijn eigen projecten en afbeeldingen staan centraal.
- De website moet cozy en persoonlijk aanvoelen.
- De verschillende hobby’s moeten herkenbaar zijn, maar wel bij dezelfde stijl horen.
  <img src="./assets/images-readme/9-9-opdracht4.png" alt="Jouw 4 gekozen afbeelding beoordelen aan de hand van 3 vragen" />
  Foto: Jouw 4 gekozen afbeelding beoordelen aan de hand van 3 vragen

#### Crazy 8 maken

Na het Visual Research maakte ik een Crazy 8. Hierbij schetste ik in korte tijd acht verschillende ideeën:

1. Kiezen tussen Pokémonkaarten waarvoor ik binder art heb gemaakt.
2. Een kaart kiezen en de bijbehorende binder-artvarianten bekijken.
3. Mijn haakpatronen als een galerij presenteren.
4. Zelf een stickervel samenstellen.
5. Mijn creatieve proces als een flow weergeven.
6. Pokémon-types als gekleurde tegels vormgeven.
7. Het eindresultaat en proces naast elkaar tonen.
8. Extra informatie tonen wanneer de gebruiker over een bolletje beweegt of erop klikt.
   Na het schetsen annoteerde ik de ideeën. Met pijlen en korte teksten gaf ik aan wat een gebruiker kan doen en welke interacties ik voor mij zie.
   <img src="./assets/images-readme/9-9-opdracht5.png" alt="Opdracht een crazy 8 maken" />
   Foto: Opdracht een crazy 8 maken

#### Mijn ideeën beoordelen

Vervolgens beoordeelde ik de acht ideeën met het bijbehorende werkvel. Per idee keek ik of het ontwerp:

- fluïde en adaptief is;
- interactief en dynamisch is;
- toegankelijk is;
- binnen de beschikbare tijd gemaakt kan worden;
- expressief genoeg is;
- leuk of verrassend is.
  Hierdoor keek ik niet alleen naar welke ideeën ik mooi vond, maar ook naar welke ideeën geschikt en haalbaar zijn voor het web. Het zelf samenstellen van een stickervel is bijvoorbeeld erg interactief, maar waarschijnlijk ook lastiger om binnen deze sprint te bouwen.
  <img src="./assets/images-readme/9-9-opdracht6.png" alt="Mijn beoordelings formulier voor de crazy 8" />
  Foto: Mijn beoordelings formulier voor de crazy 8

#### Ideeën verder uitwerken

Na de beoordeling koos ik drie ideeën om verder te onderzoeken:
Kiezen tussen verschillende Pokémonkaarten.
Binder art bekijken voor een gekozen kaart.
Haakpatronen als een galerij presenteren.
Bij het eerste idee controleert de gebruiker of de eigen Pokémonkaart ertussen staat. Daarna kan de gebruiker bij het tweede idee bekijken welke binder-artvarianten ik voor deze kaart heb gemaakt.
Deze ideeën passen goed bij mijn content en geven mij mogelijkheden om te experimenteren met scrollen, swipen, selecteren en het tonen van afbeeldingen.

## Check-out woe. 9 sept.

1. Leg uit waar het Visual Research in 3 stappen naartoe werkt.

Bij stap 1 verzamel je directe beelden die bij je onderwerp en sfeerwoorden passen. Bij stap 2 zoek je abstractere beelden die passen bij de kleuren, vormen, typografie en uitstraling die je wilt gebruiken. Bij stap 3 kies je de belangrijkste beelden en vertaal je deze naar visuele uitgangspunten voor je eigen ontwerp.

2. Vertel in 2 zinnen waar jouw Garden over gaat en met welke content je dat gaat doen (beeld, tekst, sound, animatie enz.).

Mijn digital garden gaat over mijn haakwereld en de knuffels die ik zelf maak. Ik gebruik hiervoor foto’s, teksten, illustraties en animaties om mijn creaties en het maakproces te laten zien.

3. Vertel kort welk idee van de Crazy 8 je het liefst zou willen uitvoeren of verder zou willen onderzoeken.

Van mijn Crazy 8 wil ik het idee van de haakpatronen als galerij verder onderzoeken. Dit idee past het beste bij mij en kan ik persoonlijk maken met zachte vormen, gehaakte omlijstingen en interactieve afbeeldingen.

## Voorbereiding 9 september

### Presentatie over mijn creatieve interesses

Voor woensdag 9 september moest ik een korte presentatie voorbereiden als startpunt voor mijn digital garden. In de presentatie moest ik:
mijn persoonlijke interesse uitleggen;
tien inspiratiebronnen verzamelen;
ongeveer vijftig afbeeldingen onderzoeken;
een eerste tekst van maximaal 180 tekens schrijven.

#### Een onderwerp kiezen

Eerst vond ik het lastig om een geschikt onderwerp te kiezen. Mijn eerste idee was om de presentatie over mijn studie CMD te maken. Nadat ik de opdracht beter had bekeken, begreep ik dat het onderwerp echt over een persoonlijke interesse moest gaan.
Daarna twijfelde ik tussen alleen Pokémon binder art en meerdere creatieve hobby’s. Uiteindelijk koos ik voor mijn creatieve interesses:

- haken;
- Pokémon binder art maken;
- stickers ontwerpen en maken;
- journalen.

Deze hobby’s lijken misschien verschillend, maar hebben veel overeenkomsten. Bij iedere hobby werk ik met kleuren, materialen en kleine details. Vaak begin ik met losse ideeën die tijdens het maken steeds verder groeien.
<img src="./assets/images-readme/presentatie1.png" alt="slide met alle hobby's" />
Foto: slide met alle hobby's

#### Inspiratie en afbeeldingen verzamelen

Voor iedere hobby heb ik afbeeldingen verzameld en een eigen collage gemaakt. Hierdoor hoefde ik niet alle vijftig afbeeldingen op één drukke slide te zetten. Ik verdeelde de collages over aparte slides voor haken, binder art, stickers en journalen.

Tijdens het onderzoeken van de afbeeldingen ontdekte ik verschillende overeenkomsten:
opvallende en bijpassende kleurencombinaties;
speelse vormen en kleine details;
digitaal en met de hand werken;
losse onderdelen samenbrengen tot één geheel;
experimenteren en ontwerpen blijven aanpassen;
iets persoonlijks en unieks maken.
Daarnaast heb ik tien links verzameld die ik als inspiratiebronnen heb gebruikt. Hiervoor heb ik gekeken naar Pokémonkaarten, haakpatronen, stickers, journals en andere creatieve voorbeelden.
<img src="./assets/images-readme/haken.jpg" alt="collage haken" />
Foto: collage Haken.

<img src="./assets/images-readme/binder-art.jpg" alt="collage binder-art" />
foto: collage Pokemon binder art.

<img src="./assets/images-readme/journal.jpg" alt="collage journal" />
Foto: collage journaling.

<img src="./assets/images-readme/stickers.jpg" alt="collage stickers" />
Foto: collage stickers

#### De presentatie maken met Remark.js

Ik heb de presentatie met Remark.js gemaakt in Visual Studio Code. Iedere nieuwe slide begint met drie streepjes:
(---)
Voor titels gebruikte ik een # en voor opsommingen een -. In mijn presentatiemap maakte ik een aparte map met de naam images. Hierin plaatste ik alle collages en screenshots.

## Maandag 7 september

### Sprintplanning en onderzoek

#### Sprintplanning

Tijdens deze les zijn we begonnen met de planning van Sprint 1. De opdracht voor deze sprint is om de eerste versie van mijn eigen digital garden te ontwerpen, te realiseren en uiteindelijk te publiceren met HTML en CSS.
Het is daarbij niet alleen belangrijk dat mijn website er goed uitziet en technisch werkt. Het ontwerp moet ook ‘webby’ zijn. Dit betekent dat ik gebruik moet maken van de mogelijkheden en eigenschappen van het web. Mijn digital garden moet dus niet aanvoelen als een statische poster die toevallig online staat, maar als een website waarop bezoekers kunnen navigeren, ontdekken en verschillende soorten content kunnen bekijken.
Tijdens deze sprint wil ik daarom niet alleen aandacht besteden aan de vormgeving. Ik wil ook nadenken over de structuur, navigatie, interactie en de manier waarop verschillende onderwerpen met elkaar verbonden kunnen worden.

#### Mijn sprint plannen

Tijdens de sprintplanning hebben we gekeken naar hoe ik het werk voor deze sprint kan opdelen in kleinere en overzichtelijke taken. Hiervoor gebruiken we een projectboard met drie kolommen:

- Todo
- In Progress
- Done
  In de kolom Todo staan de taken waaraan ik nog moet beginnen. Wanneer ik met een taak bezig ben, verplaats ik deze naar In Progress. Zodra een taak helemaal is afgerond, kan ik deze verplaatsen naar Done.

Ik vind deze manier van plannen handig, omdat ik hierdoor niet alleen één grote opdracht voor mij zie. De opdracht wordt verdeeld in kleinere onderdelen die ik één voor één kan uitvoeren. Hierdoor kan ik beter zien wat er nog moet gebeuren en wordt het makkelijker om aan de opdracht te beginnen.
Door de taken steeds van Todo naar In Progress en uiteindelijk naar Done te verplaatsen, kan ik mijn voortgang tijdens de sprint bijhouden. Het geeft mij ook een duidelijker beeld van wat ik al heb gedaan en waar ik nog verder aan moet werken.

#### Onderzoek naar Digital Gardens

Na de sprintplanning hebben we ons verdiept in wat een digital garden precies is. Hiervoor hebben we verschillende artikelen gelezen en besproken.
We werkten hierbij volgens de expertgroepenmethode. Iedere groep verdiepte zich in een ander artikel. Daarna deelden we de belangrijkste informatie en inzichten met elkaar. Op deze manier hoefde niet iedereen precies hetzelfde artikel te onderzoeken en kregen we toch informatie uit meerdere bronnen.
Door de verschillende artikelen kreeg ik meerdere perspectieven op wat een digital garden kan zijn. Er bestaat namelijk niet één vaste manier waarop een digital garden eruit moet zien. Toch kwamen bepaalde eigenschappen in meerdere artikelen terug.
De belangrijkste onderwerpen die ik uit het onderzoek heb gehaald, zijn:

- een digital garden blijft groeien;
- informatie wordt georganiseerd op basis van \* verbindingen;
- het is een plek om zichtbaar te leren;
- fouten en feedback horen bij het proces;
- de website mag persoonlijk en experimenteel zijn;
- verschillende soorten content mogen door elkaar staan;
- de maker blijft eigenaar van de website en de inhoud.

#### Een Digital Garden is een groeiende plek

Een van de belangrijkste dingen die ik uit de artikelen heb gehaald, is dat een digital garden niet af hoeft te zijn.

Een normale blog bestaat vaak uit losse artikelen. Deze artikelen worden geschreven, gepubliceerd en daarna meestal niet meer aangepast. De berichten staan vaak op volgorde van publicatiedatum, waarbij het nieuwste bericht bovenaan staat.
Bij een digital garden werkt dit anders. Pagina’s en ideeën mogen blijven veranderen. Een idee kan klein en nog onvolledig beginnen. Later kan de pagina worden uitgebreid wanneer de maker meer over het onderwerp leert, nieuwe inspiratie krijgt of feedback ontvangt.
Maggie Appleton beschrijft hiervoor verschillende stadia waarin een pagina zich kan bevinden:

- Seedling – een vroeg, klein en nog ruw idee;
- Budding – een idee dat al verder is onderzocht en uitgewerkt;
- Evergreen – een redelijk compleet idee dat nog steeds kan blijven veranderen.

Ik vond deze verdeling interessant, omdat hierdoor zichtbaar wordt dat niet iedere pagina op een website even ver uitgewerkt hoeft te zijn. Een korte ontdekking kan al gedeeld worden als een Seedling. Wanneer ik later meer informatie verzamel, kan deze pagina doorgroeien naar Budding en uiteindelijk naar Evergreen.
Dit haalt voor mij ook een deel van de druk weg om een pagina meteen helemaal perfect te maken. Het hoort juist bij het concept van een digital garden dat sommige ideeën nog aan het groeien zijn.

#### Informatie organiseren op basis van verbindingen

Een ander belangrijk verschil tussen een blog en een digital garden is de manier waarop de informatie wordt georganiseerd.
Bij een blog staan berichten meestal in een tijdlijn. Het nieuwste bericht staat bovenaan en oudere berichten zakken steeds verder naar beneden. De datum waarop iets is gepubliceerd, bepaalt dus voor een groot deel waar de informatie staat.
Bij een digital garden draait het veel meer om de verbindingen tussen verschillende onderwerpen. Pagina’s worden aan elkaar gekoppeld omdat de inhoud iets met elkaar te maken heeft. Een bezoeker hoeft daardoor niet één vaste route te volgen, maar kan via links steeds nieuwe onderwerpen ontdekken.
Ik vond het beeld van Maggie Appleton hierover erg duidelijk. Een traditionele tijdlijn is één rechte route, terwijl een digital garden meer lijkt op een verzameling van paden die op verschillende manieren met elkaar verbonden zijn.
Mike Caulfield beschrijft ongeveer hetzelfde verschil met de begrippen The Garden en The Stream.

- The Stream
  De Stream lijkt op sociale media. Berichten verschijnen in een tijdlijn en worden na verloop van tijd vervangen door nieuwe berichten. Oudere informatie verdwijnt steeds verder naar beneden en wordt daardoor moeilijker terug te vinden.
- The Garden
  De Garden is juist een plek waarin informatie kan blijven bestaan en verder kan groeien. Verschillende onderwerpen kunnen met elkaar worden verbonden. De bezoeker kan zelf kiezen welke route die door de informatie wil volgen.
  Dit inzicht helpt mij om anders naar de structuur van mijn eigen website te kijken. Ik hoef mijn content niet alleen op datum te sorteren. Ik kan onderwerpen ook met elkaar verbinden op basis van overeenkomsten, technieken, materialen of inspiratie.

Bij mijn eigen digital garden kan een bezoeker bijvoorbeeld vanuit een eindresultaat doorklikken naar het maakproces, de inspiratie, een experiment of een andere creatie waarin ik dezelfde techniek heb gebruikt.

#### Een plek om zichtbaar te leren

Een digital garden is niet alleen bedoeld om aan anderen te laten zien wat iemand al weet. Het kan ook een plek zijn waarop je zichtbaar maakt wat je nog aan het leren bent.
Shawn Wang noemt dit Learning in Public. Binnen zijn digital garden mogen ideeën nog onvolledig zijn en mag hij fouten maken. De bedoeling is juist dat zijn kennis blijft veranderen wanneer hij iets nieuws leert of feedback ontvangt.
Dit maakt een digital garden voor mij anders dan een portfolio. In een portfolio laat ik meestal mijn beste en meest uitgewerkte werk zien. Het eindresultaat staat daar vaak centraal.

In een digital garden mag ik juist ook laten zien:

- welke ideeën ik heb onderzocht;
- welke vragen ik nog heb;
- welke experimenten wel of niet werkten;
- wat ik tijdens het maken heb ontdekt;
- hoe mijn ontwerp is veranderd;
- welke feedback ik heb ontvangen;
- wat ik later nog verder wil onderzoeken.
  Hierdoor hoeft mijn digital garden niet alleen een verzameling van perfecte eindproducten te worden. Het mag ook een verzameling zijn van schetsen, experimenten, ontdekkingen en ideeën die nog in ontwikkeling zijn.

Dit past goed bij mijn eigen ontwerp- en maakproces. Mijn eerste idee is namelijk niet altijd meteen het uiteindelijke idee. Door mijn tussenstappen te laten zien, wordt beter zichtbaar hoe ik tot een eindresultaat ben gekomen.

#### Feedback en fouten horen bij het proces

Bij Learning in Public hoort ook dat andere mensen feedback kunnen geven.

In het artikel Digital Garden Terms of Service wordt beschreven dat bezoekers mogen aangeven wanneer informatie niet klopt of wanneer zij het ergens niet mee eens zijn. De schrijver ziet dit niet meteen als iets negatiefs, maar juist als een mogelijkheid om verder te leren.
Wanneer nieuwe informatie laat zien dat iets niet klopt, kan een pagina opnieuw worden aangepast. De inhoud staat dus niet voor altijd vast.

Dit sluit goed aan bij het idee dat een digital garden nooit helemaal klaar is. Feedback, nieuwe kennis en nieuwe ervaringen kunnen ervoor zorgen dat een pagina opnieuw verandert.
Ik vind dit een interessant uitgangspunt voor mijn eigen website. Als een onderdeel nog niet goed werkt of als ik later een beter idee krijg, betekent dit niet dat mijn eerdere werk waardeloos was. Het laat juist zien hoe mijn kennis en ontwerp zich ontwikkelen.

#### Mijn eigen website bezitten

Een ander onderwerp dat in het onderzoek naar voren kwam, is independent ownership. Dit betekent dat je digital garden echt van jezelf is en niet volledig afhankelijk is van een bestaand platform.
Wanneer iemand alleen gebruikmaakt van Instagram, TikTok, Facebook, X of Medium, bepaalt dat platform voor een groot deel hoe de content eruitziet en hoe bezoekers deze kunnen bekijken. Als het platform de regels of mogelijkheden verandert, heb je daar als gebruiker weinig controle over.

Bij een eigen website heb ik meer controle over:

- de vormgeving;
- de indeling van de pagina’s;
- de navigatie;
- de soorten content die ik plaats;
- de verbindingen tussen onderwerpen;
- de manier waarop mijn website zich later ontwikkelt.

Met HTML en CSS bouw ik mijn eigen plek op het internet. Ik kan daardoor zelf bepalen hoe mijn digital garden eruitziet en hoe bezoekers door de inhoud bewegen.
Dit sluit goed aan bij de opdracht, omdat we onze digital garden zelf gaan ontwerpen, bouwen en publiceren.

#### Waar had ik het meeste aan?

Waar ik tijdens deze les het meeste aan had, was het idee dat een digital garden niet af hoeft te zijn.
Normaal heb ik snel het gevoel dat iets eerst helemaal goed en uitgewerkt moet zijn voordat ik het kan laten zien. Bij een digital garden hoort het juist bij het concept dat ideeën nog groeien en veranderen.

Ik vond vooral het verschil tussen Seedling, Budding en Evergreen duidelijk. Deze termen maken zichtbaar dat niet iedere pagina hetzelfde niveau van uitwerking hoeft te hebben. Een klein idee kan al onderdeel zijn van de website en later verder worden aangevuld.
Ook het verschil tussen The Garden en The Stream heeft mij geholpen. Ik begrijp hierdoor beter dat ik mijn website niet alleen als een lijst met nieuwe berichten moet zien. Ik kan onderwerpen juist met elkaar verbinden, zodat bezoekers zelf verschillende routes door mijn website kunnen volgen.
Daarnaast vond ik het idee van Learning in Public interessant. Mijn digital garden hoeft niet alleen te laten zien wat ik al kan. Ik mag ook laten zien wat ik nog aan het ontdekken en leren ben.

## chech-out: heel kort

1. Een digital garden is een persoonlijke website waarop ideeën en projecten blijven groeien. Anders dan een gewone website hoeft de inhoud niet direct af of perfect te zijn.

2. Een website is ‘webby’ wanneer je de mogelijkheden van het web gebruikt, zoals links, interacties, animaties en verschillende routes. Vooral persoonlijke en speelse websites inspireren mij.

3. Ik wil mijn digital garden over mijn haakwereld maken. Hierin wil ik mijn haakcreaties, patronen, inspiratie en maakproces op een persoonlijke en interactieve manier laten zien.

## Voorbereiding maandag 7 september: We hebben voor deze les geen voorbereiding.

# Sprint 0:

## vrijdag 4 september

### Deep Dive schetsen

Tijdens deze Deep Dive heb ik geleerd dat schetsen niet alleen bedoeld is om iets mooi te tekenen. Het helpt vooral om na te denken, ideeën te onderzoeken en ontwerpkeuzes zichtbaar te maken. Een belangrijke uitspraak uit de les was:
Schetsen = denken = niet in één keer ‘klaar’.
Een schets hoeft dus niet perfect te zijn. Het belangrijkste is dat ik ideeën snel zichtbaar kan maken en verschillende mogelijkheden kan vergelijken.

#### Oude schetsen vergelijken

Voor de eerste opdracht heb ik schetsen uit eerdere projecten meegenomen, zoals logoschetsen, Crazy 8’s, interfaces, typografie, positionering en uitgewerkte tekeningen.
Mijn tekening van D’Oude Veiling laat duidelijk het eindresultaat zien, maar minder goed hoe ik tot dit ontwerp ben gekomen. Mijn Crazy 8 ziet er minder netjes uit, maar laat juist verschillende oplossingen zien. Bij mijn schetsen voor de positionering en typografie van mijn campagnewebsite is mijn proces nog duidelijker zichtbaar door de varianten en annotaties.
Hierdoor leerde ik dat een mooie schets niet automatisch een goede ontwerpschets is.

#### Een goede schets

Een goede schets hoeft voor mij niet perfect te zijn, maar moet wel mijn denkproces zichtbaar maken. Daarbij helpen:

- meerdere ideeën en varianten;
- annotaties, pijlen en korte teksten;
- verschillende lijndiktes, kleuren, highlights en schaduwen;
- het zichtbaar maken van interacties en verschillende states.
  Annotaties zijn handig omdat ik daarmee iets kan uitleggen zonder alles volledig te tekenen.

#### Oefenen met de basis

We hebben geoefend met lijnen, vormen, grids en interfaces. Ik heb geleerd dat ik eerst met eenvoudige vormen de basis kan neerzetten en daarna details kan toevoegen.
Ook hebben we het verschil tussen low-fi en hi-fi behandeld. Een low-fi schets is eenvoudig en bedoeld om snel een idee of indeling te onderzoeken. Een hi-fi uitwerking bevat meer details en lijkt meer op het uiteindelijke ontwerp.
Met dikkere lijnen en highlights kan ik belangrijke onderdelen benadrukken. Schaduwen kunnen bijvoorbeeld duidelijk maken dat iets klikbaar is. Door annotaties in een andere kleur te schrijven, blijft het verschil tussen mijn ontwerp en mijn uitleg zichtbaar.
Interactie en animatie schetsen

Een website bestaat niet alleen uit stilstaande schermen. Een gebruiker kan klikken, swipen en hoveren. Deze interacties kan ik schetsen met pijlen, stippellijnen, annotaties, kleuren en verschillende states.
Met de zoom-techniek kan ik één onderdeel groter tekenen om te laten zien wat er verandert. In de les zagen we bijvoorbeeld hoe een sidebar verschijnt, hoe een icoon verandert nadat het is geselecteerd en hoe een swipe nieuwe opties zichtbaar maakt.

#### Wat heb ik hier het meest van geleerd?

Ik heb vooral geleerd dat schetsen een manier van denken is. Het is juist waardevol om meerdere versies te maken, dingen opnieuw te proberen en erbij te schrijven waarom ik bepaalde keuzes maak.
Bij het ontwerpen van mijn website wil ik daarom niet meteen één idee volledig uitwerken. Ik wil eerst verschillende mogelijkheden onderzoeken. Daarbij ga ik ook schetsen hoe gebruikers door mijn website bewegen en hoe onderdelen reageren op klikken, swipen en hoveren.

### Deep Dive – Pick 'n' Mix

Tijdens de Deep Dive hebben we verder gekeken naar hoe je een passend lettertype kiest en hoe je verschillende lettertypes met elkaar kunt combineren. Daarbij kwamen veel dingen uit de artikelen terug.
Bij het kiezen van een lettertype kan ik onder andere kijken naar:

- stijl – past de uitstraling bij wat ik wil communiceren?
- leesbaarheid – blijft de tekst duidelijk?
- opties – welke varianten en mogelijkheden heeft de fontfamilie?
- beschikbaarheid – kan en mag ik het lettertype daadwerkelijk gebruiken?
  We hebben ook gekeken naar de geschiedenis van verschillende soorten lettertypes. In de slides kwamen onder andere Fraktur, Venetian, Old Face, Transitional, Modern, Egyptian en Sans voorbij. Hierdoor kon ik goed zien dat lettertypes door de jaren heen steeds andere kenmerken hebben gekregen.

#### Leesbaarheid

Een onderdeel waar ik veel aan had was het verschil in leesbaarheid tussen lettertypes.
Zelfs wanneer verschillende lettertypes allemaal op bijvoorbeeld 18 px staan, kunnen ze toch heel verschillend groot ogen. Dit komt onder andere door de x-hoogte en de verhoudingen van de letters. In de slides werd dit zichtbaar gemaakt door verschillende lettertypes op dezelfde grootte naast elkaar te zetten.
Hierdoor begrijp ik beter dat ik bij mijn website niet alleen kan zeggen: "18 px is groot genoeg." Ik moet het lettertype daadwerkelijk op mijn website bekijken en testen of het prettig leesbaar is.

#### Lettertypes combineren

We hebben daarna gekeken naar het combineren van lettertypes. Wat ik hiervan vooral heb onthouden, is dat een goede combinatie vaak bestaat uit een balans tussen contrast en overeenkomst.
Contrast kan bijvoorbeeld ontstaan door:

- sans serif tegenover serif;
- bold tegenover light;
- narrow tegenover wide;
- roman tegenover italic of small caps.
  Tegelijkertijd kunnen de lettertypes overeenkomsten hebben, bijvoorbeeld doordat ze uit dezelfde fontfamilie komen, dezelfde letterontwerper hebben, een vergelijkbare constructie hebben of uit ongeveer dezelfde periode komen.
  Ik vond dit vooral handig omdat ik hiervoor bij het combineren van lettertypes voornamelijk keek naar of ik ze mooi bij elkaar vond staan. Nu weet ik beter naar welke eigenschappen ik kan kijken om uit te leggen waarom twee lettertypes wel of niet bij elkaar passen.

#### Waar had ik het meeste aan?

Waar ik het meeste aan had, is dat ik nu veel beter begrijp dat een lettertype kiezen niet alleen een visuele keuze is. Hiervoor keek ik vooral naar welk lettertype ik mooi vond en of het bij mijn ontwerp paste. Nu weet ik dat ik ook moet kijken naar leesbaarheid, x-hoogte, verschillende gewichten en stijlen, taalondersteuning, het apparaat waarop de tekst wordt bekeken en waarvoor het lettertype gebruikt gaat worden.
Voor mijn eigen website vind ik vooral de leesbaarheid belangrijk. Mijn portfolio moet er natuurlijk bij mij passen en een eigen uitstraling hebben, maar bezoekers moeten de informatie ook makkelijk kunnen lezen en snel kunnen vinden.
Ook het combineren van lettertypes vond ik erg nuttig. Ik weet nu dat ik niet zomaar twee mooie lettertypes naast elkaar moet zetten, maar dat ik kan zoeken naar een combinatie met zowel contrast als overeenkomst. Dat geeft mij veel meer houvast wanneer ik straks de typografie voor mijn eigen website ga bepalen.

Wat ik uiteindelijk vooral meeneem uit deze voorbereiding en Deep Dive is:
Ik moet een lettertype niet alleen kiezen omdat ik het mooi vind, maar omdat het past bij de boodschap, goed leesbaar is én goed werkt op de plek waar ik het ga gebruiken.

## Check-out vrijdag 4 sept: vanwege de Deep-dives hadden we geen chech-out vandaag.

## voorbereiding voor 4 september

### Voorbereiding Deep Dive: Typografie

Voor deze Deep Dive heb ik twee artikelen gelezen over het kiezen en gebruiken van lettertypes. Tijdens het lezen heb ik per artikel de dingen opgeschreven die ik het belangrijkste of opvallendste vond.

### Artikel 1: How to choose the right typeface

In dit artikel wordt uitgelegd dat het kiezen van een lettertype niet alleen gaat om welk lettertype je mooi vindt. Je moet vooral kijken naar waarvoor je het lettertype gaat gebruiken, wat je ermee wilt uitstralen en of het technisch geschikt is.

Wat ik uit dit artikel heb gehaald:

1. Kijk eerst waarvoor je het lettertype gaat gebruiken.Een lettertype voor een grote titel heeft andere eigenschappen nodig dan een lettertype voor lange stukken tekst. Bij langere teksten is leesbaarheid veel belangrijker, terwijl je bij een grote titel meer ruimte hebt voor een opvallend lettertype.

2. Gebruik liever niet te veel verschillende lettertypes.Voor veel ontwerpen kan één goede fontfamilie al genoeg zijn, omdat daar bijvoorbeeld regular, bold en italic varianten in zitten. Meer lettertypes gebruiken betekent dus niet automatisch dat een ontwerp beter wordt.

3. Een lettertype moet passen bij de boodschap die je wilt overbrengen.Lettertypes hebben een bepaalde uitstraling en kunnen daardoor invloed hebben op hoe de inhoud overkomt. Een lettertype kan bijvoorbeeld formeel, modern, rustig of juist opvallend voelen. Het is daarom belangrijk dat de uitstraling past bij de boodschap van het ontwerp.

4. Controleer welke tekens en talen een lettertype ondersteunt.Dit vond ik iets waar ik zelf niet zo snel aan zou denken. Niet ieder lettertype bevat automatisch alle accenten, symbolen en speciale tekens. Je kunt dus een mooi lettertype kiezen en er later achter komen dat bepaalde tekens die je nodig hebt ontbreken.

5. Niet ieder lettertype werkt even goed op een scherm.Sommige lettertypes zijn speciaal gemaakt om ook op kleinere formaten en beeldschermen goed leesbaar te blijven. Hele dunne of gedetailleerde letters kunnen er mooi uitzien, maar op een klein scherm juist minder goed werken.

6. Bij het combineren van lettertypes moet er samenhang én verschil zijn.Lettertypes hoeven niet precies hetzelfde te zijn om goed bij elkaar te passen. Het kan juist helpen als er contrast is, maar ze moeten wel een bepaalde overeenkomst hebben in bijvoorbeeld uitstraling of bedoeling. Ook helpt het als de lettertypes verschillende functies krijgen, bijvoorbeeld één voor koppen en één voor lopende tekst.

### Artikel 2: Typography for User Interfaces

Bij dit artikel ging het veel meer over typografie binnen interfaces en websites. Wat ik hier vooral interessant aan vond, is dat tekst eigenlijk een heel groot onderdeel van een interface is. Typografie bepaalt daardoor niet alleen hoe een website eruitziet, maar ook hoe makkelijk iemand hem kan gebruiken.

Wat ik uit dit artikel heb gehaald:

1. Tekst is een onderdeel van de interface zelf.Een interface bestaat voor een groot deel uit woorden: knoppen, menu's, titels, labels en andere teksten. Typografie is daarom niet alleen iets wat je achteraf mooi maakt, maar hoort echt bij het ontwerpen van de interface.

2. Letters moeten duidelijk van elkaar te onderscheiden zijn.Bij een interface is leesbaarheid extra belangrijk. Letters zoals een hoofdletter I, kleine l en bijvoorbeeld het cijfer 1 kunnen bij sommige lettertypes heel erg op elkaar lijken. Hierdoor moet een gebruiker meer moeite doen om de tekst te begrijpen.

3. Een goed lettertype voor een interface hoeft niet de aandacht te trekken.Het lettertype moet de gebruiker vooral helpen om de inhoud te begrijpen. Het hoeft dus niet altijd het meest bijzondere of opvallende lettertype te zijn. De gebruiker moet eigenlijk zonder moeite kunnen lezen wat er staat.

4. Een UI-lettertype moet op verschillende formaten werken.Een website kan bekeken worden op een groot computerscherm, maar ook op een kleine telefoon. Daarom moet een lettertype flexibel zijn en ook bij kleinere tekstgroottes goed leesbaar blijven.

5. De x-hoogte heeft invloed op de leesbaarheid.De x-hoogte is de hoogte van kleine letters, gemeten aan bijvoorbeeld de letter x. Een grotere x-hoogte kan ervoor zorgen dat tekst op kleine formaten makkelijker leesbaar is. Te groot is alleen ook weer niet altijd beter, omdat sommige letters dan juist moeilijker van elkaar te onderscheiden kunnen worden.

6. Mensen lezen tekst in een interface anders dan een lange tekst.In een interface staan vaak losse woorden of korte stukjes tekst, zoals bij een menu of knop. Daardoor is het extra belangrijk dat individuele letters en woorden snel herkenbaar zijn.

#### Wat vond ik het opvallendst?

Ik vond het interessant dat een lettertype binnen een interface eigenlijk niet te veel aandacht hoeft te trekken. In eerste instantie kijk ik bij een lettertype snel naar de uitstraling. Door dit artikel begrijp ik beter dat een lettertype vooral de gebruiker moet ondersteunen en de inhoud duidelijk moet maken.

#### Wat heb ik van deze voorbereiding geleerd?

Door deze twee artikelen begrijp ik dat typografie veel meer is dan het kiezen van een mooi lettertype. Een lettertype moet passen bij het doel en de uitstraling van mijn website, maar het moet vooral goed leesbaar en bruikbaar zijn.
Bij het kiezen van mijn lettertypes wil ik daarom letten op:

- de leesbaarheid van titels en lopende tekst;
- de uitstraling die bij mijn onderwerp past;
- het aantal lettertypes en varianten;
- de herkenbaarheid van verschillende letters en cijfers;
- de beschikbare tekens en symbolen;
- de leesbaarheid op desktop en mobiel;
- het verschil en de samenhang tussen mijn fonts.

Wat ik vooral meeneem, is dat ik mijn keuze niet alleen moet kunnen uitleggen met ‘ik vind dit lettertype mooi’. Ik moet ook kunnen onderbouwen waarom het bij mijn website past en waarom het voor de gebruiker prettig leesbaar is.

## woensdag 2 september

### verwerking van de les

#### Voorbereiding

Voor deze les had ik de artikelen van Interneting Is Hard gelezen en de pagina Structuring content with HTML van MDN gescand. Tijdens het lezen heb ik aantekeningen gemaakt en twee vragen meegenomen naar de les. Ook had ik opgeschreven welke dingen mij tijdens het lezen verwonderden.
Mijn volledige aantekeningen en voorbereiding staan eerder in mijn Learning Log.

#### Antwoorden op mijn vragen

Tijdens mijn voorbereiding had ik twee vragen opgeschreven die ik tijdens de les wilde stellen.

1. Wanneer kan ik beter een HTML-element als selector gebruiken en wanneer een class?
   Tijdens de les kwam ik erachter dat we binnen dit project geen classes mogen gebruiken. Het is juist de bedoeling dat we leren om HTML-elementen op andere manieren te selecteren met CSS. Hierdoor moet ik dus verder kijken dan alleen een class toevoegen wanneer ik één specifiek onderdeel wil vormgeven.
   Dit vind ik eigenlijk wel interessant, omdat ik normaal waarschijnlijk snel een class zou gebruiken. Nu word ik gedwongen om beter naar mijn HTML-structuur en CSS-selectors te kijken.

2. Welke CSS-regel krijgt voorrang wanneer meerdere regels hetzelfde element aanpassen?
   Ik heb geleerd dat de volledige manier waarop CSS bepaalt welke regel voorrang krijgt best complex is. De docent gaf aan dat we daar op dit moment nog niet helemaal diep op in hoeven te gaan.
   Wat ik voor nu vooral moet onthouden is:
   Hoe specifieker een CSS-regel is, hoe meer voorrang deze heeft.
   Voor nu is dit voldoende om mee te werken. Later gaan we waarschijnlijk dieper in op hoe deze voorrang precies wordt berekend.

#### Wat mij verwonderde

Tijdens mijn voorbereiding had ik al een aantal dingen gevonden die mij verwonderden, onder andere tijdens het scannen van MDN. Zo kwam ik erachter dat een decoratieve afbeelding juist een lege alt="" kan krijgen en dat ‘klik hier’ geen goede tekst voor een link is.
Deze verwonderingen en mijn uitleg daarbij heb ik al bij mijn voorbereiding uitgewerkt.

#### Nieuwe bron uit de les; HTML5 Doctor

Tijdens de les kregen we ook HTML5 Doctor als website mee. Deze website kan ik gebruiken om meer te ontdekken over HTML-elementen en om op te zoeken waarvoor verschillende elementen bedoeld zijn.
Dit sluit goed aan op wat we nu aan het leren zijn, omdat we niet alleen moeten kijken naar hoe iets eruitziet, maar ook naar welk HTML-element inhoudelijk het beste past bij de content.

#### Wat neem ik mee uit deze les?

Door mijn voorbereiding had ik al kennisgemaakt met HTML-structuur, semantiek, CSS-selectors en de cascade. Tijdens de les zijn vooral mijn vragen hierover duidelijker geworden.
Ik weet nu dat ik binnen dit project niet zomaar classes kan gebruiken en daardoor bewuster moet nadenken over mijn HTML-structuur en de manier waarop ik elementen selecteer. Ook weet ik dat CSS-regels verschillende prioriteiten kunnen hebben en dat ik voor nu vooral moet onthouden dat de specifiekste regel voorrang krijgt.
Daarnaast heb ik met HTML5 Doctor een nieuwe bron gekregen die ik tijdens het maken van mijn website kan gebruiken wanneer ik niet weet welk HTML-element ik het beste kan gebruiken.

Vanwege een priva afspraak heb ik helaas niet de tweede deepdive kunnen maken

## Check-out woensdag 2 sept: vanwege de Deep-dives hadden we geen chech-out vandaag.

## Voorbereidingen 2 september

### Voorbereiding basis HTML, CSS, fonts en kleur

Voor de voorbereiding van de les heb ik informatie gelezen over webfonts, HTML en CSS. Hierdoor begrijp ik beter hoe een website wordt opgebouwd en welke keuzes ik moet maken bij het gebruiken van lettertypen.

### Web-safe fonts en @font-face

Ik heb geleerd dat een lettertype beschikbaar moet zijn op het apparaat van de bezoeker of door de website geladen moet worden. Er zijn hiervoor drie mogelijkheden:
Web-safe fonts: deze lettertypen staan standaard op de meeste apparaten. Ze laden snel en gebruiken geen extra data. Voorbeelden hiervan zijn Arial, Verdana, Georgia en Times New Roman.
Webfontservices: dit zijn diensten zoals Google Fonts en Adobe Fonts. Tijdens deze opdracht mogen wij deze niet gebruiken. Ze kunnen namelijk zorgen voor minder privacy, extra laadtijd en afhankelijkheid van een externe dienst.

@font-face: hiermee kan ik een lettertype zelf downloaden, in mijn projectmap zetten en vanuit mijn CSS-bestand laden.
Met font-family bepaal ik welk lettertype een element krijgt. Als ik een lettertype aan de body geef, wordt dit meestal automatisch overgenomen door de elementen die hierin staan. Dit heet inheritance.
Ik kan ook verschillende lettertypen achter elkaar plaatsen. Dit heet een font-stack. Als het eerste lettertype niet geladen kan worden, probeert de browser automatisch het volgende lettertype.
body {
font-family: Georgia, Times, serif;
}
Met system-ui gebruikt de website het standaardlettertype van het besturingssysteem. Hierdoor kan het lettertype er op een Windows-computer bijvoorbeeld iets anders uitzien dan op een MacBook.
Wanneer ik een zelf gedownload lettertype wil gebruiken, maak ik eerst een map voor de fontbestanden. Daarna koppel ik het lettertype bovenaan mijn CSS-bestand met @font-face.
@font-face {
font-family: "Dyna Puff";
src: url("../fonts/DynaPuff-Bold.ttf");
}

body {
font-family: "Dyna Puff", sans-serif;
}

Een fontfamilie kan uit verschillende bestanden bestaan, zoals regular, italic, bold en bold italic. Met font-weight en font-style geef ik aan welke variant bij ieder bestand hoort. De browser kan daarna automatisch de juiste variant gebruiken.
Ik heb ook geleerd dat het niet slim is om heel veel lettertypen en varianten aan mijn website toe te voegen. Hierdoor moet de bezoeker meer bestanden downloaden en kan de website langzamer worden. Daarnaast moet ik controleren of de licentie van een lettertype het gebruik op een website toestaat.

<img src="./assets/images-readme/aantekening3sepetmber2.png" alt="aantekeningen deep dive (web safe fonts)" />
Foto: aantekeningen deep dive (web safe font).

### HTML & CSS Is Hard

Voor de voorbereiding heb ik de onderdelen Introduction, Basic Web Pages en Hello, CSS van HTML & CSS Is Hard gelezen.
In Introduction heb ik geleerd dat HTML, CSS en JavaScript ieder een eigen functie hebben. HTML bepaalt de inhoud en structuur van een website. CSS wordt gebruikt voor de vormgeving en JavaScript maakt interacties mogelijk.

In Basic Web Pages heb ik geleerd hoe een HTML-pagina wordt opgebouwd met html, head en body. Ook kwamen headings, paragrafen en lijsten aan bod. HTML bepaalt dus niet alleen wat er op een pagina staat, maar geeft ook betekenis en structuur aan de inhoud.
In Hello, CSS heb ik geleerd hoe ik een CSS-bestand aan HTML kan koppelen. Een CSS-regel bestaat uit een selector, een property en een value. Daarnaast heb ik gelezen over kleuren, lettertypen, meeteenheden, inheritance en de cascade.
Door deze artikelen begrijp ik beter dat HTML en CSS twee verschillende taken hebben, maar wel met elkaar samenwerken. HTML bepaalt wat een onderdeel is en CSS bepaalt hoe dit onderdeel eruitziet.

Na het lezen had ik nog twee vragen:
Wanneer kan ik beter een HTML-element, zoals p of h1, als selector gebruiken en wanneer is een class handiger?
Hoe bepaalt CSS welke regel voorrang krijgt als meerdere regels hetzelfde element aanpassen?

### MDN – Structuring content with HTML

Ik heb ongeveer een half uur scannend gelezen op MDN. Ik heb vooral gekeken naar semantische elementen, zoals header, nav, main, section, article en footer. Deze elementen geven betekenis aan de verschillende onderdelen van een pagina. Dit is duidelijker dan wanneer een hele website alleen met div-elementen wordt opgebouwd.
Ook heb ik gekeken naar links, afbeeldingen, formulieren en tabellen. Bij deze onderwerpen kwam toegankelijkheid vaak terug. Goede HTML helpt niet alleen de browser, maar ook zoekmachines en screenreaders om een website beter te begrijpen.

Ik vond het opvallend dat niet iedere afbeelding een uitgebreide alt-tekst nodig heeft. Als een afbeelding alleen ter decoratie wordt gebruikt, kan deze alt="" krijgen. Een screenreader weet dan dat de afbeelding kan worden overgeslagen.
Ook heb ik geleerd dat ‘klik hier’ geen goede linktekst is. Zonder extra context is namelijk niet duidelijk waar de link naartoe gaat. Een tekst zoals ‘Bekijk mijn contactgegevens’ vertelt veel duidelijker wat iemand na het aanklikken kan verwachten.

### Wat ik hiervan heb geleerd

Ik heb vooral geleerd dat HTML niet alleen bepaalt wat er op het scherm staat. Door semantische elementen, duidelijke linkteksten en passende alt-teksten te gebruiken, kan ik mijn website begrijpelijker en toegankelijker maken.
Daarnaast begrijp ik nu beter hoe lettertypen op het web werken. Voor deze opdracht kan ik een web-safe font gebruiken of een zelf opgeslagen lettertype met @font-face aan mijn website koppelen. Daarbij moet ik niet alleen kijken naar wat ik mooi vind, maar ook letten op leesbaarheid, fallbacks, bestandsgrootte, privacy en de licentie van het lettertype.
Voor mijn eigen website wil ik daarom bewust omgaan met de hoeveelheid fonts en varianten die ik toevoeg. Ik wil een stijl kiezen die bij mijn onderwerp past, maar mijn website moet ook duidelijk leesbaar zijn en snel blijven laden.

<img src="./assets/images-readme/aantekeningen3september.png" alt="aantekeningen van HTML en CSS basis" />
 Foto: aantekeningen van HTML en CSS basi

## kick-off maandag 31 augustus:

31 augustus: Check out

1. Wat is een source hosting platform en welke heb ik gekozen?
   Een source hosting platform is een online plek waar je de bestanden en code van een project kunt opslaan en beheren. Het handige hiervan is dat verschillende versies van je code worden bijgehouden. Hierdoor kun je later terugzien welke aanpassingen je hebt gemaakt en wanneer je deze hebt gemaakt.

Voor mijn website gebruik ik GitHub als source hosting platform. De code van mijn website staat hierdoor online in een repository. De bestanden pas ik aan in Visual Studio Code en daarna stuur ik de nieuwste versie naar GitHub. Met GitHub Pages kan ik mijn website vervolgens online publiceren.

Mijn repository op GitHub, waarin de bestanden en verschillende versies van mijn website worden opgeslagen.
<img src="./assets/images-readme/gitthubstart.png" alt="Je domein koppelen aan je Github" />
Foto:Je domein koppelen aan je Github
Deze foto is wel later toegevoeegd omdat ik niet wist dat dat moest.

2. Welke domeinnaam heb ik gekozen en hoe heb ik deze gekoppeld?
   Ik heb gekozen voor de domeinnaam madebyjudith.nl. Ik heb bewust voor deze naam gekozen omdat ik de website uiteindelijk als mijn persoonlijke portfolio wil blijven gebruiken. Ik kan hier mijn projecten uit het eerste jaar op zetten, maar later ook nieuw werk toevoegen. Zo kan mijn portfolio met mij meegroeien en kan ik de website later gebruiken bij het zoeken naar een stage of werk.

   Om mijn domeinnaam aan mijn website te koppelen, heb ik binnen GitHub Pages mijn eigen domein ingevuld. Daarna heb ik bij mijn domein de benodigde DNS-instellingen aangepast. De uitleg en gegevens die ik hiervoor nodig had, kon ik op DLO vinden.
   Nadat ik deze instellingen had toegevoegd, controleerde GitHub de verbinding. Ik kreeg daarna de melding ‘DNS check successful’. Dit betekende dat mijn GitHub-pagina goed was gekoppeld aan madebyjudith.nl.

Foto: Hier kozen we onze eigen domein naam

<img src="./assets/images-readme/Domeinnaamkiezen.png" alt="Hier kozen we onze eigen domein naam" />

3. Hoe pas ik mijn website aan en publiceer ik deze online?
   Ik pas mijn website aan in Visual Studio Code. Hier kan ik bijvoorbeeld veranderingen maken in mijn HTML- en CSS-bestanden. Tijdens het werken gebruik ik Go Live om mijn website lokaal in de browser te bekijken. Zo kan ik eerst controleren hoe mijn aanpassingen eruitzien, voordat ik ze online publiceer.
   Wanneer ik tevreden ben, sla ik mijn bestanden op. Daarna open ik in Visual Studio Code het onderdeel Source Control. Hier zet ik de aangepaste bestanden klaar en maak ik een commit. Bij deze commit schrijf ik een korte beschrijving van wat ik heb veranderd. Vervolgens push of synchroniseer ik de commit naar GitHub.
   GitHub ontvangt dan de nieuwste versie van mijn bestanden. Via GitHub Pages wordt deze versie automatisch gepubliceerd. Na een korte tijd zijn mijn veranderingen ook zichtbaar op madebyjudith.nl.
   Mijn werkwijze is:
   Aanpassen → testen met Go Live → opslaan → committen → pushen naar GitHub → online publiceren via GitHub Pages

Foto: Dit is het begin wat we gekregen hadden om onze website te maken.

<img src="./assets/images-readme/Blancoversiewebsite.png" alt="Dit is het begin wat we gekregen hadden om onze website te maken." />

# Model

## Learning Log

# Sprint 2:

## i.v.m. een slecht geplande verassings stedentrip ben ik afwezig van 1 tot 5 oktober.

## Voorbereiding voor woensdg 30 september

### Mijn website testen zonder muis

Na de Deep Dive over buttons en states wilde ik controleren of mijn website ook zonder muis te gebruiken is. Daarom heb ik in mijn CSS een :focus-visible-regel toegevoegd aan mijn links. Deze regel geeft een duidelijke rand aan de link die op dat moment met het toetsenbord is geselecteerd. Zo kan een bezoeker zien waar die zich op de pagina bevindt.

Daarna heb ik mijn website getest door mijn muis weg te leggen en met het toetsenbord door de pagina te gaan. In Chrome kon ik met Tab langs de links navigeren en met Enter een pagina openen. Ook heb ik gecontroleerd of ik met Shift + Tab weer terug kon gaan.

In Safari dacht ik eerst dat het niet werkte, omdat ik met alleen Tab niet langs de links ging. Toen ontdekte ik dat ik daar Option + Tab moest gebruiken. Daarna kon ik ook in Safari de links selecteren en de focusrand zien. Bij mijn keuze tussen licht en donker ontdekte ik nog iets nieuws: omdat dit radioknoppen in één groep zijn, wissel je daartussen met de pijltjestoetsen. Met Tab ga je daarna verder naar het volgende onderdeel.

Door dit te testen heb ik geleerd dat het toevoegen van een focusstijl pas de eerste stap is. Ik moet ook zelf controleren of alle onderdelen bereikbaar zijn, of ik steeds kan zien waar de focus staat en of de bediening in verschillende browsers werkt.

<img src="./assets/images-readme/zondermuistest.png" alt="" />
Foto: van mijn test dat het bruikbaar is zonder muis.

### Mijn knoppen en links verbeteren

Ik had het gevoel dat mijn code voor de knoppen op mijn website niet helemaal goed was. Daarom ben ik eerst begonnen met de Deep Dive Buttons, states en selectors. Ik hoopte daarin een antwoord te vinden op mijn vraag. De Deep Dive ging vooral over de verschillende toestanden van interactieve elementen, maar hielp mij ook om beter na te denken over het verschil tussen een button en een link.

Bij het bekijken van mijn eigen code zag ik dat ik voor de teruglink een 'button' binnen een 'a' had gezet. Dat voelde voor mij al niet logisch: de link zorgt er namelijk voor dat je naar een andere pagina gaat, terwijl een button bedoeld is om een handeling uit te voeren. Ik heb de button daarom uit de HTML gehaald en alleen de link laten staan.

Toen ik dat voor het eerst deed, zag de teruglink er ineens anders uit. Op de eerste screenshot is te zien hoe de oude code een klein wit knopje binnen een grotere bruine vorm liet zien. Nadat ik de 'button' weghaalde, moest ik ook mijn CSS aanpassen. De vormgeving stond namelijk nog bij button en werd daardoor niet meer op de link toegepast. Ik heb de selector veranderd naar a, waarna de link er weer uitzag zoals ik wilde en nog steeds werkte.

Daarna heb ik ook mijn andere navigatielinks bekeken om te controleren of ik daar het juiste HTML-element gebruikte. Hierdoor begrijp ik nu beter dat ik eerst moet bepalen wat een element doet en daarna pas met CSS bepaal hoe het eruitziet.

<img src="./assets/images-readme/oudecode-29-9.png" alt="" />
Foto: mijn oude HTML code.
---

<img src="./assets/images-readme/knopnabuttonweg.png" alt="" />
Foto: het uiterlijk vóór de aanpassing in de css

### Deep Dive: Buttons, states en selectors

Tijdens deze Deep Dive heb ik geleerd dat je met CSS ook de interactie van een website vormgeeft. Een link of knop kan er anders uitzien wanneer iemand er met de muis overheen gaat, er met het toetsenbord naartoe navigeert of hem indrukt. Zo krijgt de bezoeker feedback op wat die doet.

Ik leerde eerst het verschil tussen een link en een button. Een link brengt je naar een andere pagina of bron, terwijl een button een handeling uitvoert. Mijn navigatie met Home, Flappie, Vonkje en Simba bestaat uit links, omdat je daarmee naar andere pagina’s gaat. Ik heb de vier states uit de Deep Dive daarom op deze navigatielinks uitgeprobeerd.

De normale vormgeving heet de default state. Met :hover verander ik de vormgeving als de muis boven een link staat. Met :focus-visible laat ik duidelijk zien welke link iemand met de Tab-toets heeft geselecteerd. Dat vind ik belangrijk, omdat de navigatie ook zonder muis te gebruiken moet zijn. Met :active geef ik feedback op het moment dat iemand een link indrukt.

Ik heb de verschillende states getest met mijn muis en toetsenbord. Vooral het effect van :active vind ik leuk: de link wordt tijdens het indrukken heel even kleiner, alsof je hem echt indrukt. Dit effect wil ik ook toepassen in mijn eigen website, omdat het de interactie duidelijker en leuker maakt.

In het tweede deel van de Deep Dive heb ik geleerd hoe 'details' en 'summary' werken. Daarmee kun je informatie laten uitklappen zonder JavaScript. Ook een summary kan een normale, focus-, hover- en active-toestand krijgen. Met details:open kun je daarnaast de vormgeving veranderen zodra de informatie is uitgeklapt. Dit kan ik later gebruiken om extra uitleg overzichtelijk aan te bieden, zonder meteen een lange lap tekst te tonen.
Dit wil ik toepassen in mijn cookie over privacy.

<img src="./assets/images-readme/4states.png" alt="" />
Foto: mijn code met de 4 states.

### Laatste feedback en mijn keuze

Ik heb de drie nieuwe varianten opnieuw aan mensen in mijn omgeving laten zien. Ik vroeg welke zij het beste vonden en waarom. Zo kon ik zien of de combinatie van het koekje, het hapje en het informatiebericht duidelijker was geworden.

Lars koos variant 2, omdat de andere twee hem minder aanspraken. De vijf anderen kozen allemaal variant 3, de zachte tekstvorm. Desirée vond dat het koekje en het bericht daarin één geheel vormen. René vond het de mooiste combinatie en zei dat het bericht er vloeiend uitkomt. Annet vond deze variant het leukst en duidelijk. Irene zei dat het echt lijkt alsof het bericht uit het koekje komt. Laura vond vooral sterk dat alles als één geheel oogt.

Die reacties sluiten aan bij wat ik met het ontwerp wilde bereiken. Ik wilde dat het informatiebericht niet als een los kaartje naast het koekje staat, maar er zichtbaar uit voortkomt. Daarom kies ik variant 3 om verder uit te werken. De vorm loopt door van het gehaakte koekje naar het bericht, terwijl het losse hapje boven op het bericht terugkomt.

Deze feedback helpt mij bij mijn keuze voor de vormgeving. Bij de verdere uitwerking wil ik ook controleren of bezoekers zonder uitleg begrijpen dat ze op het koekje kunnen klikken om privacyinformatie te openen. De foto van mijn feedbackaantekeningen voeg ik hieronder toe.

<img src="./assets/images-readme/feedback-cookie3.jpg" alt="" />
Foto: de feedback die ik heb gekregen over de 3 laatste variaties.

## Na de les van maandag 28 september

### Van feedback naar nieuwe ontwerpvarianten

Op maandag heb ik de feedback op mijn ideeën voor de privacyinformatie verwerkt. Ik heb de suggesties van Lars en Isabeau gecombineerd: een gehaakt koekje dat na een klik een hapje mist, met een informatiekaartje dat via draadjes aan het koekje vastzit. Het losse hapje komt in sommige varianten terug op het kaartje.

Ik heb dit idee eerst in zes globale varianten verkend. Daarna heb ik dezelfde varianten uitgebreider uitwerken, zodat ik beter kon vergelijken waar het kaartje verschijnt en hoe de verbinding met het koekje werkt. Tot slot heb ik ze in kleur gevisualiseren via canva pro.

Ik wil de zes varianten nu aan mensen in mijn omgeving laten zien. Ik vraag welke zij het duidelijkst en het leukst vinden, of ze begrijpen dat het koekje een knop is en of het kaartje logisch uit het koekje lijkt te komen. De reacties en mijn uiteindelijke keuze beschrijf ik in een volgend onderdeel.

<img src="./assets/images-readme/schetsencookie2.png" alt="" />
Foto: de schetsen van mijn variaties van de cookies na de feedback

### Feedback verwerken en drie nieuwe varianten maken

Ik heb de zes varianten van het gehaakte koekje opnieuw aan mensen in mijn omgeving laten zien. Ik wilde weten welk ontwerp zij het duidelijkst en het mooist vonden. De reacties liepen uiteen. Het hangende koekje sprak sommige mensen aan, maar zelf vind ik dat minder goed passen bij de vormgeving van mijn website. Bij de andere varianten werd vooral positief gereageerd op de manier waarop het kaartje en het koekje samen één geheel vormen. Ook het idee van een tekstballon viel op, omdat het bericht daardoor op een speelse manier uit het koekje lijkt te komen.

Met die feedback ben ik verdergegaan met variant 2, 4 en 6. Ik heb de sterke punten daarvan gecombineerd in drie nieuwe ontwerpen. In alle drie verschijnt het informatiekaartje direct naast het koekje, zonder dat het los hangt. Wanneer iemand op het koekje klikt, verdwijnt er een hapje. Dat stukje komt terug boven op het bericht. Zo is te zien dat het bericht bij het koekje hoort.

De drie ontwerpen laten elk een andere beweging zien. Bij de eerste variant vouwt het kaartje uit het koekje. Bij de tweede lijkt het kaartje door de opening naar buiten te schuiven. Bij de derde loopt de vorm van het koekje door in een zachte tekstvorm. Door deze verschillen naast elkaar te zetten, kan ik beter beoordelen welke interactie het duidelijkst is en het beste bij mijn website past.

Ik wil deze drie varianten nog één keer laten testen in mijn omgeving. Daarbij vraag ik of mensen begrijpen dat ze op het koekje kunnen klikken, of het bericht echt uit het koekje lijkt te komen en welke variant zij het prettigst vinden. Met die laatste feedback kan ik een onderbouwde keuze maken voor het ontwerp dat ik op mijn website ga uitwerken. De uitkomst van die test beschrijf ik in een volgend onderdeel.

Voor de nieuwe varianten heb ik weer eerst een schets gemaakt en daarna weer met canva kleur gegeven. Aangezien ik al de juiste vormgeving hasd voor het koekje ging dit een stuk makkelijker en sneller.

<img src="./assets/images-readme/cookievariatie2.png" alt="" />
Foto: De nieuwe varianten na de feedback.

## Maandag 28 september

### Bi-weekly Geek 2 – Het web en de wet

Vandaag begonnen we met de Bi-weekly Geek. Ik werkte samen met Massimo, Eva, Isabeau en Joy aan de vragen: 'Kan een machine onderscheid maken tussen informatie, prpagagana en desinformatie?' en ‘Kun je vrijheid van informatie hebben zonder bescherming tegen desinformatie?’ De opdracht was verdeeld over twee teams. Het andere team bedacht eerst deelvragen die nodig zijn om de hoofdvraag te kunnen beantwoorden. Daarna bekeek een ander team welke onderzoeksmethoden bij die deelvragen passen.

We kwamen op verschillende manieren om informatie te verzamelen, zoals literatuuronderzoek, interviews met experts, een focusgroep en een enquête. Ook dachten we aan het vergelijken van bestaande regels en voorbeelden. Ik merkte hierdoor dat je niet meteen een antwoord op een grote vraag hoeft te geven. Door de vraag eerst op te delen, kun je gerichter onderzoeken wat begrippen als vrijheid van informatie en desinformatie betekenen en welke gevolgen bescherming daartegen kan hebben.

Hieronder voeg ik de foto’s van onze ingevulde opdrachtbladen toe.

<img src="./assets/images-readme/weeklygeek2.png" alt="" />
Foto: De ingevulde opdracht bladen van de weekly geek 2.

### Toegankelijkheid testen met het toetsenbord en VoiceOver

#### Waarom hebben we dit gedaan?

Vandaag hebben we onderzocht hoe je een website gebruikt zonder muis of trackpad. Een website moet ook te bedienen zijn voor mensen die bijvoorbeeld minder goed zien of moeite hebben met fijne motoriek. Daarom hebben we geoefend met twee manieren van navigeren: alleen met het toetsenbord en met VoiceOver, de screenreader op een Mac.

Het doel van de opdracht was om op NS.nl een reis naar Maastricht te plannen. Daarbij moesten we vertrekken vanaf onze huidige locatie, de reis voor morgen instellen, om 12.00 uur vertrekken en een overstaptijd van minimaal tien minuten kiezen. We deden de opdracht twee keer: één keer met alleen het toetsenbord en één keer met VoiceOver.

#### Het POUR-principe

Tijdens de les hebben we het gehad over het POUR-principe. De vier letters beschrijven wat een toegankelijke website nodig heeft:

- Waarneembaar: bezoekers moeten de informatie kunnen zien, horen of op een andere manier meekrijgen. Een screenreader moet bijvoorbeeld kunnen vertellen wat een belangrijke afbeelding betekent.

- Bedienbaar: bezoekers moeten alle functies kunnen gebruiken, ook zonder muis. Je moet bijvoorbeeld met het toetsenbord bij knoppen en invulvelden kunnen komen.

- Begrijpelijk: de tekst en de bediening moeten duidelijk zijn. Bij een formulier moet je begrijpen wat je moet invullen en wat er gebeurt als je op een knop drukt.

- Robuust: de website moet goed werken met verschillende browsers en hulpmiddelen, zoals een screenreader.

Ik begrijp nu beter dat toegankelijkheid uit meerdere onderdelen bestaat. Een knop kan er duidelijk uitzien, maar alsnog lastig te gebruiken zijn als je er niet met het toetsenbord bij kunt komen of als VoiceOver niet vertelt wat de knop doet.

#### De niveaus A, AA en AAA

We hebben ook de WCAG-niveaus besproken. Dit zijn niveaus waarmee je kunt beoordelen aan welke toegankelijkheidseisen een website voldoet:

- A is het eerste niveau met belangrijke basiseisen.

- AA bevat de eisen van A en aanvullende eisen. Dit is het niveau waaraan onze website voor de opdracht moet voldoen.

- AAA bevat ook de eisen van A en AA, met nog strengere eisen. Waar het bij mijn website mogelijk is, wil ik ook aan zulke extra eisen denken.

Een voorbeeld is het contrast tussen tekst en achtergrond. Als kleuren te weinig van elkaar verschillen, wordt tekst moeilijker leesbaar. Ook een zichtbare focus is belangrijk: wanneer iemand op Tab drukt, moet duidelijk zijn welk onderdeel op dat moment geselecteerd is.

#### Test 1: NS.nl met alleen het toetsenbord

Voor de eerste test gebruikten we (deed deze opdracht met Jesse) geen muis of trackpad. Ik navigeerde met Tab langs de onderdelen van de pagina en met Shift + Tab terug. Met Enter of Spatie kon ik een onderdeel activeren. Zo probeerde ik de reis stap voor stap in te vullen.

Tijdens het testen lette ik niet alleen op de vraag of ik de reis kon plannen. Ik keek ook of ik kon zien waar ik op de pagina was en of ik zonder muis verder kon wanneer er bijvoorbeeld een keuzelijst verscheen. Hierdoor merkte ik hoe belangrijk de zichtbare focus en een duidelijke volgorde van invulvelden zijn.

Het lukte niet in 1 keer omdat ik op safari zat en daar deed niet alles het goed. ik ben daarna over gegaan op Chrome en daar deed alles het wel.

<img src="./assets/images-readme/alleentoetenbord.png" alt="" />
Foto: Ik testte of ik op NS.nl een reis kon plannen zonder mijn muis of trackpad te gebruiken.
Bron: [NS.nl](https://www.ns.nl)

---

<img src="./assets/images-readme/spiekbriefje-toetsenbord.png" alt="" />
Foto: Spiekbriefje 1: alleen het toetsenbord

#### Test 2: NS.nl met VoiceOver

Daarna voerde we de opdracht opnieuw uit met VoiceOver. VoiceOver leest onderdelen van de website voor en vertelt bijvoorbeeld of iets een kop, link, knop of invulveld is. Daardoor kon ik op een andere manier door dezelfde reisplanner navigeren.

Bij deze test lette ik op de informatie die werd voorgelezen. Begrijp je wat een invulveld vraagt? Is de naam van een knop duidelijk? En kun je horen waar je in het proces bent? De test maakte voor mij duidelijk dat een visueel ontwerp niet genoeg informatie geeft over hoe een website werkt voor iemand die een screenreader gebruikt.

<img src="./assets/images-readme/voiceover.png" alt="" />
Foto: Ik gebruikte VoiceOver om de reisplanner van NS.nl met een screenreader te testen.
Bron: [NS.nl](https://www.ns.nl)

<img src="./assets/images-readme/spiekbriefje-voice.png" alt="" />
Foto: Spiekbriefje 2: VoiceOver op de Mac

#### Wat neem ik mee voor mijn eigen website?

Door deze opdracht kijk ik anders naar mijn eigen website. Bij het maken en aanpassen van de site wil ik controleren of ik alle links, knoppen en menu’s met alleen het toetsenbord kan gebruiken. Ik wil ook testen of de focus goed zichtbaar is en of de volgorde waarin ik door de pagina ga logisch is.

Met VoiceOver wil ik nagaan of de koppen een duidelijke structuur vormen, of links en knoppen begrijpelijke namen hebben en of belangrijke afbeeldingen goed worden beschreven. Ik kan de spiekbriefjes bij mijn voortgangsgesprek gebruiken om te laten zien hoe ik dit test. De foto’s hierboven laten zien dat ik beide manieren van bedienen tijdens de les zelf heb uitgeprobeerd.

## Check-out maandag 28 september

Na het testen van NS.nl besprak ik samen met Lars drie vragen over semantiek, beperkingen en screenreaders. We gebruikten daarbij wat we tijdens de opdracht met het toetsenbord en VoiceOver hadden geleerd.

1. Wat bedoelt Vasilis met de uitspraak: “Semantiek doet mij niet zo veel, ik ben liever bezig met de UX van HTML”?

Volgens ons bedoelt hij dat hij minder bezig is met wat een HTML-woord letterlijk betekent en vooral kijkt naar wat je met het element kunt doen. Hij vindt het belangrijk hoe iemand de website in de praktijk ervaart en bedient.

Door de opdracht begrijp ik wel dat die twee dingen met elkaar te maken hebben. Als je bijvoorbeeld een echte HTML-knop gebruikt, kunnen bezoekers die meestal met het toetsenbord bedienen en herkent een screenreader dat het een knop is. De keuze van een HTML-element heeft dus invloed op de gebruikservaring.

2. Wat voor type beperkingen hebben invloed op het gebruiken van websites?

We bespraken vier soorten beperkingen:

- Visuele beperkingen: iemand ziet de website minder goed of niet en kan bijvoorbeeld een screenreader gebruiken.

- Auditieve beperkingen: iemand hoort geluid of gesproken informatie minder goed of niet.

- Motorische beperkingen: iemand kan moeite hebben met een muis of kleine klikvlakken en gebruikt bijvoorbeeld het toetsenbord.

- Cognitieve beperkingen: iemand kan moeite hebben met ingewikkelde teksten, veel informatie tegelijk of een onduidelijke indeling.

Daarom is het belangrijk om een website op verschillende manieren te testen. Als iets voor mij met een muis werkt, betekent dat nog niet dat iedereen het kan gebruiken.

3. Noem drie manieren om door een website te navigeren met jouw screenreader.

Op mijn Mac gebruik ik VoiceOver. Daarmee kan ik op verschillende manieren door een website gaan:

1. Onderdeel voor onderdeel: met Control + Option + <- of Control + Option + -> ga ik naar het vorige of volgende onderdeel.

2. Via de koppen: met de VoiceOver-rotor kan ik een lijst met koppen openen en naar een bepaald gedeelte van de pagina springen.

3. Via links of formuliervelden: in dezelfde rotor kan ik ook een lijst met links of formuliervelden kiezen. Dat is handig als ik snel iets wil vinden of een formulier wil invullen.

Door dit samen met Lars te bespreken, kon ik beter uitleggen waarom de opbouw van HTML belangrijk is. Duidelijke koppen, links, knoppen en invulvelden helpen bezoekers om hun weg te vinden, vooral wanneer ze een screenreader gebruiken.

## voorbereiding maandag 28 september

### Verantwoordelijkheid van digitale platforms en AI

Ik heb drie artikelen gelezen en een video bekeken over de verantwoordelijkheid van digitale platforms. In het NOS-artikel las ik over een rechtszaak tegen Meta. Amerikaanse staten stellen dat functies zoals automatisch afspelende video’s, stories en likes jongeren lang op Instagram en Facebook houden. Meta spreekt die beschuldigingen tegen. Het artikel liet mij nadenken over de invloed die kleine ontwerpkeuzes kunnen hebben op het gedrag van gebruikers.

Het artikel van Euronews ging over een onderzoek naar AI-chatbots die soms Russische propaganda als bron gebruikten. Ik leerde hiervan dat een antwoord betrouwbaar kan lijken, zelfs wanneer er een bron bij staat. Het blijft belangrijk om te controleren waar informatie vandaan komt en of die bron geloofwaardig is.

In het artikel van de Financial Times las ik dat ChatGPT volgens de Europese Commissie onder strengere regels van de Digital Services Act (DSA) gaat vallen. Grote online diensten krijgen extra verplichtingen, bijvoorbeeld rond illegale inhoud en de bescherming van minderjarigen. De video van de Europese Commissie hielp mij om de DSA beter te begrijpen. Daarin werd uitgelegd dat platforms duidelijker moeten zijn over hun aanbevelingen, jongeren beter moeten beschermen en meer verantwoordelijkheid moeten nemen voor verkopers op hun platform. Ook dark patterns kwamen aan bod: ontwerpen die mensen ongemerkt naar een bepaalde keuze sturen.

Deze bronnen waren nuttig voor mijn eigen ontwerpwerk. Ze lieten mij zien dat ik niet alleen moet nadenken over hoe een website eruitziet en werkt, maar ook over de gevolgen voor de bezoeker. Ik wil duidelijke informatie geven, bezoekers zelf keuzes laten maken en kritisch blijven op de bronnen die ik gebruik. Onder deze tekst voeg ik foto’s van mijn handgeschreven aantekeningen toe als bewijs van wat ik heb gelezen en bekeken. Omdat die foto’s niet overal goed leesbaar zijn, heb ik de belangrijkste inzichten en wat ik eraan had hierboven ook in tekst beschreven.

<img src="./assets/images-readme/aantekeningen28-9.png" alt="" />
Foto: Mijn aantekeningen van de artikelen en de video

### Feedback over mijn ideeen voor de privacyinformatie.

Na mijn eerdere voorbereiding heb ik de zes ideeën voor de vormgeving van mijn privacyinformatie aan mensen in mijn omgeving laten zien. Ik vroeg welk idee hen het meest aansprak en waarom. Ik schreef hun reacties op, zodat ik mijn keuze niet alleen op mijn eigen voorkeur zou baseren.

Bij het bolletje wol met draadje viel op dat het goed aansluit bij de titel en de sfeer van mijn website. Alleen René zei ook dat het juist verwarrend kan zijn als ik daar de zelfde vormgeving voor gebruik. Het gehaakte koekje werd gekozen omdat mensen het meteen met cookies associëren. Het garenlabel vond Annet passend omdat er op mijn website ook haakpatronen staan en op een garenlabel staan ook altijd alle informatie over dat garen. De rest van de varianten vielen niet zo erg in de smaak waardoor ik de keuze heb genomen om met deze varianten niet verder te gaan.

Ik kreeg ook feedback op hoe ik ideeën kon combineren. Lars stelde voor om het bolletje wol en het gehaakte koekje samen te gebruiken: het koekje blijft het herkenbare beeld en de tekst van het bericht wordt met een draadje aan het koekje verbonden. Isabeau bedacht daar een speelse reactie op. Wanneer je op het koekje klikt, lijkt er een hapje uit te verdwijnen. Dat losse stukje komt aan het informatiebericht te zitten.

Die twee reacties wil ik samenbrengen in één ontwerp. Eerst ziet de bezoeker een gehaakt koekje met het woord ‘Privacy’ erbij. Na een klik verschijnt een kort informatiekaartje dat met touwtjes aan het koekje vastzit. Het koekje mist dan een hapje en dat stukje zit aan de bovenkant van het kaartje. Zo horen het koekje en de uitleg zichtbaar bij elkaar. Op het kaartje komen de korte uitleg, ‘Meer informatie’ en ‘Sluiten’. Sluiten betekent alleen dat het kaartje verdwijnt; het koekje blijft staan zodat de informatie later opnieuw te openen is.
En ik ben nog aan het twijfelen of ik een knop erbij voeg met 'begrepen'. Maar hiervoor zal ik later een user test deoen om te kijken welke stijl van de pop-up de voorkeur heeft van gebruikers.

Ik vind deze combinatie leuk omdat de feedback mijn ideeën verder heeft gebracht dan de losse wireframes. Het koekje is herkenbaar, terwijl het draadje en het gehaakte uiterlijk bij mijn website passen. In een volgende schets wil ik kijken of het kaartje en het hapje ook op een klein scherm duidelijk blijven. Daarbij moet meteen zichtbaar zijn dat het om privacyinformatie gaat en niet om een vraag om cookies te accepteren.

Ik ga na de les nieuwe varianten maken op mijn gecombineerde cookie en deze weer testen mt mijn omgeving.

<img src="./assets/images-readme/feedback-cookie-1.png" alt="" />
Foto: de feedback die ik heb gekregen om mijn wireframes.

## Vrijdag 25 september

Door privé omstandigheiden kon ik helaas niet bij de les zijn.

Wel heb ik deze tijd gebruikt om mijn README aan te vullen (want daar liet ik erg bij achter) en verder te gaan met het bedenken hoe ik mijn cookie wil vormgeven.

Ook heb ik gekeken naar de checkout vragen en. heb ik bekeken welke ik kan beantwoorden.

### Ideeën voor de vormgeving van mijn privacyinformatie

Nadat ik had onderzocht welke gegevens er bij een bezoek aan mijn website worden verwerkt, ben ik gaan nadenken over de vormgeving van de privacyinformatie. Mijn eerste schetsen waren gebaseerd op een cookiemelding met knoppen voor ‘Accepteren’ en ‘Afwijzen’. Uit mijn onderzoek bleek dat die knoppen op mijn website geen echte keuze zouden bieden. Daarom wilde ik mijn ideeën aanpassen: de bezoeker moet de informatie gemakkelijk kunnen vinden en lezen, zonder eerst ergens mee te hoeven instemmen.

Ik heb zes mogelijke vormen bedacht die passen bij het haakthema van mijn website. Het eerste idee is een bolletje wol met een draadje. Wat het zelfde is als het bolletje wol die uit de tittel komt, maar het draadje leidt nu naar de privacyuitleg. Bij het tweede idee staat er een gehaakt koekje op de pagina. Als je erop klikt, verschijnt de uitleg naast het koekje. Daarmee kan ik het koekje idee uit mijn eerdere ontwerp behouden, terwijl het geen toestemmingsknop meer is.

Mijn derde idee is een haakpatroonkaartje dat openvouwt wanneer je erop klikt. Dit past bij de haakpatronen op mijn website en maakt het openen van informatie visueel herkenbaar. Bij het vierde idee hangt een koekje aan een draadje aan de rand van de pagina. Na een klik verschijnt de uitleg onder het koekje, alsof het draadje het informatiekaartje tevoorschijn haalt. Het vijfde idee is een garenlabel dat openklapt. Op zo’n label staat normaal informatie over wol; daarom leek het mij een passende plek voor informatie over de website. Tot slot bedacht ik een ontwerp met een rij haaksteken, waarbij een opvallende steek de ingang naar de privacyuitleg is. De steken passen bij elkaar, net zoals de verschillende onderdelen van de website met elkaar samenhangen.

Om de ideeën beter te kunnen vergelijken, heb ik digitaal zwart-witte wireframes gemaakt. In elk wireframe is te zien hoe het onderdeel eruitziet voor en na een klik. Deze schetsen gebruik ik als hulpmiddel om te bepalen welke vorm het duidelijkst werkt. Mijn eigen aantekeningen met de zes schetsen voeg ik hieronder ook toe.
<img src="./assets/images-readme/wireframes-cookie.png" alt="" />
Foto: mijn korte wireframes over de cookie vromgeving.

### Ideeën kiezen en feedback vragen

Na het bekijken van de zes wireframes spraken drie ideeën mij het meest aan: het bolletje wol met draadje, het gehaakte koekje en het koekje aan een draadje. Het bolletje wol vind ik leuk omdat het aansluit op mijn tittel gif, maar nu een andere functie heeft. Het draadje kan de bezoeker op een natuurlijke manier naar de privacyuitleg leiden. Bij het gehaakte koekje vind ik vooral leuk dat ik een herkenbaar onderdeel uit mijn eerdere ontwerp kan behouden en het is een knipoog naar een cookie. Het koekje aan een draadje spreekt mij aan vanwege de manier waarop het informatiekaartje tevoorschijn kan komen.

Ik wilde mijn keuze niet alleen baseren op wat ik zelf mooi vind. Daarom heb ik de ideeën ook aan mensen in mijn omgeving laten zien en gevraagd welke variant zij het beste vinden. Daarbij wilde ik niet alleen weten welk ontwerp ze het leukst vonden, maar ook of ze begrepen dat ze erop konden klikken voor privacyinformatie. Hun reacties kan ik gebruiken om een ontwerp te kiezen en het waar nodig duidelijker te maken.

## Check-out van vrijdag 25 september

Omdat ik tijdens deze les niet aanwezig was, ben ik niet aan iemand gekoppeld en heb ik gekeken of ik het zelf kon opzoeken

1. Wat is HTML-validatie, waarom is het belangrijk en hoe heb je dat vandaag uitgevoerd?

HTML-validatie is het controleren van de HTML-code op fouten en waarschuwingen. Hiermee kun je bijvoorbeeld ontdekken of elementen verkeerd zijn geplaatst, niet goed zijn afgesloten of op een verkeerde manier zijn gebruikt.

Dit is belangrijk omdat correcte HTML ervoor zorgt dat een website goed werkt in verschillende browsers. Ook maakt het de website beter begrijpelijk voor zoekmachines en hulpmiddelen zoals screenreaders.

Ik heb zelfstandig onderzocht hoe HTML-validatie werkt.
Bron: [HTML-validatie](https://frontend.webontwerp.ucll.be/HTML_validatie/)

2. Welke dingen vielen je op?

Ik heb het niet uitgevoerd dus ik ga de vraag wat aanpassen naar: Welke dingen kunnen opvallen wanneer je HTML-validatie uitvoert?

Wanneer je HTML-validatie uitvoert, kan opvallen dat een validator heel precies naar de code kijkt. De validator kan bijvoorbeeld aangeven dat een element niet goed is afgesloten, op de verkeerde plek staat of dat een verplicht onderdeel ontbreekt.

Ook kan een website er in de browser goed uitzien, terwijl er toch fouten of waarschuwingen in de HTML staan. Bij iedere melding laat de validator meestal zien om welke regel en welk onderdeel het gaat. Hierdoor kun je de fouten makkelijker terugvinden en stap voor stap verbeteren.

3. Welke feedback heb je ontvangen tijdens het gesprek met je docenten?

Omdat ik tijdens deze les niet aanwezig was, heb ik geen gesprek met de docenten gehad en daarom ook geen persoonlijke feedback ontvangen. Ik ben niet aan iemand gekoppeld, maar heb de opdracht vooral zelfstandig bekeken en onderzocht. Hierdoor heb ik zelf onderzocht wat HTML-validatie is en wat je zou kunnen opvallen na zo' contole.

## voorbereinding voor vrijdag 25 september

### Dieper onderzoek naar gegevens van bezoekers

Mijn website wordt gehost met GitHub Pages. Hierover had ik al informatie van GitHub opgezocht over wat er gebeurt wanneer iemand een GitHub Pages-website bezoekt. Ik vond de uitleg moeilijk om helemaal zelfstandig te begrijpen, omdat er veel tekst en technische termen in stonden. Hierdoor wilde ik toch wat meer onderzoek doen naar alle data dat wordt opgeslagen.
Hiervoor heb ik ChatGPT gebruikt om die informatie in begrijpelijkere taal uit te leggen en om mij te helpen onderscheid te maken tussen wat GitHub doet en wat ik eventueel zelf aan mijn website toevoeg. Daarna kon ik de uitleg weer naast de informatie van GitHub leggen.

Ik wil nog controleren of mijn eigen website daarnaast iets toevoegt, zoals externe inhoud, scripts of niet-noodzakelijke cookies. Pas wanneer ik weet wat mijn eigen website daadwerkelijk doet, kan ik bepalen of er een toestemmingsvraag nodig is en waarover die dan moet gaan. Ook wil ik duidelijk kunnen uitleggen welke informatie bij GitHub Pages hoort en welke keuzes de bezoeker wel of niet heeft.

#### De prompt die ik heb gebruikt voor Chatgpt:

Mijn website staat op GitHub Pages. Ik wil voor mijn learning log onderzoeken welke gegevens van bezoekers worden verwerkt wanneer zij mijn website openen, en of ik daarvoor een cookiemelding met knoppen voor accepteren en afwijzen nodig heb.

Gebruik eerst de officiële documentatie en privacyverklaring van GitHub. Maak daarna in eenvoudig Nederlands onderscheid tussen:

1. gegevens die GitHub Pages automatisch verwerkt om de website aan te bieden of te beveiligen;

2. cookies of gegevens die pas een rol spelen als ik zelf extra scripts, externe inhoud of diensten aan mijn website toevoeg;

3. wat een bezoeker daadwerkelijk kan accepteren of afwijzen via een knop op mijn eigen website.

Leg moeilijke termen uit, vermeld bij iedere conclusie de exacte bronlink en zeg duidelijk wat je zonder mijn volledige websitecode niet kunt vaststellen. Controleer ook of mijn idee eerlijk is: bij afwijzen wil ik nu een zwart scherm tonen met de tekst dat de website niet beschikbaar is. Leg uit of dat technisch klopt en wat een duidelijker alternatief zou zijn.

Hierna vroeg chat nog wat extra informatie over mijn code voor eventuele externe links. Hier kwam hij de link van Justus tegen dus hier heb ik aan Chat uitgelegd dat die link van mijn docent is en dat mijn docent de informatie niet opslaat.
Bron: [Chatgpt](https://chatgpt.com)

Antwoord van ChatGPT:
<img src="./assets/images-readme/chapgpt-1.png" alt="" />

<img src="./assets/images-readme/chatgpt-2.png" alt="" />
Foto's: Het antwoord wat Chat GPT mij gegeven heeft.

### Effect van mijn diepere onderzoek naar de data

Voor de opdracht over human consent had ik twee schetsen gemaakt rondom het thema haken. In de ene schets lag er een bolletje wol met een haakpatroon van een cookie in de hoek van de website. In de andere schets stond een gehaakt koekje met een spandoek waarop ‘cookies’ stond. Bij beide ideeën kon de bezoeker kiezen tussen accepteren en afwijzen. Als iemand zou afwijzen, wilde ik een zwart scherm laten zien met de boodschap dat de website niet beschikbaar was.

Nadat ik mijn onderzoek met behulp van ChatGPT verder had onderzocht, ben ik anders naar deze schetsen gaan kijken. Ik had eerst vooral nagedacht over hoe ik een originele cookiemelding kon ontwerpen. Door het onderzoek besefte ik dat ik eerst moest weten waar de bezoeker eigenlijk toestemming voor zou geven. Mijn website staat op GitHub Pages. GitHub geeft aan dat bij een bezoek aan een GitHub Pages-website het IP-adres van de bezoeker voor beveiliging wordt vastgelegd. Dat gebeurt al wanneer de pagina wordt opgevraagd. Een knop op mijn website kan die verwerking dus niet aan- of uitzetten.

Ook moest ik beter onderscheid maken tussen de algemene privacyverklaring van GitHub en wat er op mijn eigen website gebeurt. In de algemene verklaring staan verschillende gegevens en cookies genoemd, maar dat betekent niet automatisch dat mijn website al die cookies gebruikt. De Google Fonts die ik gebruik, heb ik zelf gedownload en in mijn assets-map gezet. Voor die lettertypen hoeft de browser dus geen verbinding met Google Fonts te maken. Op mijn homepage staat daarnaast een onderdeel van Digitaal Tuintje waarvoor de browser wel verbinding maakt met een andere website. Daarover wil ik duidelijk zijn tegenover mijn bezoekers. Ookal weet ik dat hier geen data bij wordt opgeslagen.

Op basis van de onderdelen die ik heb onderzocht, heb ik geen optionele cookies of analysetool gevonden waarvoor ik bezoekers op dit moment een keuze tussen accepteren en afwijzen moet geven. Mijn oorspronkelijke knoppen zouden daardoor een keuze suggereren die er niet echt is. Ook het zwarte scherm na ‘Afwijzen’ past niet meer bij wat ik nu weet: de website kan gewoon worden getoond, terwijl GitHub het IP-adres dan al heeft verwerkt. Ik wil bezoekers niet het gevoel geven dat ze ergens mee moeten instemmen om mijn website te kunnen bekijken. Voor uitsluitend strikt noodzakelijke cookies hoeft volgens de [Autoriteit Persoonsgegevens](https://www.autoriteitpersoonsgegevens.nl) geen toestemming te worden gevraagd.

Daarom ga ik mijn twee schetsen niet in hun oorspronkelijke vorm gebruiken. Ik wil het haakthema wel behouden omdat dat goed past bij mijn website, maar de functie veranderen. In plaats van een koekje dat om toestemming vraagt, kan bijvoorbeeld het bolletje wol verwijzen naar een korte privacyuitleg. Bezoekers kunnen die informatie lezen zonder eerst op ‘Accepteren’ of ‘Afwijzen’ te moeten klikken. Zo blijft het ontwerp bij mijn website passen en geef ik tegelijk een eerlijker beeld van wat er met gegevens gebeurt. Als ik later nieuwe externe diensten of optionele cookies toevoeg, moet ik opnieuw onderzoeken of een toestemmingskeuze nodig is.

### Welke informatie ik op mijn website wil laten zien.

Ik wil een korte, begrijpelijke privacyuitleg op mijn website zetten, met de mogelijkheid om meer informatie te lezen. Daarin wil ik vertellen dat mijn website via GitHub Pages wordt gepubliceerd en dat GitHub bij een bezoek het IP-adres vastlegt voor beveiliging. Ik wil er ook bij uitleggen dat mijn eigen knoppen die verwerking niet kunnen uitschakelen.

Daarnaast wil ik benoemen dat de lettertypen lokaal vanaf mijn website worden geladen en dat op de homepage een onderdeel van Digitaal Tuintje staat waarvoor een verbinding met digitaaltuintje.nl wordt gemaakt. ALs we Justus moeten geloven worden hierbij geen gegevens opgeslagen of gebruikt voor andere doeleindes.

Tot slot wil ik duidelijk maken dat ik in de onderzochte onderdelen van mijn website geen optionele cookies of analysetool heb gevonden waarvoor ik nu toestemming vraag. Ik voeg een link toe naar de uitleg van GitHub Pages over gegevensverzameling. Zo kan een bezoeker zelf verder lezen en is de informatie op mijn website concreter dan een algemene melding over ‘cookies’.

Ik heb aan Chatgpt voor de zekerheid gevraagd of ik een externe link kan toevoegen zonder dat daarna meet data verwerkt wordt.

#### De prompt die ik heb gebruikt voor Chatgpt:

als ik een externe link naar GitHub er inzet heb ik dan niet gezeur met eventueel meer data die GitHub verzameld?

Antwoord van ChatGPT:
<img src="./assets/images-readme/chatgpt-3.png" alt="Antwoord van Chatgpt" />
Foto: Antwoord van Chatgpt over extra data met een externe link.

### Eerste opzet van de cookie tekst

#### Korte tekst op de cookie pop-up zelf:

Hoe zit het met mijn gegevens?

Deze website staat op GitHub Pages. Bij een bezoek legt GitHub uw IP-adres vast voor beveiliging. Op deze website vraag ik u niet om toestemming voor optionele cookies.

Met twee knoppen: meer informatie en begrepen.

#### De tekste bij het klikken op meer infomatie:

Privacy op deze website

Wat gebeurt er als u mijn website bezoekt?
Mijn website wordt gepubliceerd via GitHub Pages. GitHub legt het IP-adres van bezoekers vast voor beveiliging, ook als u geen GitHub-account hebt. Een IP-adres is een nummer waarmee uw apparaat verbinding maakt met internet.

Gebruikt deze website andere diensten?
De lettertypen staan als bestanden op mijn eigen website. Uw browser hoeft daarvoor geen verbinding met Google Fonts te maken. Op de homepage staat ook een onderdeel van Digitaal Tuintje Om dat te tonen, maakt uw browser verbinding met digitaaltuintje.nl. Hierbij wordt geen data opgeslagen.

Waarom zie ik geen knop ‘Accepteren’ of ‘Afwijzen’?
In de onderdelen die ik heb onderzocht, gebruik ik geen optionele cookies of analysetool waarvoor ik u nu om toestemming vraag. De verwerking door GitHub Pages kan ik niet met zo’n knop aan- of uitzetten. Daarom geef ik u uitleg in plaats van een keuze die niets zou veranderen.

Wilt u meer weten over de hosting? Lees dan [GitHubs uitleg over gegevensverzameling bij GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages).

## Woensdag 23 september

### Gast spreker

De les begon met een gastspreker over privacy. Ik heb tijdens de presentatie aantekeningen gemaakt. Het onderwerp sloot goed aan op ons onderzoek naar cookies: als bezoeker geef je soms gegevens door zonder dat je precies weet welke gegevens dat zijn of wat ermee gebeurt. Ik vond het interessant om daar bewuster over na te denken, omdat ik zelf ook een website maak.

<img src="./assets/images-readme/aantekeningen-gastspreker-23-9.png" alt="Aantekening over de gastspreker" />
Foto: Aantekeningen van de gast spreker.

### Wire-frames

Na de gastspreker kregen we uitleg over het maken van een wireframe. Een wireframe is een eenvoudige schets van de indeling en werking van een pagina. Je hoeft nog niet alle kleuren, afbeeldingen en details uit te werken. Eerst kijk je welke informatie en knoppen nodig zijn, waar ze komen te staan en wat er gebeurt als iemand erop klikt. Dat vond ik een handige manier om mijn idee uit te proberen voordat ik het in code maak.

Daarna moesten we zelf een dark pattern op een bestaande website zoeken en de werking ervan schetsen. Ik onderzocht een voorbeeld op Eneba waarbij extra kosten pas later in het bestelproces zichtbaar worden. Ik tekende hoe de bezoeker eerst een prijs ziet en daarna bij het doorgaan een hoger totaalbedrag tegenkomt. Door de opeenvolgende schermen te schetsen, kon ik duidelijker laten zien wanneer die kosten verschijnen en waarom een bezoeker ze in het begin gemakkelijk kan missen. Deze wireframe voeg ik hieronder toe.

<img src="./assets/images-readme/wireframe-23-9.png" alt="Uit werking van de wireframe opdracht" />
Foto: Uitwerkingen van de wire frame opdracht

### Welke data wordt er opgeslagen an mijn bezoekers?

Vervolgens moesten we onderzoeken welke informatie we zelf aan bezoekers van onze website moeten uitleggen. Mijn website staat op GitHub Pages. Daarom heb ik de informatie van GitHub bekeken. Ik maakte aantekeningen over gegevens die bij een bezoek aan een website een rol kunnen spelen, zoals een IP-adres, gegevens over de browser en het apparaat, en informatie over welke pagina wordt opgevraagd. Ik wil daarbij precies blijven onderscheiden wat GitHub verwerkt en wat mijn eigen website eventueel zelf zou verzamelen. De foto van mijn onderzoeksaantekeningen voeg ik hieronder toe.

Met die informatie heb ik eerste ideeën geschetst voor hoe ik bezoekers hierover wil informeren en een keuze wil laten maken. Ik heb twee schetsen gemaakt waarin bij 1 schets een gehaakt koekje verandert afhankelijk van de keuze van de bezoeker. Bij accepteren blijft het koekje heel en bij afwijzen verandert de afbeelding in een gebroken koekje die op een zwart scherm staat met daarop de teskt excuus deze website is niet beschikbaar.

Ik wilde daarmee de keuze zichtbaar en passend bij de sfeer van mijn website maken. Tegelijkertijd moet ik in een volgende versie goed opletten dat de tekening de bezoeker niet ongemerkt richting ‘accepteren’ stuurt. Beide keuzes moeten even duidelijk blijven en de tekst moet uitleggen wat ze werkelijk betekenen. Foto’s van deze eerste schetsen voeg ik hieronder toe.

<img src="./assets/images-readme/variatiecookie-1.png" alt="" />
Foto: Variantie 1: een haak patroon van een cookie die goed is gegaan als je hem acceptert en fout gaat als je hem hebt afgewezen die op een zwart scherm staat met daarop de teskt excuus deze website is niet beschikbaar.

<img src="./assets/images-readme/variantie2-cookie.jpg" alt="" />
Foto: variantie 2: een cookie dat lekker gaat haken als hem accepteerd en stuk gaat als je hem hebt afgewezen die op een zwart scherm staat met daarop de teskt excuus deze website is niet beschikbaar.

---

<img src="./assets/images-readme/informatie-github.jpg" alt="Aantekeningen van mijn onderzoek naar github" />
Foto: mijn aantekeningen naar mijn onderzoek naar Github.

### Wat neem ik mee?

Ik neem uit deze les mee dat ik bij een cookiemelding niet meteen met de vormgeving moet beginnen. Eerst moet ik weten welke informatie klopt, wat een bezoeker moet begrijpen en welke keuzes ik daadwerkelijk kan aanbieden. De wireframes hielpen mij om het verschil tussen een idee en de werking ervan te zien. In een volgende stap wil ik mijn schetsen verder uitwerken en controleren of de uitleg en de keuzes eerlijk en begrijpelijk zijn.

## Chech-out woensdag 23 september

1. Wat is een wireflow en wat heb je eraan?

Een wireflow combineert eenvoudige schetsen van schermen met pijlen die laten zien hoe iemand van het ene scherm naar het andere gaat. Je ziet dus zowel wat de bezoeker ziet als wat er na een klik gebeurt. Dat is handig om een interactie uit te denken voordat je gaat coderen. Ik kan er bijvoorbeeld mee laten zien wat er op mijn website verandert wanneer iemand cookies accepteert of afwijst. media.nngroup.com

2. Wat zijn dark UX patterns? Geef drie voorbeelden.

Dark UX patterns zijn ontwerpkeuzes die bezoekers sturen naar iets wat ze misschien niet zelf zouden kiezen. De website kan er voordeel van hebben, terwijl de bezoeker belangrijke informatie mist of onder druk wordt gezet. Drie voorbeelden zijn:

1. Verborgen kosten: je ziet eerst een lage prijs, maar pas later in het bestelproces verschijnen extra kosten. Dit heb ik ook onderzocht in mijn schets van Eneba.
2. Confirmshaming: de tekst bij ‘nee’ geeft je een vervelend gevoel, bijvoorbeeld: “Nee, ik wil geen voordeel.” Daardoor wordt weigeren minder aantrekkelijk.
3. Nagging: een website blijft je onderbreken met hetzelfde verzoek, ook nadat je het hebt weggeklikt.

Ik wil bij mijn eigen ontwerp opletten dat de bezoeker de gevolgen van een keuze begrijpt en zich vrij voelt om die keuze te maken.

3. Waar moet je als ontwerper rekening mee houden bij het maken van een human consent component?

Een human consent component is voor mij een toestemmingsvraag die rekening houdt met de persoon die de keuze moet maken. Ik moet eerst onderzoeken waarvoor ik daadwerkelijk toestemming vraag en daarna in gewone taal uitleggen welke gegevens worden gebruikt, met welk doel en wat de keuzes betekenen. Accepteren en afwijzen moeten allebei duidelijk te vinden zijn. Ook mag ik iemand niet met een opvallende knop, schuldgevoel of een misleidende afbeelding naar één antwoord duwen.
Bij mijn schets verandert een koekje na het accepteren of afwijzen. Dat maakt de reactie zichtbaar, maar ik moet goed opletten dat het koekje bij afwijzen geen straf of schuldgevoel uitbeeldt. Beide keuzes moeten eerlijk blijven en de uitleg moet belangrijker zijn dan het grapje in de afbeelding.

## voorbereiding woensdag 23 september

### Opdracht afmaken

Als voorbereiding op woensdag heb ik de codeeroefening van Justus van maandag thuis afgemaakt. Tijdens de les ging het live coderen voor mij te snel om alles meteen goed te volgen. Thuis kon ik de code op mijn eigen tempo opnieuw bekijken en de onderdelen die nog niet af waren verder uitwerken.

Ik heb ook extra uitleg voor mezelf bij de code gezet. Ik wilde niet alleen een werkende uitwerking hebben, maar later ook kunnen begrijpen waarom iets op die manier is geschreven. Als ik een vergelijkbaar onderdeel in mijn eigen website wil gebruiken, kan ik mijn uitleg erbij pakken en het zelf opnieuw toepassen. Dat hielp mij meer dan de code alleen overnemen.

Omdat het niet echt lukt met mijn inhoud heb ik de inhoud van Justus gekopieerd en geplakt zodta ik echt alles goed kon mee doen.

<img src="./assets/images-readme/opdracht-justus.png" alt="Uitwerkingen opdracht van Justud." />
Foto: Uitwerkingen van de opdracht van Justus

### Onderzoek naar dark patterns

Daarnaast heb ik ter voorbereiding twee video’s bekeken en een artikel van UX Design Institute gelezen over dark patterns. Daarbij ging het over ontwerpkeuzes die bezoekers in een bepaalde richting sturen, bijvoorbeeld bij het delen van gegevens of het maken van een keuze. Ik ben hierdoor bewuster gaan letten op de woorden bij knoppen, de uitleg die een website geeft en hoe makkelijk verschillende keuzes te vinden zijn. Dat sluit ook aan bij de cookiepop-ups die we maandag hebben onderzocht.

Tijdens het lezen en kijken heb ik aantekeningen gemaakt. Foto’s van deze aantekeningen voeg ik hieronder toe. Zo kan ik later terugvinden wat ik uit de bronnen heb gehaald en welke punten ik wil onthouden wanneer ik zelf interactieve onderdelen ontwerp.
<img src="./assets/images-readme/Aantekeningen-huiswerk21-9.png" alt="Aantekeningen van het huiswerk voor woensdag 23-9" />
Foto: Aantekeningen van het huiswerk voor woensdag 23-9

## maandag 21 september

### live coderen

Aan het begin van sprint 2 ging Justus live coderen. We konden meekijken hoe hij een voorbeeld stap voor stap opbouwde, maar het tempo lag voor mij erg hoog. Ik probeerde tegelijk te begrijpen wat hij deed, aantekeningen te maken en zelf mee te werken. Daardoor lukte het mij niet om de hele opdracht tijdens de les af te ronden. Ik heb opgeschreven wat ik kon volgen en ben er later thuis rustig mee verdergegaan.

In de code van deze opdracht werkte ik onder andere met de opbouw van een HTML-pagina en een cookiemelding in een dialog-element. Ik vond het leerzaam om te zien hoe HTML-onderdelen samen een werkend geheel moeten vormen. Thuis kon ik de stappen opnieuw bekijken en in mijn eigen tempo uitproberen. Daardoor had ik meer ruimte om te begrijpen wat de code deed en om de opdracht af te maken. Mijn aantekeningen en de code van deze oefening voeg ik hieronder toe.
<img src="./assets/images-readme/aantekening-justus-livecode.jpg" alt="Aantekeningen van het live coderen van Justus." />
Foto: Aantekingen van het live coderen.

### cookiepop-ups onderzoeken

Daarna kregen we een opdracht over cookie consent. Ik heb deze samen met Massimo en Eva gemaakt. We onderzochten cookiebanners van de Volkskrant en Paradiso. Op het werkblad keken we niet alleen naar de knoppen, maar ook naar de uitleg: wat gebeurt er met je gegevens, wie kunnen die gegevens krijgen en kun je je keuze later nog veranderen? Ook bekeken we of ‘accepteren’ en ‘weigeren’ even duidelijk en makkelijk waren, en welke keuze de websites het liefst lijken te willen.

Tijdens het vergelijken viel ons op dat er verschil zit tussen een keuze aanbieden en iemand helpen een goed geïnformeerde keuze te maken. Een cookiebanner kan meerdere knoppen hebben, terwijl je toch moet zoeken naar wat die keuzes precies betekenen. Bij de Volkskrant zagen we bijvoorbeeld een uitgebreidere uitleg, maar ook veel informatie over partijen die gegevens kunnen ontvangen. Bij Paradiso keken we onder meer naar de verschillende keuzeopties en hoe duidelijk de gevolgen daarvan werden uitgelegd. De foto van ons ingevulde werkblad voeg ik hieronder toe en ook de bronnen van de websites.

<img src="./assets/images-readme/groepsopdracht 21-9.jpg" alt="Uitwerking van de opdracht over cookie onderzoek.." />
Foto: groeps opdracht over het onderzoek naar cookies.

Bronnen:
[Paradiso](https://www.paradiso.nl)
[Volkskrant](https://www.volkskrant.nl)

### Wat neem ik mee uit de les

Ik neem uit deze les mee dat ik bij interactieve onderdelen niet alleen moet nadenken over hoe ze eruitzien en of ze technisch werken. De woorden op een knop, de uitleg eromheen en hoe makkelijk je een keuze kunt maken, bepalen ook hoe eerlijk en duidelijk de ervaring voor een bezoeker is. De live-codeeroefening liet mij zien dat ik soms meer tijd nodig heb om code te begrijpen. De groepsopdracht hielp mij om kritischer te kijken naar de keuzes die een website aan bezoekers voorlegt.

## Check-out maandag 21 september

Ik heb deze samen met Eva geaakt.

1. Wat zijn HTML landmark role elements?
HTML landmark role elements zijn elementen die een webpagina verdelen in duidelijke onderdelen. Ze geven aan welke functie een bepaald gedeelte van de pagina heeft. Hierdoor kunnen mensen, zoekmachines en hulpmiddelen zoals screenreaders de structuur van een website beter begrijpen.
Voorbeelden zijn:
<header>: de bovenkant van een pagina, vaak met een titel of logo.
<nav>: het gedeelte met de navigatie en links.
<main>: de belangrijkste inhoud van de pagina.
<aside>: extra informatie die naast de hoofdinhoud staat.
<footer>: de onderkant van de pagina, bijvoorbeeld met contactgegevens.
<section>: een onderdeel van de pagina met een eigen onderwerp.
<form>: een gedeelte waarin een formulier staat.
Door deze elementen te gebruiken, wordt een website overzichtelijker en toegankelijker. Een gebruiker met een screenreader kan bijvoorbeeld direct naar de navigatie of de hoofdinhoud springen.

2. Wat zijn heading-elementen en hoe horen deze ‘genest’ te worden?
Heading-elementen zijn de koppen en tussenkoppen van een webpagina. In HTML gebruik je hiervoor <h1> tot en met <h6>.
De <h1> is de belangrijkste titel van de pagina. Een <h2> gebruik je voor de belangrijkste onderdelen onder deze titel. Wanneer een onderdeel binnen een <h2> weer een eigen tussenkop heeft, gebruik je een <h3>. Daarna kun je verdergaan met <h4>, <h5> en <h6>.
De koppen moeten in een logische volgorde worden gebruikt. Je hoort dus niet zomaar van een <h1> naar een <h4> te springen.
Bijvoorbeeld:
<h1>Mijn creatieve website</h1>

<h2>Haken</h2>
<h3>Mijn haakprojecten</h3>
<h3>Mijn haakpatronen</h3>

<h2>Binder art</h2>
<h3>Pokémon binder art</h3>
In dit voorbeeld is “Mijn creatieve website” het hoofdonderwerp. “Haken” en “Binder art” zijn onderwerpen binnen de website. De projecten en patronen zijn weer kleinere onderwerpen binnen deze onderdelen.
De heading-elementen hoeven niet letterlijk in elkaar geplaatst te worden. Met ‘nesten’ wordt hier vooral bedoeld dat de koppen inhoudelijk onder elkaar vallen en samen een duidelijke hiërarchie vormen.

3. Hoe ga jij met cookies om? Beschrijf jouw beweegredenen en of die zijn veranderd na het volgen van dit college.
   Voor het volgen van dit college accepteerde ik cookies meestal zonder goed te lezen waarvoor ze werden gebruikt. Ik klikte vaak op “alles accepteren”, omdat dit de snelste manier was om verder te gaan naar de website. Ik dacht toen niet veel na over welke informatie een website verzamelde en met welke partijen deze informatie gedeeld kon worden.
   Na dit college ben ik mij bewuster geworden van de verschillende soorten cookies. Noodzakelijke cookies zijn bijvoorbeeld nodig om een website goed te laten werken. Voorkeurscookies onthouden bepaalde instellingen. Analytische cookies verzamelen informatie over het gebruik van een website. Marketingcookies kunnen mijn gedrag op verschillende websites volgen om persoonlijke advertenties te laten zien.
   Mijn gedrag is hierdoor veranderd. Ik kijk nu beter naar de mogelijkheden in de cookiemelding. Wanneer het mogelijk is, accepteer ik alleen de noodzakelijke cookies en wijs ik marketing- en trackingcookies af. Soms accepteer ik analytische cookies wanneer deze alleen worden gebruikt om de website te verbeteren.
   Mijn belangrijkste beweegreden is mijn privacy. Ik wil meer controle hebben over welke gegevens van mij worden verzameld. Het college heeft mij laten zien dat cookies niet alleen handig zijn, maar ook gebruikt kunnen worden om mijn online gedrag te volgen. Daarom maak ik nu bewustere keuzes voordat ik cookies accepteer.

## Voorbereiding maandag 21 september

### verder werken aan mijn website

Voor de les van maandag hoefden we geen aparte voorbereidende opdracht te maken. Ik heb die tijd gebruikt om verder te coderen aan mijn eigen website. Na de inlevering van sprint 1 zag ik nog onderdelen die ik wilde aanvullen en verbeteren. Daarom ben ik verdergegaan met de uitwerking, zodat ik met een actuelere versie van mijn website aan sprint 2 kon beginnen.

Tijdens het coderen keek ik steeds wat er al werkte en wat nog aandacht nodig had. Ik maakte aanpassingen in mijn HTML en CSS en bekeek het resultaat in de browser. Zo kon ik zien of de veranderingen deden wat ik verwachtte. Als iets niet meteen goed stond, moest ik opnieuw naar mijn code kijken en een andere oplossing proberen.

Ik heb een paar foto’s gemaakt van de website terwijl ik eraan werkte. Die voeg ik hieronder toe, zodat zichtbaar is hoe mijn website er op dit moment uitzag en waar ik mee bezig was. Deze voorbereiding bestond dus vooral uit zelf verder bouwen en mijn werk stap voor stap verbeteren.
<img src="./assets/images-readme/21-9.png" alt=" Meerdere HTML's aangemaakt." />
Foto: Verder gewerkt aan mijn website.

# Sprint 1:

## Vrijdag 18 september (eerste DEADLINE!)

### Vrijdag – retrospectief en voortgangsgesprek

Voor de les had ik mijn website ingeleverd voor de deadline. Tijdens de les keken we terug op sprint 1 en bespraken we onze voortgang. Ik had ook het overzicht van de beoordelingspunten erbij. Daarin stond onder andere dat er gekeken werd naar onze website, de manier waarop we ons proces in de learning log hebben vastgelegd, onze ontwerpkeuzes en de uitwerking in HTML en CSS. Het hielp mij om te zien waarop ik feedback zou krijgen.

#### Retrospectief

Tijdens de les werkten we aan een retrospectief. Dat is een opdracht waarbij je terugkijkt op wat er de afgelopen twee weken is gebeurd, wat goed ging en wat lastig was. We gebruikten hiervoor _visual thinking_: je probeert je ervaringen en gedachten zichtbaar te maken met tekeningen. We begonnen met kleine tekenoefeningen, zoals kronkels in vogels veranderen en voorwerpen tekenen met basisvormen. Daardoor lag de nadruk minder op mooi kunnen tekenen en meer op een idee duidelijk overbrengen.

Daarna maakten we een piek- en daltekening van de afgelopen twee weken. Hiermee kon ik terugkijken op de momenten waarop ik vooruitgang voelde en op de momenten waarop het moeilijker ging. Bij die momenten keken we ook naar de competenties waaraan we hadden gewerkt en welke nog aandacht nodig hebben. Als laatste maakten we een metafoor met een titel voor onze ervaring van sprint 1. Ik vond het een andere manier van reflecteren dan alleen tekst schrijven: door te tekenen moest ik nadenken over hoe de verschillende gebeurtenissen met elkaar samenhingen. De afbeeldingen van mijn uitwerkingen voeg ik hieronder toe.
<img src="./assets/images-readme/aantekeningen-beoordelen.jpg" alt="Aantekeningen beoordelen op onder andere visuele hiërarchie." />
Foto: groeps opdracht het beoordelen van de aantekeningen.

<img src="./assets/images-readme/retrospectief-1.jpg" alt="Opdracht 1: van ronkels naar vogels" />
Foto: Opdracht 1: van ronkels naar vogels

<img src="./assets/images-readme/retrospectief-2.jpg" alt="Opdracht 2: simpele elementen tekenen" />
Foto: Opdracht 2: simpele elementen tekenen

<img src="./assets/images-readme/retrospectief-3.jpg" alt="Opdracht 3:Diek en daal tekening" />
Foto: Opdracht 3:Diek en daal tekening

<img src="./assets/images-readme/retrospectief-4.jpg" alt="Opdracht 4: een metafoor van sprint 1" />
Foto:Opdracht 4: een metafoor van sprint 1

#### beoordelingsgesprek

Terwijl we aan de retrospectief werkten, werden we één voor één naar een ander lokaal geroepen voor een voortgangsgesprek. Mijn gesprek was met Diederik. We bespraken mijn website en mijn voortgang aan de hand van de beoordelingspunten. Diederik gaf aan dat hij het knap vond hoeveel ik had gedaan, omdat ik door ziekte en privéomstandigheden niet altijd bij de lessen kon zijn en ook minder tijd had om aan mijn werk te besteden. Dat was fijn om te horen. Ik kreeg tijdens het gesprek het gevoel dat er met respect met mijn situatie werd omgegaan en dat er ook werd gezien hoeveel werk ik ondanks die omstandigheden had verzet.

Ik heb een positieve beoordeling en feedback gekregen. Dit was een formatieve beoordeling, dus ik kreeg geen eindcijfer. Het gesprek gaf mij wel een beter beeld van waar ik nu sta en of ik met mijn website op de goede weg ben. Dat stelde me gerust, zeker omdat ik zelf nog veel onderdelen zie die ik wil verbeteren.

Wat ik uit deze dag meeneem, is dat ik naast de dingen die nog niet af zijn ook mag kijken naar wat ik al heb bereikt. De retrospectief hielp mij om de afgelopen sprint als geheel te bekijken. Het voortgangsgesprek hielp mij om mijn werk door de ogen van een docent te zien. Met de feedback kan ik gerichter kiezen wat ik in de volgende sprint verder wil uitwerken en verbeteren.

## check-out vrijdag 18 september:

### Oriënteren en begrijpen

#### Waarom geven de docenten deze opdracht?

Volgens mij willen de docenten dat ik leer hoe ik een eigen idee omzet in een werkende website. Ik leer daarbij niet alleen HTML en CSS gebruiken, maar ook nadenken over mijn inhoud, ontwerpkeuzes en de mensen die mijn website bezoeken. Doordat de website over mijn eigen interesse gaat, moet ik zelf keuzes maken en kunnen uitleggen waarom ik die maak.

#### Welke technieken gebruik ik?

Ik gebruik HTML om mijn pagina’s en inhoud op te bouwen en CSS om de website vorm te geven. In CSS heb ik onder andere gewerkt met kleuren, lettertypes, afstanden en een lichte en donkere weergave. Door die technieken op mijn eigen website toe te passen, begrijp ik beter wat ze doen dan wanneer ik alleen voorbeelden uit een les overneem.

#### Wat zijn de randvoorwaarden?

Ik moet een werkende website inleveren en mijn proces en bronnen inzichtelijk maken. Ook moet ik rekening houden met wat we binnen de opdracht wel en niet mogen gebruiken. Mijn beschikbare tijd en mijn huidige kennis zijn voor mij ook randvoorwaarden: doordat ik ziek ben geweest en er privéomstandigheden waren, moest ik bepalen welke onderdelen ik eerst zou uitwerken. Daarbij wil ik blijven controleren of mijn website duidelijk en toegankelijk is.

#### Waar gebruik je HTML/CSS voor?

Met HTML geef ik betekenis en structuur aan de inhoud, bijvoorbeeld door titels, paragrafen, afbeeldingen en links op de juiste plek te zetten. Met CSS bepaal ik hoe die inhoud eruitziet en op het scherm wordt geplaatst. Ik merk dat ik beide nodig heb: een mooi ontwerp helpt weinig als de inhoud onduidelijk is, en goede inhoud wordt lastiger te gebruiken als de vormgeving niet helpt.

#### Wat kan er allemaal met CSS?

Ik ontdek steeds meer mogelijkheden van CSS. Ik kan er niet alleen kleuren en lettertypes mee aanpassen, maar ook onderdelen plaatsen, ruimte maken en verschillende weergaven ontwerpen. De light- en dark-mode-deep dive liet mij zien dat ik met CSS ook kan reageren op een gekozen thema. Tijdens het bouwen ontdek ik welke mogelijkheden ik voor mijn eigen website wil leren gebruiken. Ik vind het ook leuk dat je elke keer wat nieuws leert.

### Verbeelden en conceptualiseren

#### Lukt het om verschillende ideeën te bedenken?

Ja, ik heb tijdens mijn ontwerpproces meerdere ideeën voor de inhoud en vormgeving onderzocht. Ik heb bijvoorbeeld nagedacht over hoe ik mijn creatieve interesse kan laten zien en hoe bezoekers door de website kunnen gaan. Niet elk idee is uiteindelijk in de ingeleverde versie terechtgekomen. Het vergelijken van ideeën hielp mij wel om een richting te kiezen.

#### Lukt het om je ideeën te schetsen?

Schetsen helpt mij om ideeën die in mijn hoofd zitten zichtbaar te maken. Tijdens het schetsen zie ik sneller of een indeling logisch is en welke onderdelen nog ontbreken. Ik heb ook geleerd dat een schets niet netjes of definitief hoeft te zijn. Het is juist een manier om te denken, iets uit te proberen en daarna een andere versie te maken.

#### Wat doet deze CSS-property?

Bij het coderen probeer ik steeds beter te begrijpen wat een CSS-regel verandert. Soms zie ik meteen het verwachte resultaat, maar soms beïnvloedt een regel ook een ander onderdeel van de pagina. Dan kijk ik opnieuw naar mijn code en probeer ik stap voor stap te achterhalen waardoor dat gebeurt. Op die manier leer ik niet alleen welke waarde werkt, maar ook waarom.

#### Welke content, en welke HTML heb ik nodig?

Ik wil dat bezoekers begrijpen waar mijn website over gaat en dat ze verder kunnen klikken naar de inhoud die hen interesseert. Daarom heb ik nagedacht over welke teksten, afbeeldingen, navigatie en pagina’s daarvoor nodig zijn. Vlak voor de deadline wilde ik graag meerdere HTML-pagina’s hebben, zodat mijn idee duidelijker werd dan op één losse pagina. Tijdens het maken merk ik ook dat de inhoud invloed heeft op hoe ik de HTML moet indelen.

#### Hoe kan ik dit soort content vormgeven?

Ik onderzoek hoe ik tekst en beelden zo kan plaatsen dat de website duidelijk blijft en tegelijk bij mijn onderwerp past. Daarbij let ik op verschillen tussen een grote titel, een kopje en een paragraaf. Ook denk ik na over kleur en ruimte tussen onderdelen. Ik wil dat bezoekers eerst de belangrijkste informatie zien en daarna makkelijk verder kunnen lezen of klikken.

#### Wat als ik hier nu eens 1000 invul?

Deze vraag herinnert mij eraan dat ik tijdens het ontwerpen soms best een extreme waarde mag proberen. Als ik een formaat of afstand veel groter maak, zie ik duidelijker welk effect die keuze heeft. Ik hoef die extreme versie niet te houden, maar het experiment kan mij helpen om een betere keuze te maken dan wanneer ik steeds maar een heel klein beetje verander.

### Prototypen en uitwerken

#### Begrijpen bezoekers de site?

Ik kan zelf bedenken hoe iemand mijn website zou gebruiken, maar ik weet pas meer wanneer iemand anders hem probeert. Mijn zussen hebben mijn website getest. Tijdens dat testen zag ik een foutje dat ik zelf nog niet had opgemerkt en dat heb ik meteen opgelost. Dat liet mij zien hoe waardevol het is om anderen naar een werkende versie te laten kijken. Ik maak zelf ook altijd vaak gebruik van gebruikers testen op andere onderdelen bijv. op mijn schetsen dan vraag ik in mijn omgeving welke ze het makkelijkste vinden. Ik heb het ook gedaan bij mijn typografie, ik had verschillende fontsen ze laten zien en als eerste gevraagd welke hun het beste vonden qua duidelijkheid en leesbaarheid daarna had ik ze uitgelegd wat mijn doel was voor het lettertype. Het grappige hieraan is dat je dan ziet dat ze heel anders gaan kijken naar de lettertypes en dan geven ze soms hele andere feedback dan als ik niet die tweede vraag heb gevraagd.

#### Wat vindt de opdrachtgever ervan?

Bij deze opdracht geven de docenten feedback op mijn werk en mijn voortgang. Tijdens mijn gesprek met Diederik kreeg ik terug dat hij het knap vond hoeveel ik had gedaan, gezien ik ziek ben geweest en mijn privéomstandigheden. De beoordeling gaf mij het gevoel dat ik op de goede weg ben. Ik zie de feedback als informatie waarmee ik kan bepalen wat in een volgende versie nog aandacht nodig heeft.

#### Werkt dit wel?

Tijdens het bouwen merk ik soms pas of een idee in mijn website werkt. Een voorbeeld is de automatische stand die ik eerst naast light en dark mode had toegevoegd. Die gaf soms een probleem in combinatie met mijn gifje. Daarom heb ik de automatische stand weggehaald en gekozen voor een lichte en een donkere stand. Door het echt te bouwen, kon ik die keuze maken op basis van wat er gebeurde.

#### Oooooh, kan dit óók?!

Tijdens het toepassen van de light- en dark-mode-deep dive ontdekte ik dat ik dezelfde onderdelen met verschillende kleuren kan laten werken. Ik moest daardoor verder kijken dan alleen de achtergrond: ook tekst en knoppen moesten in beide standen kloppen. Dat vond ik interessant aan coderen. Een techniek die ik eerst als één kleine toevoeging zag, had invloed op mijn hele ontwerp.

### Evalueren

#### Wat wilde ik weten of bereiken?

Ik wilde een website maken waarop mijn idee en mijn creatieve interesse (haken) herkenbaar zijn. Voor de deadline wilde ik vooral dat er genoeg werkte om de bedoeling van de website te laten zien. Daarom vond ik het belangrijk om verder te komen dan één HTML-pagina en om mijn gekozen vormgeving ook echt in de code te verwerken.

#### Wat heb ik gedaan?

Ik heb ideeën geschetst, informatie gelezen, aantekeningen gemaakt en mijn website gebouwd met HTML en CSS. Ik heb de deep dive over light en dark mode toegepast en problemen die ik tijdens het coderen tegenkwam aangepakt. Ook heb ik mijn zussen de website laten testen (en andere mensen in mijn omgeveing hebben kleine onderdelen bekeken en getest of mening over gegeven) en mijn voortgang met Diederik besproken. In mijn learning log leg ik die stappen en mijn keuzes vast.

#### Wat was het resultaat?

Voor de deadline heb ik een versie van mijn website op tijd kunnen inleveren. Daarin was meer van mijn idee te zien doordat ik ook aan meerdere pagina’s had gewerkt. De lichte en donkere stand waren onderdeel van mijn website geworden. Tegelijkertijd was nog niet alles zoals ik het uiteindelijk wil hebben en was mijn README nog niet up-to-date. Dat laatste heb ik als notitie bij het inleveren gemeld.

#### Wat weet je nu wel en nog niet?

Ik begrijp beter hoe ik HTML gebruik voor de opbouw van mijn pagina’s en CSS voor de vormgeving. Ook heb ik geleerd dat testen een fout zichtbaar kan maken die ik zelf niet meer zie. Ik wil nog beter worden in het zelfstandig oplossen van CSS-problemen en in het controleren van mijn hele website op verschillende schermen en manieren van bedienen.

#### Wat vond je wel en niet leuk?

Ik vind het leuk om te zien hoe een idee langzaam verandert in een werkende website. Vooral het moment waarop iets dat ik heb bedacht ook echt in de browser verschijnt, motiveert mij. Het is minder leuk wanneer de code anders reageert dan ik verwacht of wanneer ik door tijdgebrek niet alles kan afmaken. Toch leer ik juist op die momenten om keuzes te maken en problemen stap voor stap te onderzoeken.
En heel eerlijk haal ik niet zo veel plezier uit het coderen zelf. Maar ik probeer er wel zo veel mogelijk van te leren en er uit te halen. Want ik heb zware dyslexie en daardoor is het voor mij echt heel lastig om goed te coderen. ALs ik een letter mis of een m=punt verkeerd heb staan dan zie ik dat gewoon niet alleen mijn code doet het dan natuurlijk ook niet.

#### Voldoet het nog aan de eisen?

Ik heb tijdens het werken naar de beoordelingspunten gekeken. Ik heb bijvoorbeeld gewerkt aan mijn procesdocumentatie, mijn ontwerpkeuzes en de lichte en donkere weergave. Ik weet ook dat er nog punten zijn om na te lopen. Mijn README was bij de deadline niet bijgewerkt; dat heb ik bij mijn inlevering aangegeven. Voor een volgende versie wil ik de eisen opnieuw naast mijn website leggen en per onderdeel controleren wat al klopt en wat nog werk vraagt.

#### Is mijn HTML nog valide?

Ik wil mijn HTML opnieuw controleren met een validator. Daarmee kan ik fouten vinden die ik niet meteen in de browser zie. Ik wil daarbij ook kijken of ik de juiste HTML-elementen gebruik en of de volgorde van mijn koppen logisch is. Een pagina die er goed uitziet, hoeft in de code namelijk nog niet helemaal goed opgebouwd te zijn.

#### Is mijn website toegankelijk?

Ik wil controleren of ik mijn website ook met een toetsenbord kan bedienen en of afbeeldingen passende alt-teksten hebben. Daarnaast wil ik het contrast van tekst en achtergrond in zowel de lichte als de donkere stand nakijken. Ik heb hier al over geleerd, maar ik wil niet doen alsof één snelle blik genoeg is om te weten dat de hele website toegankelijk is.

#### Is mijn website nog adaptief?

Ik heb een lichte en een donkere stand toegevoegd, maar ik wil nog controleren of alle onderdelen in beide standen goed zichtbaar blijven. Ook wil ik mijn pagina’s op verschillende schermgroottes bekijken. Omdat ik een gifje gebruik, wil ik verder onderzoeken wat er gebeurt als iemand minder beweging op het scherm heeft ingesteld.

#### Voldoet mijn website nog aan de wet?

Ik wil goed nagaan welke afbeeldingen en andere materialen ik op mijn website gebruik en of ik die mag gebruiken en correct vermeld. Ook wil ik nadenken over privacy als ik later onderdelen toevoeg die gegevens van bezoekers verwerken. Dit is voor mij nog een controlepunt; ik wil geen conclusie trekken zonder eerst mijn website en de gebruikte bronnen goed na te lopen. Ik weet dat we volgende sprint hier dieper op in duiken.

#### Zie ik mezelf nog terug in wat ik doe?

Ja! Mijn website gaat over een onderwerp dat bij mij past en ik maak zelf keuzes in de sfeer, beelden en vormgeving. Daardoor voelt het als mijn eigen project, ook wanneer nog niet alles af is. Ik wil bij volgende aanpassingen blijven kijken of ze mijn idee duidelijker maken, in plaats van iets toe te voegen alleen omdat het technisch mogelijk is.
Het gaat namelijk ook echt over mijn haak beestjes, het enige jammere is dat ik mijn afbeeldingen mooier en beter laat maken oor AI. Ik heb er over na gedacht om alles zelf te tekenen maar dan krijgen ze niet de uitstraling die ik ze wil geven. De beste oplossing is alles nog een keer zelf haken en dan mooie foto's maken alleen daar heb ik helaas de tijd niet voor. Ik zou dit zeker wel doen als het echt mijn eigen eigen website is buiten school om zodat ik te tijd heb om echt alles zelf te maken en mooi te fotograferen.
Alleen voor dit blok leek het mij de beste oplossing om de foto's te laten bijwerken door AI. Ik zet ook netjes op de foto aan AI teken zodat iedereen kan zien dat het AI gegenereerd is.

## voorbereiding vrijdag 18 september

### Vrijdag – voorbereiding en deadline

Voor vrijdag had ik minder voorbereidingstijd dan normaal. Donderdagochtend moest ik werken en in de middag en avond was ik op school voor mijn propedeuse-uitreiking. Gelukkig hoefden we deze keer geen artikelen te lezen of andere opdrachten voor te bereiden. De belangrijkste voorbereiding was om mijn website zo goed mogelijk af te maken voor de deadline en mijn README bij te werken.

Ik was nog niet helemaal tevreden met mijn website. Een website is natuurlijk nooit écht af, maar ik wilde wel dat bij het inleveren duidelijk werd wat mijn idee was en hoe bezoekers erdoorheen konden gaan. Na de uitreiking heb ik daarom nog kort iets gedronken bij Fest en ben ik daarna naar huis gegaan om ’s avonds verder te coderen.

Mijn belangrijkste doel voor die avond was om meerdere HTML-pagina’s te maken. Ik wilde dat de website meer zou zijn dan één losse pagina, zodat je bij het bekijken beter kon zien welke richting ik ermee op wilde. Door mijn lange reistijd had ik uiteindelijk minder tijd om te coderen dan ik vooraf dacht. Ik moest daarom kiezen wat ik voor de deadline nog kon afronden.

Het is gelukt om nog stappen te zetten en mijn website op tijd in te leveren. Mijn README heb ik helaas niet meer up-to-date kunnen maken. Dat heb ik meteen eerlijk vermeld in een notitie bij mijn inlevering, zodat duidelijk was dat de README nog niet de laatste stand van mijn website beschreef.

Ik merk dat ik kritisch blijf kijken naar mijn eigen werk en daardoor steeds nieuwe dingen zie die ik wil verbeteren. Voor deze deadline heb ik geleerd om keuzes te maken in de tijd die ik had. De README bijwerken en de onderdelen waar ik nog niet tevreden over ben, neem ik mee als volgende stappen.

## Woensdag 16 september

### Zelfstandig werken aan je website

Tijdens de les hebben we vooral zelfstandig aan onze eigen websites gewerkt. Het doel van deze dag was om zo veel mogelijk af te krijgen voor de deadline op vrijdag. Er was ruimte om in mijn eigen tempo door te werken. Als ik ergens tegenaan liep, kon ik rustig een vraag stellen aan de docenten.

Ik heb deze werktijd gebruikt om verder te kijken naar wat mijn website nog nodig had en om onderdelen te verbeteren. Omdat de deadline dichtbij kwam, moest ik keuzes maken: welke dingen waren belangrijk om nu werkend en duidelijk te krijgen, en welke details/informatie konden later nog aangepast worden? Het was prettig dat ik tijdens het werken meteen hulp kon vragen als ik vastliep, maar ook zelf eerst kon proberen een probleem op te lossen.

Deze les liet mij zien dat een website richting de deadline niet alleen afgemaakt, maar ook gecontroleerd moet worden. Ik wil daarom bij de laatste aanpassingen letten op de structuur van mijn pagina’s, de leesbaarheid van de tekst en of onderdelen op verschillende pagina’s consequent zijn vormgegeven.

## Check-out woensdag 16 september

1. Noem 3 Gestalt- of Design principes op en laat de ander uitleggen wat ze betekenen en doen.

Ik kies visuele hiërarchie, contrast en nabijheid:

- Visuele hiërarchie: je laat zien welke informatie het belangrijkst is. Een grote titel valt bijvoorbeeld eerder op dan een kleine paragraaf. Zo weet de bezoeker waar die eerst moet kijken.
- Contrast: je maakt een duidelijk verschil tussen onderdelen, bijvoorbeeld met lichte en donkere kleuren. Dat kan belangrijke onderdelen laten opvallen en helpt om tekst leesbaar te houden.
- Nabijheid: onderdelen die dicht bij elkaar staan, zien we als een groep. Een kopje moet daarom dichter bij de tekst staan waar het bij hoort dan bij het volgende onderdeel.

2. Een grid biedt ruimte om te spelen (vrijheid), maar tegelijkertijd ook eenheid en structuur (vastigheid). Wat wordt hiermee bedoeld?

Een grid is een soort onzichtbare indeling van een pagina, bijvoorbeeld met kolommen en vaste afstanden. Het geeft vastigheid, omdat je onderdelen netjes kunt uitlijnen en pagina’s daardoor bij elkaar passen. Binnen die indeling heb je toch vrijheid: een afbeelding kan bijvoorbeeld meer kolommen innemen dan een tekstblok. Je hoeft dus niet alles precies hetzelfde te maken, maar de pagina blijft wel overzichtelijk.

3. Welk principe neem je mee in een laatste iteratie van je eigen Garden?

Ik neem visuele hiërarchie mee. Bij mijn laatste aanpassingen wil ik controleren of meteen duidelijk is wat de titel is, welke kopjes bij welke tekst horen en welke knoppen belangrijk zijn. Daarvoor kijk ik naar de grootte van de tekst, de ruimte tussen onderdelen en het kleurcontrast. Zo kan ik mijn Garden duidelijker maken zonder de hele vormgeving opnieuw te veranderen.

## voorbereiding woensdag 16 september

### Verder werken aan mijn website: visueel ontwerp, light/dark mode en testen

Ik heb gelezen over visueel ontwerp en consistentie. Daarnaast heb ik verder gewerkt aan mijn website, een deep dive toegepast in mijn code en mijn website door mijn zussen laten testen. Ik merkte dat deze onderdelen met elkaar samenhangen: de artikelen hielpen mij bewuster naar mijn ontwerp te kijken, terwijl ik tijdens het coderen en testen ontdekte of mijn keuzes ook echt werkten.

#### Wat ik heb gelezen

Ik heb het artikel 5 Principles of Visual Design in UX van Nielsen Norman Group gelezen. Hierin worden vijf principes uitgelegd: schaal, visuele hiërarchie, balans, contrast en Gestalt. Wat ik hier vooral uit meenam, is dat vormgeving bezoekers helpt om informatie te begrijpen. Door een belangrijk onderdeel groter te maken, valt het eerder op. Met kleur, grootte en ruimte kun je laten zien waar iemand eerst naar moet kijken. Ook de afstand tussen onderdelen is belangrijk: als een kopje dicht bij een tekst staat, zie je sneller dat ze bij elkaar horen.

Daarna heb ik de Design Consistency Guide van UXPin gelezen. Dit artikel gaat over het consequent gebruiken van onderdelen in een ontwerp. Als dezelfde soort knop op iedere pagina een andere kleur of vorm heeft, moet een bezoeker telkens opnieuw nadenken over wat die knop doet. Hetzelfde geldt voor lettertypes, afstanden en de opbouw van pagina’s. Ik wil daarom beter opletten of ik mijn ontwerpkeuzes overal op dezelfde manier toepas.

Tijdens het lezen heb ik aantekeningen gemaakt. Hieronder voeg ik foto’s van mijn aantekeningen toe. Die laten zien welke punten ik uit de artikelen heb gehaald en wil gebruiken bij het verder ontwerpen van mijn website.
<img src="./assets/images-readme/aantekeningen-woe-16-9.png" alt="Aantekeningen van artikelen: 5 principes of visual design in UX en UXPin design consistency guide" />

#### Verder werken aan mijn website

Naast het lezen ben ik verdergegaan met mijn website. De website krijgt steeds meer vorm, maar er zijn ook nog onderdelen die ik moet uitwerken en verbeteren. Ik probeer daarbij niet alleen te kijken of iets er mooi uitziet, maar ook of de tekst duidelijk is, onderdelen bij elkaar horen en bezoekers begrijpen waar ze op kunnen klikken. De artikelen gaven mij woorden voor dingen waar ik tijdens het ontwerpen al mee bezig was, zoals hiërarchie, contrast en consistentie.

Ik loop op dit moment wat achter, omdat ik ziek ben geweest en er privé ook dingen speelden. Daardoor lukt het mij niet om helemaal gelijk te lopen met alle deep dives. Ik heb ervoor gekozen om gericht verder te werken aan mijn website en één deep dive meteen toe te passen. Mijn keuze viel op light en dark mode, omdat ik daar direct iets mee kon toevoegen aan mijn eigen ontwerp en tegelijkertijd kon oefenen met CSS.

#### Light en dark mode toepassen

Met behulp van de deep dive heb ik een lichte en een donkere weergave in mijn website gezet. Daarvoor heb ik de kleuren in mijn CSS vastgelegd en aangegeven welke kleur in de lichte en welke in de donkere stand gebruikt moet worden. Ik moest niet alleen nadenken over de achtergrondkleur, maar ook over de tekst, de knoppen en wat er gebeurt wanneer iemand over een knop beweegt. In beide standen moeten die onderdelen bij elkaar passen en leesbaar blijven.

Het toevoegen lukte niet meteen zonder problemen. Soms werkte iets anders dan ik verwachtte en moest ik opnieuw naar mijn code kijken. Door de uitleg uit de deep dive erbij te pakken en stap voor stap dingen aan te passen, heb ik die problemen kunnen oplossen. Dat vond ik leerzaam, omdat ik zo beter begreep wat de code doet in plaats van alleen een voorbeeld over te nemen.

Eerst had ik naast licht en donker ook een automatische stand toegevoegd. Daarbij kwam soms een fout naar voren in combinatie met mijn gifje. Ik heb geprobeerd te begrijpen waar het misging en heb uiteindelijk besloten de automatische stand weg te halen. Mijn website heeft nu een lichte en een donkere stand waaruit de bezoeker kan kiezen. Dat werkte op dit moment beter voor mijn website.

Van de stappen tijdens het coderen heb ik helaas geen foto’s gemaakt. In mijn code is wel terug te zien hoe ik de kleuren voor light en dark mode heb toegevoegd en welke keuze ik uiteindelijk heb gemaakt.

<img src="./assets/images-readme/aantekeingen-deepdive-lightanddark.png" alt="Aantekeningen van de Depp-dive over light and dark + aantekeningen/ opmerkingen na het coderen." />
Foto: Aantekeningen van de Depp-dive over light and dark + aantekeningen/ opmerkingen na het coderen

#### Testen met mijn zussen

Mijn zussen hebben mijn website ook getest. Ik heb daar wél 2 foto’s van gekregen en voeg die hieronder toe. Door hen de website te laten bekijken, kon ik zien hoe anderen ermee omgaan. Tijdens het testen zag ik nog een foutje dat mij eerder niet was opgevallen. Dat heb ik meteen opgelost.

Dit liet mij zien waarom het belangrijk is om een website niet alleen zelf te controleren. Als ik er lang aan werk, weet ik al hoe alles bedoeld is en kijk ik soms over een fout heen. Iemand die de website voor het eerst ziet, kijkt er anders naar. Ik wil daarom vaker tussendoor laten testen, ook wanneer de website nog niet helemaal af is.

<img src="./assets/images-readme/testen-lauwendees.png" alt=" Foto's van het bewijs dat ze getest hebben en hoe het er uit ziet." />
Foto: bewijs van testing + resultaat op mijn website.

## Maandag 14 september

### Bi-Weekly geek 1

Tijdens de eerste Bi-Weekly Geek stond de werking, betrouwbaarheid en verantwoordelijkheid van het internet centraal. We gingen in groepjes aan de slag met verschillende hoofdvragen. Het doel was om te leren hoe je een grote vraag kunt opdelen in kleinere deelvragen en daar vervolgens passende onderzoeksmethoden bij kunt zoeken.

#### Onze hoofdvraag

Mijn groepje bestond uit Eva, Seb, Massimo en mij. Wij kregen de volgende hoofdvraag:
Moeten kritieke internetdiensten in handen zijn van commerciële bedrijven?

Deze vraag sluit aan bij de voorbereiding over cloudbedrijven en de macht van grote technologiebedrijven. Veel websites en apps zijn afhankelijk van commerciële bedrijven zoals Amazon, Microsoft en Google. Wanneer één van deze bedrijven een grote storing heeft, kunnen veel verschillende diensten tegelijk uitvallen.

Voordat we de hoofdvraag konden beantwoorden, moesten we eerst bedenken welke informatie we nodig hadden. Daarom hebben we de hoofdvraag opgesplitst in kleinere deelvragen.

#### Onze deelvragen

Samen bedachten we de volgende deelvragen:

1. Wat zijn kritieke internetdiensten?
2. Welke bedrijven vallen onder commerciële bedrijven?
3. Over welke data beschikken kritieke internetdiensten?
4. Wat zijn de voor- en nadelen van kritieke internetdiensten in handen van commerciële bedrijven?
5. Wie heeft de kritieke internetdiensten op dit moment in bezit of onder controle?

Deze deelvragen bekijken de hoofdvraag vanuit verschillende kanten. We moeten eerst begrijpen wat kritieke internetdiensten zijn en welke bedrijven ze beheren. Daarna kunnen we onderzoeken welke gegevens deze diensten verwerken en wat de mogelijke voordelen en risico’s van commercieel beheer zijn.

#### Werkblad uitwisselen

Nadat iedere groep deelvragen had bedacht, wisselden we onze werkbladen uit. Iedere groep kreeg daardoor het blad van een andere groep.

Bij het tweede onderdeel moesten we niet zelf nieuwe deelvragen bedenken. We bekeken de deelvragen van de andere groep en zochten bij iedere vraag een passende onderzoeksmethode. Hiermee onderzochten we hoe de groep informatie kon verzamelen om de hoofdvraag uiteindelijk zo goed mogelijk te beantwoorden.

We dachten bijvoorbeeld na over methoden zoals:

- deskresearch;
- artikelen en betrouwbare bronnen vergelijken;
- experts interviewen;
- verschillende bedrijven of diensten vergelijken;
- bestaande gegevens en onderzoeken analyseren.

Door het werkblad uit te wisselen, kregen we een andere kijk op de vragen. We moesten niet alleen nadenken over wat iemand wilde weten, maar vooral over hoe die informatie onderzocht kon worden.

Van het tweede werkblad heb ik helaas geen foto gemaakt. Daarom beschrijf ik deze stap in mijn Learning Log.

#### Het verband met mijn voorbereiding

De opdracht sloot goed aan bij de bronnen die ik vooraf had bekeken. In het artikel over de cloudstoring werd duidelijk dat veel internetdiensten afhankelijk zijn van een klein aantal commerciële cloudbedrijven.

Deze bedrijven kunnen voordelen bieden. Ze beschikken bijvoorbeeld over veel technische kennis, grote datacenters en voldoende geld om hun systemen te onderhouden. Tegelijkertijd kan deze afhankelijkheid ook risico’s veroorzaken. Een storing, verandering in voorwaarden of verkeerde beslissing van één bedrijf kan gevolgen hebben voor veel gebruikers en organisaties.

Het artikel over Tim Berners-Lee liet daarnaast zien dat grote technologiebedrijven niet alleen veel infrastructuur beheren, maar ook veel macht hebben over persoonsgegevens, platforms en de manier waarop mensen het web gebruiken.

Door de hoofdvraag begreep ik beter dat de betrouwbaarheid van het internet niet alleen een technisch probleem is. Het is ook een vraag over eigendom, verantwoordelijkheid, privacy en macht.

#### Wat heb ik geleerd?

Tijdens deze les heb ik geleerd dat een brede hoofdvraag niet direct te beantwoorden is. Door de vraag op te delen in kleinere deelvragen wordt duidelijker welke informatie nodig is.

Ook heb ik geleerd dat iedere deelvraag een passende onderzoeksmethode nodig heeft. Een feitelijke vraag kan bijvoorbeeld onderzocht worden met deskresearch, terwijl een vraag over ervaringen of meningen beter onderzocht kan worden met interviews.

Het uitwisselen van de werkbladen vond ik nuttig, omdat een andere groep met een frisse blik naar de vragen keek. Hierdoor zag ik dat onderzoek niet alleen draait om goede vragen bedenken, maar ook om bewust kiezen hoe je betrouwbare antwoorden verzamelt.

## Check-out maandag 14 sept.

1. Leg uit wanneer een website ‘lelijk’ wordt en geef voorbeelden van wat je kan doen om deze ‘lelijke’ onderdelen te fixen.
   Een website wordt ‘lelijk’ wanneer de vormgeving op bepaalde schermformaten niet meer goed werkt. Tekst kan bijvoorbeeld te breed worden, afbeeldingen kunnen buiten het scherm vallen en onderdelen kunnen over elkaar heen komen te staan. Dit kan ik oplossen met flexibele eenheden, max-width, flex-wrap en media queries.

2. Vertel welke volgende stap je neemt om je website responsive te maken.
   Mijn volgende stap is om mijn website op verschillende schermformaten te testen. Daarna pas ik onderdelen die niet goed meeschalen aan en voeg ik waar nodig media queries toe voor grotere schermen.

3. Kun je het ontwerp en de bouw van je eigen Garden uit je hoofd onderbouwen in Webby vocabulary?
   Mijn digital garden is responsive, omdat de indeling zich aanpast aan verschillende schermformaten. De website is ook interactief en dynamisch door de navigatie, knoppen, links en animaties. Met semantische HTML, duidelijke koppen, alt-teksten, voldoende contrast en toetsenbordfocus probeer ik de website daarnaast toegankelijk te maken. De kleuren, zachte vormen, afbeeldingen en typografie maken mijn website expressief en persoonlijk.

## Voorbereiding maandag 14 september

Voor de eerste Bi-Weekly Geek heb ik vooraf één video bekeken en twee artikelen gelezen. De bronnen gingen over de technische werking van het internet, de afhankelijkheid van grote cloudbedrijven en de oorspronkelijke bedoeling van het World Wide Web.

#### Hoe werkt het internet?

In de video van BBC werd uitgelegd dat het internet bestaat uit verschillende computers en apparaten die met elkaar verbonden zijn. Samen vormen deze apparaten een groot netwerk.

Om informatie op de juiste plaats te krijgen, gebruikt het internet vaste regels. Deze regels worden protocollen genoemd. Grote bestanden en berichten worden tijdens het versturen verdeeld in kleine stukjes. Deze stukjes heten pakketjes.

Ieder pakketje bevat informatie over:

- waar het vandaan komt;
- waar het naartoe moet;
- hoe het later weer moet worden samengevoegd.

Ieder apparaat op het internet heeft een eigen numeriek adres: een IP-adres. Een Domain Name System, oftewel DNS, werkt als een soort adresboek. Het vertaalt een herkenbare domeinnaam naar het bijbehorende IP-adres.

Vervolgens sturen routers de pakketjes door het netwerk. De pakketjes kunnen verschillende routes volgen. Wanneer ze op hun bestemming aankomen, worden ze weer in de juiste volgorde samengevoegd.

Door deze video begrijp ik beter dat het internet niet één onzichtbaar systeem is. Het bestaat uit veel apparaten, servers, kabels, adressen en afspraken die samenwerken om informatie te versturen.

#### The Guardian – The cloud crash

Het eerste artikel ging over een grote storing bij Amazon Web Services, ook wel AWS genoemd. AWS levert cloudservices aan veel verschillende bedrijven. Deze bedrijven huren bijvoorbeeld opslagruimte, servers en rekenkracht van Amazon.

Door de storing werkten veel websites en apps tijdelijk niet meer. Dit liet zien dat veel verschillende online diensten achter de schermen afhankelijk zijn van dezelfde grote cloudbedrijven.
De cloud klinkt alsof gegevens onzichtbaar ergens op het internet zweven, maar bestaat in werkelijkheid uit fysieke datacenters met computers en servers. Wanneer er bij een belangrijk datacenter een probleem ontstaat, kan dit wereldwijd gevolgen hebben.

De grootste cloudproviders zijn:

- Amazon Web Services;
- Microsoft Azure;
- Google Cloud.
  Overstappen naar een andere aanbieder is vaak moeilijk, duur en tijdrovend. Bedrijven bouwen hun systemen namelijk rondom de technieken van één aanbieder. Hierdoor kan een sterke leveranciersafhankelijkheid ontstaan.

Dit is ook belangrijk voor Europa. Veel Europese bedrijven, overheden en publieke diensten gebruiken infrastructuur van Amerikaanse technologiebedrijven. Hierdoor heeft Europa minder controle over belangrijke digitale voorzieningen.

Mogelijke oplossingen zijn:

- Meer Europese cloudinfrastructuur ontwikkelen;
- open standaarden gebruiken;
- meer met open-source technologie werken;
- het makkelijker maken om tussen aanbieders te wisselen.

 <img src="./assets/images-readme/aantekeingen-ma14-9-1.png" alt="Aantekeningen van artikel The Guardian" />
 Foto: aantekeningen van het artikel

#### Tim Berners-Lee en de toekomst van het web

Het tweede artikel ging over Tim Berners-Lee, de bedenker van het World Wide Web. Hij bedacht het web in 1989 als een open systeem waarmee mensen informatie konden delen en samenwerken.

Het internet en het web zijn niet precies hetzelfde. Het internet is de technische infrastructuur waarmee apparaten met elkaar verbonden zijn. Het World Wide Web is een systeem van websites en pagina’s dat gebruikmaakt van die infrastructuur.

Volgens Berners-Lee is een deel van het web steeds commerciëler geworden. Grote technologiebedrijven verdienen geld aan advertenties, aandacht en persoonsgegevens. Sociale media worden daarom vaak ontworpen om mensen zo lang mogelijk te laten kijken, klikken en scrollen.

Hierdoor heb ik geleerd dat technologie niet neutraal is. Ontwerpkeuzes kunnen het gedrag van gebruikers beïnvloeden. Voorbeelden hiervan zijn:

- eindeloos scrollen;
- meldingen;
- aanbevolen berichten;
- algoritmes die bepalen wat iemand ziet.
  Berners-Lee werkt daarom aan Solid. Dit project moet gebruikers meer controle geven over hun eigen gegevens. Bij Solid worden persoonlijke gegevens opgeslagen in een eigen digitale opslag, een zogenaamde pod. De gebruiker bepaalt vervolgens zelf wie toegang krijgt tot welke informatie.

In het artikel bespreekt Berners-Lee ook kunstmatige intelligentie. Hij vindt dat er meer onafhankelijke controle, duidelijke regels en internationale samenwerking nodig zijn. Hij vergelijkt dit met CERN, waar wetenschappers uit verschillende landen gezamenlijk onderzoek doen.

De belangrijkste boodschap die ik uit dit artikel haal, is dat het web opnieuw meer voor de gebruiker ontworpen moet worden. Mensen moeten meer controle krijgen over hun gegevens en grote technologiebedrijven moeten niet alle macht over het web en de data van gebruikers hebben.

<img src="./assets/images-readme/aantekeingen-ma14-9-2.png" alt="Aantekeningen van artikel Tim Barners-Lee" />
 Foto: aantekeningen van het artikel

#### Het verband tussen de bronnen

De drie bronnen bekijken het internet vanuit verschillende kanten.
De video van BBC legt uit hoe informatie technisch over het internet wordt verstuurd. Het artikel over de cloudstoring laat zien wie een groot deel van de technische infrastructuur beheert. Het artikel over Tim Berners-Lee gaat vooral over wie controle heeft over het web, digitale platforms en de gegevens van gebruikers.

De artikelen laten allebei zien dat het internet open en verspreid lijkt, terwijl veel macht bij een klein aantal grote technologiebedrijven ligt. Deze bedrijven beheren een groot deel van de infrastructuur, platforms en persoonsgegevens.

Hierdoor begrijp ik dat het internet niet alleen een technisch onderwerp is. Het gaat ook over macht, verantwoordelijkheid, privacy, betrouwbaarheid en onafhankelijkheid.

#### Wat heb ik geleerd?

Door deze voorbereiding begrijp ik beter hoe het internet technisch werkt en welke bedrijven een belangrijke rol spelen in de infrastructuur ervan.
Ik heb geleerd dat:

- gegevens als kleine pakketjes over het internet worden verstuurd;
- protocollen ervoor zorgen dat apparaten dezelfde regels gebruiken;
- IP-adressen en DNS nodig zijn om de juiste bestemming te vinden;
- veel websites afhankelijk zijn van enkele grote cloudproviders;
- een storing bij één aanbieder veel verschillende diensten kan raken;
- ontwerpkeuzes invloed hebben op het gedrag van gebruikers;
- gebruikers vaak weinig controle hebben over hun persoonsgegevens;
- het belangrijk is om na te denken over openheid, privacy en onafhankelijkheid.

De voorbereiding gaf mij genoeg achtergrondinformatie om tijdens de Bi-Weekly Geek mee te kunnen praten over vragen zoals: Wie heeft controle over het internet? en Wie is verantwoordelijk voor de betrouwbaarheid van het internet?

## Vrijdag 11 september

### korte samenvatting van de voorbereiding (bij het voorbereiden kopje staat het uitgebreid)

#### Mobile-first schermschetsen

Als voorbereiding werkte ik mijn gekozen ideeën eerst uit voor een mobiel scherm. Hierdoor moest ik goed nadenken over welke content het belangrijkste is en wat de gebruiker als eerste moet zien.

Voor het kiezen van een Pokémonkaart maakte ik twee varianten:

- Een horizontale waaier waarin de middelste kaart het grootste is. De gebruiker kan naar links of rechts swipen.
- Een verticale indeling waarin de kaarten onder elkaar staan. De gebruiker kan door de kaarten scrollen.

Voor mijn haakpatronen maakte ik ook twee galerij-indelingen. In de eerste schets staan grote afbeeldingen onder elkaar. In de tweede schets wisselen afbeeldingen en korte teksten elkaar af. Rond de afbeeldingen tekende ik zachte en wollige vormen om de sfeer van het haken terug te laten komen.
Bij de mobiele schetsen hield ik rekening met: een indeling in één kolom;

- de belangrijkste informatie bovenaan;
- grote klikvlakken;
- duidelijke koppen;
- realistische verhoudingen voor afbeeldingen en teksten;
- een ontwerp dat past bij een kleiner scherm.

#### Vertaling naar desktop

Daarna vertaalde ik dezelfde ideeën naar een groter laptopscherm. Ik maakte geen volledig nieuw ontwerp, maar onderzocht hoe ik de extra ruimte kon gebruiken.
Op een mobiel scherm staat de content vooral onder elkaar. Op een laptopscherm kunnen meerdere kaarten of projecten naast elkaar worden getoond. De belangrijkste Pokémonkaart kan centraal blijven staan, terwijl andere kaarten of binder-artvarianten eromheen worden geplaatst.

Bij de desktopversies lette ik erop dat:

- het belangrijkste onderdeel het meeste opvalt;
- de extra ruimte nuttig wordt gebruikt;
- meerdere afbeeldingen naast elkaar kunnen staan;
- de visuele hiërarchie hetzelfde blijft;
- hover- en focus-states mogelijk zijn;
- de mobiele en desktopversie herkenbaar bij elkaar horen.

De foto's staan bij de voorberiding.

### zelfstsandig verder werken + feedback moment.

Tijdens de les mochten we zelfstandig verder werken aan onze website. Tussendoor voerden we in kleine groepjes gesprekken met Justus of Sanne. Tijdens dit gesprek bekeken we hoe ver iedereen was, wat al goed ging en waar iemand nog tegenaan liep.

Ons groepje was als eerste aan de beurt. We lieten één voor één onze presentatie zien. Als iemand al iets in HTML had gebouwd, kon dit ook worden getoond.
Omdat ik eerder had verteld dat ik nog twijfelde over het onderwerp van mijn website, hebben we bij mij vooral naar mijn presentatie en schetsen gekeken. We onderzochten samen welk onderwerp de meeste mogelijkheden bood voor mijn digital garden.

#### Feedback op mijn onderwerp

Tijdens het bekijken van mijn presentatie merkte ik dat Justus vooral enthousiast werd van mijn haakprojecten. Daarna bekeken we mijn mobiele en desktop-schetsen. Aan de verschillende ideeën was duidelijk te zien dat ik nog niet helemaal zeker wist welke richting ik wilde kiezen.

Justus legde uit dat het onderwerp haken sterk is omdat het persoonlijk bij mij past. Ook sluit het goed aan bij mijn gekozen sfeerwoorden en bij de zachte, handgemaakte uitstraling die ik in mijn Visual Research had verzameld.

Deze feedback hielp mij om een duidelijkere keuze te maken. Ik besloot om mij voor mijn website vooral te richten op mijn haakwereld en haakcreaties. Hierdoor werd het makkelijker om keuzes te maken voor de inhoud, typografie, kleuren en vormgeving van mijn website.

De foto's van mijn schetsen en presentatie staat eerder in mijn learnig log.

#### Een passend lettertype onderzoeken

Na het gesprek kon ik weer zelfstandig verder. Ik begon met het zoeken naar een lettertype dat bij de gewenste uitstraling van mijn website past.

Ik wilde een lettertype vinden dat:

- creatief aanvoelt;
- past bij de handgemaakte uitstraling van haken;
- goed leesbaar blijft;
- aansluit bij mijn sfeerwoorden;
- gebruikt kan worden op mijn website.

Ik heb verschillende lettertypen bekeken. Een aantal lettertypen vond ik erg mooi, maar deze waren betaald. Daarom besloot ik deze niet te gebruiken.

Uiteindelijk koos ik een lettertype uit Google Fonts. Bij de verdere uitwerking wil ik onderzoeken of ik het lettertype lokaal in mijn website kan opslaan. Hierdoor hoeft de browser van een bezoeker niet iedere keer verbinding te maken met een externe fontservice. Dit past bij mijn doel om zo bewust mogelijk om te gaan met de privacy en dataverspreiding van mijn bezoekers.

 <img src="./assets/images-readme/fontsen.png" alt="De fontsen die ik heb bekeken en heb vergeleken voor mijn website" />

Foto" Lettertypes die ik intressant vond.

Bronnen:
[Twisted rope font](https://www.creativefabrica.com/product/twisted-rope)
[Abode fonts](https://fonts.adobe.com)
[Envato](https://elements.envato.com)
[Creative kitting font](https://www.creativefabrica.com/product/creative-knitting)
[Google fonts](https://fonts.google.com)

#### Kleurenpaletten maken

Naast de typografie heb ik verschillende kleurenpaletten samengesteld. Ik wilde onderzoeken welke kleuren het beste aansluiten bij mijn haakprojecten en mijn sfeerwoorden.

Ik keek daarbij naar:

- zachte en warme kleuren;
- kleuren die een cozy gevoel geven;
- voldoende contrast tussen tekst en achtergrond;
- kleuren die passen bij mijn afbeeldingen;
- accentkleuren voor knoppen en belangrijke onderdelen.

Door meerdere kleurenpaletten naast elkaar te zetten, kon ik beter vergelijken welke combinatie het beste bij mijn onderwerp past. Ik wilde voorkomen dat de website te druk zou worden. De haakcreaties moeten centraal blijven staan en de kleuren moeten deze afbeeldingen ondersteunen.

 <img src="./assets/images-readme/kleurpallets.png" alt="De kleuren pallets die ik heb gemaakt voor mijn webside." />
  <img src="./assets/images-readme/gekozen-pallet.png" alt="De kleuren die ik heb gekozen voor mijn website." />
  Foto's: Kleurpalleten

Bron: Adobe color
[Adobe color website](https://color.adobe.com/create/color-wheel)

#### Gebruik van AI voor mijn afbeeldingen

Voor de afbeeldingen op mijn website heb ik mijn eigen foto’s van de gehaakte dieren gebruikt. Wanneer ik zelf nog geen goede foto had, gebruikte ik de voorbeeldfoto van het dier uit het bijbehorende haakpatroon.

Ik heb deze foto’s aan ChatGPT gegeven en gevraagd om er een mooier en duidelijker beeld van te maken. Het was belangrijk dat de gehaakte dieren realistisch bleven en herkenbaar waren als hetzelfde dier. De kleuren, vorm, het gebruikte garen en de verschillende onderdelen moesten daarom hetzelfde blijven.

Daarnaast wilde ik dat alle afbeeldingen op mijn website dezelfde uitstraling kregen. Daarom heb ik bij iedere afbeelding gevraagd om een warme en gezellige omgeving, zachte belichting en natuurlijke materialen. Hierdoor vormen de afbeeldingen samen één geheel en passen ze beter bij de stijl van mijn website.

Voor de procesfoto’s heb ik de prompt aangepast door te beschrijven welke stap zichtbaar moest zijn. Ik vroeg bijvoorbeeld om een foto waarop een onderdeel werd gehaakt, alle losse onderdelen klaar lagen of het dier in elkaar werd gezet.

Na het maken van de afbeeldingen heb ik gecontroleerd of het dier nog overeenkwam met mijn eigen foto of de originele voorbeeldfoto. Wanneer onderdelen, kleuren of vormen niet klopten, heb ik de prompt aangepast en een nieuwe afbeelding laten maken.

##### De prompt's die ik heb gebruikt voor Chatgpt:

Gebruik de bijgevoegde foto van mijn gehaakte dier of de voorbeeldfoto uit het haakpatroon als basis. Maak hiervan een mooie en realistische foto. Het gehaakte dier moet hetzelfde blijven: behoud de vorm, kleuren, verhoudingen, het soort garen en alle herkenbare onderdelen. Plaats het dier in een warme en gezellige omgeving met zachte stoffen en natuurlijk daglicht. Gebruik rustige zand- en bruintinten, zodat de afbeelding past bij de andere foto’s op mijn website. Zorg voor een scherpe en professionele foto, maar laat het beeld wel natuurlijk en handgemaakt aanvoelen. Voeg geen tekst, logo of watermerk toe.

Aanvulling voor procesfoto’s:
Laat zien dat het gehaakte dier nog wordt gemaakt. Toon handen die bezig zijn met haken, vullen of het vastnaaien van een onderdeel. Zorg dat alleen de onderdelen zichtbaar zijn die op dat moment al af horen te zijn. Gebruik dezelfde warme, realistische stijl als bij de andere afbeeldingen.

 <img src="./assets/images-readme/voorenna.png" alt="Voor en na foto's" />
 Foto: het verschil tussen de foto's voor en na chat.

#### Wat heb ik geleerd?

Tijdens deze les heb ik geleerd hoe waardevol het is om mijn ideeën aan iemand anders te laten zien. Zelf bleef ik lang twijfelen tussen verschillende onderwerpen. Door het gesprek met Justus werd duidelijk welk onderwerp het persoonlijkste is en de meeste mogelijkheden biedt.

Ik heb ook geleerd dat mijn onderwerp invloed heeft op bijna alle ontwerpkeuzes. Nadat ik voor haken had gekozen, kon ik gerichter zoeken naar passende kleuren, lettertypen, vormen en afbeeldingen.

Daarnaast ben ik bewuster gaan nadenken over externe diensten. Een lettertype moet niet alleen mooi en leesbaar zijn, maar ook praktisch beschikbaar zijn en op een bewuste manier aan de website worden toegevoegd.

Aan het einde van de les had ik daardoor een veel duidelijkere richting voor mijn digital garden. Ik wist beter welk onderwerp centraal zou staan en welke uitstraling daarbij past.

## Chech-out vrijdag 11 september

Welke feedback heb gehad?
Ik heb alle ontvangen feedback hier boven beschreven.

## voorbereiding 11 september

#### Mobile-first schermschetsen

Ik werkte de gekozen ideeën eerst uit voor een mobiel scherm. Hierdoor moest ik goed nadenken over welke content het belangrijkste is en wat de gebruiker als eerste moet zien.
Voor het kiezen van een Pokémonkaart maakte ik twee varianten:

- Een horizontale waaier waarin de middelste kaart het grootste is en de gebruiker naar links of rechts kan swipen.
- Een verticale indeling waarin de kaarten onder elkaar staan en de gebruiker kan scrollen.
- Voor mijn haakpatronen maakte ik ook twee galerij-indelingen. In de eerste staan grote afbeeldingen onder elkaar. In de tweede worden afbeeldingen afgewisseld met korte teksten. Rond de afbeeldingen tekende ik zachte en wollige vormen om de sfeer van het haken terug te laten komen.

Bij de mobiele schetsen hield ik rekening met:

- een indeling in één kolom;
- de belangrijkste informatie bovenaan;
- grote klikvlakken;
- realistische afbeeldingen en tekst;
- duidelijke koppen;

 <img src="./assets/images-readme/mobielscherm-1.png" alt="" />
  <img src="./assets/images-readme/mobielscherm-2.png" alt="" />
   <img src="./assets/images-readme/mobielscherm-3.png" alt="" />
Foto's: mijn schetsen van de mobile- first schermschetsen.

#### Vertaling naar desktop

Daarna vertaalde ik dezelfde ideeën naar een groter laptopscherm. Ik maakte geen compleet nieuwe ontwerpen, maar onderzocht hoe ik de extra ruimte kon gebruiken.
Op mobiel staat de content vooral onder elkaar. Op desktop kunnen meerdere kaarten of projecten naast elkaar staan. De belangrijkste Pokémonkaart blijft centraal staan, terwijl andere kaarten of binder-artvarianten eromheen worden geplaatst.

Ik lette erop dat:

- het belangrijkste onderdeel het meeste opvalt;
- de extra ruimte nuttig wordt gebruikt;
- meerdere afbeeldingen naast elkaar kunnen staan;
- de visuele hiërarchie hetzelfde blijft;
- hover- en focus-states mogelijk zijn;
- mobiel en desktop herkenbaar bij elkaar horen.

# foto toevoegen!!

## woensdag 9 september (online les NS-staking)

### Visual Research, Crazy 8 en schermschetsen

Tijdens deze les heb ik verder gewerkt aan de visuele stijl en indeling van mijn digital garden. Ik begon met Visual Research. Daarna maakte ik een Crazy 8, beoordeelde ik mijn ideeën en werkte ik de beste ideeën uit als mobiele en desktop-schetsen.

#### Mijn sfeerwoorden bepalen

Als uitgangspunt voor mijn Visual Research koos ik de sfeerwoorden:

- speels
- cozy
- fantasierijk

  Deze woorden passen bij mijn creatieve onderwerpen, zoals Pokémon binder art, haken, stickers en journalen. Ik wil dat mijn website persoonlijk, creatief en gezellig aanvoelt. De verschillende onderdelen mogen een eigen uitstraling hebben, maar moeten door het gebruik van kleuren en vormen wel bij elkaar passen.
  <img src="./assets/images-readme/9-9-opdracht1.png" alt="Mijn keuze voor mijn sfeerwoorden en de uitleg waarom ik hiervoor heb gekozen." />
  Foto: Mijn keuze voor mijn sfeerwoorden en de uitleg waarom ik hiervoor heb gekozen

#### Stap 1: directe beelden verzamelen

Eerst verzamelde ik afbeeldingen die direct passen bij mijn hobby’s en sfeerwoorden. Ik zocht onder andere naar Pokémon, binder art, haakprojecten, journals, stickers en andere creatieve producten.
Ik keek niet alleen naar het onderwerp van de afbeeldingen, maar ook naar kleur, vorm, materiaal en uitstraling. Ik zag vooral zachte vormen, vrolijke kleuren, handgemaakte materialen en fantasierijke illustraties terug.
<img src="./assets/images-readme/9-9-opdracht2.png" alt="De afbeeldingen die ik heb gebruikt in mijn presentatie" />
Foto:De afbeeldingen die ik heb gebruikt in mijn presentatie

#### Stap 2: abstracte beelden verzamelen

Daarna zocht ik naar abstractere beelden. Hierbij keek ik minder naar de hobby’s zelf en meer naar de visuele kenmerken die bij mijn sfeerwoorden passen.
Ik verzamelde voorbeelden van:
zachte en organische vormen;
afgeronde vlakken;
vrolijke kleuren en pastelkleuren;
collages en patronen;
speelse typografie;
onderdelen die in elkaar overlopen.
Hierdoor ontdekte ik dat niet alleen het onderwerp, maar ook de kleuren, vormen, typografie en plaatsing de sfeer van mijn website bepalen.
<img src="./assets/images-readme/9-9-opdracht3.png" alt="Inspiratie op zoeken om mijn sfeer woorden een vusieel beeld te geven." />
Foto: Inspiratie op zoeken om mijn sfeer woorden een vusieel beeld te geven.

#### Stap 3: visuele uitgangspunten bepalen

Uit mijn verzameling koos ik vier afbeeldingen die mij het meeste aanspraken. Per afbeelding beschreef ik waarom deze bij mijn sfeerwoorden past en welke kenmerken ik kan gebruiken.
Daaruit kwamen de volgende visuele uitgangspunten:

- Ik gebruik afgeronde en organische vormen.
- Ik werk met zachte kleuren en enkele fellere accenten.
- Onderdelen mogen speels worden geplaatst.
- Mijn eigen projecten en afbeeldingen staan centraal.
- De website moet cozy en persoonlijk aanvoelen.
- De verschillende hobby’s moeten herkenbaar zijn, maar wel bij dezelfde stijl horen.
  <img src="./assets/images-readme/9-9-opdracht4.png" alt="Jouw 4 gekozen afbeelding beoordelen aan de hand van 3 vragen" />
  Foto: Jouw 4 gekozen afbeelding beoordelen aan de hand van 3 vragen

#### Crazy 8 maken

Na het Visual Research maakte ik een Crazy 8. Hierbij schetste ik in korte tijd acht verschillende ideeën:

1. Kiezen tussen Pokémonkaarten waarvoor ik binder art heb gemaakt.
2. Een kaart kiezen en de bijbehorende binder-artvarianten bekijken.
3. Mijn haakpatronen als een galerij presenteren.
4. Zelf een stickervel samenstellen.
5. Mijn creatieve proces als een flow weergeven.
6. Pokémon-types als gekleurde tegels vormgeven.
7. Het eindresultaat en proces naast elkaar tonen.
8. Extra informatie tonen wanneer de gebruiker over een bolletje beweegt of erop klikt.
   Na het schetsen annoteerde ik de ideeën. Met pijlen en korte teksten gaf ik aan wat een gebruiker kan doen en welke interacties ik voor mij zie.
   <img src="./assets/images-readme/9-9-opdracht5.png" alt="Opdracht een crazy 8 maken" />
   Foto: Opdracht een crazy 8 maken

#### Mijn ideeën beoordelen

Vervolgens beoordeelde ik de acht ideeën met het bijbehorende werkvel. Per idee keek ik of het ontwerp:

- fluïde en adaptief is;
- interactief en dynamisch is;
- toegankelijk is;
- binnen de beschikbare tijd gemaakt kan worden;
- expressief genoeg is;
- leuk of verrassend is.
  Hierdoor keek ik niet alleen naar welke ideeën ik mooi vond, maar ook naar welke ideeën geschikt en haalbaar zijn voor het web. Het zelf samenstellen van een stickervel is bijvoorbeeld erg interactief, maar waarschijnlijk ook lastiger om binnen deze sprint te bouwen.
  <img src="./assets/images-readme/9-9-opdracht6.png" alt="Mijn beoordelings formulier voor de crazy 8" />
  Foto: Mijn beoordelings formulier voor de crazy 8

#### Ideeën verder uitwerken

Na de beoordeling koos ik drie ideeën om verder te onderzoeken:
Kiezen tussen verschillende Pokémonkaarten.
Binder art bekijken voor een gekozen kaart.
Haakpatronen als een galerij presenteren.
Bij het eerste idee controleert de gebruiker of de eigen Pokémonkaart ertussen staat. Daarna kan de gebruiker bij het tweede idee bekijken welke binder-artvarianten ik voor deze kaart heb gemaakt.
Deze ideeën passen goed bij mijn content en geven mij mogelijkheden om te experimenteren met scrollen, swipen, selecteren en het tonen van afbeeldingen.

## Check-out woe. 9 sept.

1. Leg uit waar het Visual Research in 3 stappen naartoe werkt.

Bij stap 1 verzamel je directe beelden die bij je onderwerp en sfeerwoorden passen. Bij stap 2 zoek je abstractere beelden die passen bij de kleuren, vormen, typografie en uitstraling die je wilt gebruiken. Bij stap 3 kies je de belangrijkste beelden en vertaal je deze naar visuele uitgangspunten voor je eigen ontwerp.

2. Vertel in 2 zinnen waar jouw Garden over gaat en met welke content je dat gaat doen (beeld, tekst, sound, animatie enz.).

Mijn digital garden gaat over mijn haakwereld en de knuffels die ik zelf maak. Ik gebruik hiervoor foto’s, teksten, illustraties en animaties om mijn creaties en het maakproces te laten zien.

3. Vertel kort welk idee van de Crazy 8 je het liefst zou willen uitvoeren of verder zou willen onderzoeken.

Van mijn Crazy 8 wil ik het idee van de haakpatronen als galerij verder onderzoeken. Dit idee past het beste bij mij en kan ik persoonlijk maken met zachte vormen, gehaakte omlijstingen en interactieve afbeeldingen.

## Voorbereiding 9 september

### Presentatie over mijn creatieve interesses

Voor woensdag 9 september moest ik een korte presentatie voorbereiden als startpunt voor mijn digital garden. In de presentatie moest ik:
mijn persoonlijke interesse uitleggen;
tien inspiratiebronnen verzamelen;
ongeveer vijftig afbeeldingen onderzoeken;
een eerste tekst van maximaal 180 tekens schrijven.

#### Een onderwerp kiezen

Eerst vond ik het lastig om een geschikt onderwerp te kiezen. Mijn eerste idee was om de presentatie over mijn studie CMD te maken. Nadat ik de opdracht beter had bekeken, begreep ik dat het onderwerp echt over een persoonlijke interesse moest gaan.
Daarna twijfelde ik tussen alleen Pokémon binder art en meerdere creatieve hobby’s. Uiteindelijk koos ik voor mijn creatieve interesses:

- haken;
- Pokémon binder art maken;
- stickers ontwerpen en maken;
- journalen.

Deze hobby’s lijken misschien verschillend, maar hebben veel overeenkomsten. Bij iedere hobby werk ik met kleuren, materialen en kleine details. Vaak begin ik met losse ideeën die tijdens het maken steeds verder groeien.
<img src="./assets/images-readme/presentatie1.png" alt="slide met alle hobby's" />
Foto: slide met alle hobby's

#### Inspiratie en afbeeldingen verzamelen

Voor iedere hobby heb ik afbeeldingen verzameld en een eigen collage gemaakt. Hierdoor hoefde ik niet alle vijftig afbeeldingen op één drukke slide te zetten. Ik verdeelde de collages over aparte slides voor haken, binder art, stickers en journalen.

Tijdens het onderzoeken van de afbeeldingen ontdekte ik verschillende overeenkomsten:
opvallende en bijpassende kleurencombinaties;
speelse vormen en kleine details;
digitaal en met de hand werken;
losse onderdelen samenbrengen tot één geheel;
experimenteren en ontwerpen blijven aanpassen;
iets persoonlijks en unieks maken.
Daarnaast heb ik tien links verzameld die ik als inspiratiebronnen heb gebruikt. Hiervoor heb ik gekeken naar Pokémonkaarten, haakpatronen, stickers, journals en andere creatieve voorbeelden.
<img src="./assets/images-readme/haken.jpg" alt="collage haken" />
Foto: collage Haken.

<img src="./assets/images-readme/binder-art.jpg" alt="collage binder-art" />
foto: collage Pokemon binder art.

<img src="./assets/images-readme/journal.jpg" alt="collage journal" />
Foto: collage journaling.

<img src="./assets/images-readme/stickers.jpg" alt="collage stickers" />
Foto: collage stickers

#### De presentatie maken met Remark.js

Ik heb de presentatie met Remark.js gemaakt in Visual Studio Code. Iedere nieuwe slide begint met drie streepjes:
(---)
Voor titels gebruikte ik een # en voor opsommingen een -. In mijn presentatiemap maakte ik een aparte map met de naam images. Hierin plaatste ik alle collages en screenshots.

## Maandag 7 september

### Sprintplanning en onderzoek

#### Sprintplanning

Tijdens deze les zijn we begonnen met de planning van Sprint 1. De opdracht voor deze sprint is om de eerste versie van mijn eigen digital garden te ontwerpen, te realiseren en uiteindelijk te publiceren met HTML en CSS.
Het is daarbij niet alleen belangrijk dat mijn website er goed uitziet en technisch werkt. Het ontwerp moet ook ‘webby’ zijn. Dit betekent dat ik gebruik moet maken van de mogelijkheden en eigenschappen van het web. Mijn digital garden moet dus niet aanvoelen als een statische poster die toevallig online staat, maar als een website waarop bezoekers kunnen navigeren, ontdekken en verschillende soorten content kunnen bekijken.
Tijdens deze sprint wil ik daarom niet alleen aandacht besteden aan de vormgeving. Ik wil ook nadenken over de structuur, navigatie, interactie en de manier waarop verschillende onderwerpen met elkaar verbonden kunnen worden.

#### Mijn sprint plannen

Tijdens de sprintplanning hebben we gekeken naar hoe ik het werk voor deze sprint kan opdelen in kleinere en overzichtelijke taken. Hiervoor gebruiken we een projectboard met drie kolommen:

- Todo
- In Progress
- Done
  In de kolom Todo staan de taken waaraan ik nog moet beginnen. Wanneer ik met een taak bezig ben, verplaats ik deze naar In Progress. Zodra een taak helemaal is afgerond, kan ik deze verplaatsen naar Done.

Ik vind deze manier van plannen handig, omdat ik hierdoor niet alleen één grote opdracht voor mij zie. De opdracht wordt verdeeld in kleinere onderdelen die ik één voor één kan uitvoeren. Hierdoor kan ik beter zien wat er nog moet gebeuren en wordt het makkelijker om aan de opdracht te beginnen.
Door de taken steeds van Todo naar In Progress en uiteindelijk naar Done te verplaatsen, kan ik mijn voortgang tijdens de sprint bijhouden. Het geeft mij ook een duidelijker beeld van wat ik al heb gedaan en waar ik nog verder aan moet werken.

#### Onderzoek naar Digital Gardens

Na de sprintplanning hebben we ons verdiept in wat een digital garden precies is. Hiervoor hebben we verschillende artikelen gelezen en besproken.
We werkten hierbij volgens de expertgroepenmethode. Iedere groep verdiepte zich in een ander artikel. Daarna deelden we de belangrijkste informatie en inzichten met elkaar. Op deze manier hoefde niet iedereen precies hetzelfde artikel te onderzoeken en kregen we toch informatie uit meerdere bronnen.
Door de verschillende artikelen kreeg ik meerdere perspectieven op wat een digital garden kan zijn. Er bestaat namelijk niet één vaste manier waarop een digital garden eruit moet zien. Toch kwamen bepaalde eigenschappen in meerdere artikelen terug.
De belangrijkste onderwerpen die ik uit het onderzoek heb gehaald, zijn:

- een digital garden blijft groeien;
- informatie wordt georganiseerd op basis van \* verbindingen;
- het is een plek om zichtbaar te leren;
- fouten en feedback horen bij het proces;
- de website mag persoonlijk en experimenteel zijn;
- verschillende soorten content mogen door elkaar staan;
- de maker blijft eigenaar van de website en de inhoud.

#### Een Digital Garden is een groeiende plek

Een van de belangrijkste dingen die ik uit de artikelen heb gehaald, is dat een digital garden niet af hoeft te zijn.

Een normale blog bestaat vaak uit losse artikelen. Deze artikelen worden geschreven, gepubliceerd en daarna meestal niet meer aangepast. De berichten staan vaak op volgorde van publicatiedatum, waarbij het nieuwste bericht bovenaan staat.
Bij een digital garden werkt dit anders. Pagina’s en ideeën mogen blijven veranderen. Een idee kan klein en nog onvolledig beginnen. Later kan de pagina worden uitgebreid wanneer de maker meer over het onderwerp leert, nieuwe inspiratie krijgt of feedback ontvangt.
Maggie Appleton beschrijft hiervoor verschillende stadia waarin een pagina zich kan bevinden:

- Seedling – een vroeg, klein en nog ruw idee;
- Budding – een idee dat al verder is onderzocht en uitgewerkt;
- Evergreen – een redelijk compleet idee dat nog steeds kan blijven veranderen.

Ik vond deze verdeling interessant, omdat hierdoor zichtbaar wordt dat niet iedere pagina op een website even ver uitgewerkt hoeft te zijn. Een korte ontdekking kan al gedeeld worden als een Seedling. Wanneer ik later meer informatie verzamel, kan deze pagina doorgroeien naar Budding en uiteindelijk naar Evergreen.
Dit haalt voor mij ook een deel van de druk weg om een pagina meteen helemaal perfect te maken. Het hoort juist bij het concept van een digital garden dat sommige ideeën nog aan het groeien zijn.

#### Informatie organiseren op basis van verbindingen

Een ander belangrijk verschil tussen een blog en een digital garden is de manier waarop de informatie wordt georganiseerd.
Bij een blog staan berichten meestal in een tijdlijn. Het nieuwste bericht staat bovenaan en oudere berichten zakken steeds verder naar beneden. De datum waarop iets is gepubliceerd, bepaalt dus voor een groot deel waar de informatie staat.
Bij een digital garden draait het veel meer om de verbindingen tussen verschillende onderwerpen. Pagina’s worden aan elkaar gekoppeld omdat de inhoud iets met elkaar te maken heeft. Een bezoeker hoeft daardoor niet één vaste route te volgen, maar kan via links steeds nieuwe onderwerpen ontdekken.
Ik vond het beeld van Maggie Appleton hierover erg duidelijk. Een traditionele tijdlijn is één rechte route, terwijl een digital garden meer lijkt op een verzameling van paden die op verschillende manieren met elkaar verbonden zijn.
Mike Caulfield beschrijft ongeveer hetzelfde verschil met de begrippen The Garden en The Stream.

- The Stream
  De Stream lijkt op sociale media. Berichten verschijnen in een tijdlijn en worden na verloop van tijd vervangen door nieuwe berichten. Oudere informatie verdwijnt steeds verder naar beneden en wordt daardoor moeilijker terug te vinden.
- The Garden
  De Garden is juist een plek waarin informatie kan blijven bestaan en verder kan groeien. Verschillende onderwerpen kunnen met elkaar worden verbonden. De bezoeker kan zelf kiezen welke route die door de informatie wil volgen.
  Dit inzicht helpt mij om anders naar de structuur van mijn eigen website te kijken. Ik hoef mijn content niet alleen op datum te sorteren. Ik kan onderwerpen ook met elkaar verbinden op basis van overeenkomsten, technieken, materialen of inspiratie.

Bij mijn eigen digital garden kan een bezoeker bijvoorbeeld vanuit een eindresultaat doorklikken naar het maakproces, de inspiratie, een experiment of een andere creatie waarin ik dezelfde techniek heb gebruikt.

#### Een plek om zichtbaar te leren

Een digital garden is niet alleen bedoeld om aan anderen te laten zien wat iemand al weet. Het kan ook een plek zijn waarop je zichtbaar maakt wat je nog aan het leren bent.
Shawn Wang noemt dit Learning in Public. Binnen zijn digital garden mogen ideeën nog onvolledig zijn en mag hij fouten maken. De bedoeling is juist dat zijn kennis blijft veranderen wanneer hij iets nieuws leert of feedback ontvangt.
Dit maakt een digital garden voor mij anders dan een portfolio. In een portfolio laat ik meestal mijn beste en meest uitgewerkte werk zien. Het eindresultaat staat daar vaak centraal.

In een digital garden mag ik juist ook laten zien:

- welke ideeën ik heb onderzocht;
- welke vragen ik nog heb;
- welke experimenten wel of niet werkten;
- wat ik tijdens het maken heb ontdekt;
- hoe mijn ontwerp is veranderd;
- welke feedback ik heb ontvangen;
- wat ik later nog verder wil onderzoeken.
  Hierdoor hoeft mijn digital garden niet alleen een verzameling van perfecte eindproducten te worden. Het mag ook een verzameling zijn van schetsen, experimenten, ontdekkingen en ideeën die nog in ontwikkeling zijn.

Dit past goed bij mijn eigen ontwerp- en maakproces. Mijn eerste idee is namelijk niet altijd meteen het uiteindelijke idee. Door mijn tussenstappen te laten zien, wordt beter zichtbaar hoe ik tot een eindresultaat ben gekomen.

#### Feedback en fouten horen bij het proces

Bij Learning in Public hoort ook dat andere mensen feedback kunnen geven.

In het artikel Digital Garden Terms of Service wordt beschreven dat bezoekers mogen aangeven wanneer informatie niet klopt of wanneer zij het ergens niet mee eens zijn. De schrijver ziet dit niet meteen als iets negatiefs, maar juist als een mogelijkheid om verder te leren.
Wanneer nieuwe informatie laat zien dat iets niet klopt, kan een pagina opnieuw worden aangepast. De inhoud staat dus niet voor altijd vast.

Dit sluit goed aan bij het idee dat een digital garden nooit helemaal klaar is. Feedback, nieuwe kennis en nieuwe ervaringen kunnen ervoor zorgen dat een pagina opnieuw verandert.
Ik vind dit een interessant uitgangspunt voor mijn eigen website. Als een onderdeel nog niet goed werkt of als ik later een beter idee krijg, betekent dit niet dat mijn eerdere werk waardeloos was. Het laat juist zien hoe mijn kennis en ontwerp zich ontwikkelen.

#### Mijn eigen website bezitten

Een ander onderwerp dat in het onderzoek naar voren kwam, is independent ownership. Dit betekent dat je digital garden echt van jezelf is en niet volledig afhankelijk is van een bestaand platform.
Wanneer iemand alleen gebruikmaakt van Instagram, TikTok, Facebook, X of Medium, bepaalt dat platform voor een groot deel hoe de content eruitziet en hoe bezoekers deze kunnen bekijken. Als het platform de regels of mogelijkheden verandert, heb je daar als gebruiker weinig controle over.

Bij een eigen website heb ik meer controle over:

- de vormgeving;
- de indeling van de pagina’s;
- de navigatie;
- de soorten content die ik plaats;
- de verbindingen tussen onderwerpen;
- de manier waarop mijn website zich later ontwikkelt.

Met HTML en CSS bouw ik mijn eigen plek op het internet. Ik kan daardoor zelf bepalen hoe mijn digital garden eruitziet en hoe bezoekers door de inhoud bewegen.
Dit sluit goed aan bij de opdracht, omdat we onze digital garden zelf gaan ontwerpen, bouwen en publiceren.

#### Waar had ik het meeste aan?

Waar ik tijdens deze les het meeste aan had, was het idee dat een digital garden niet af hoeft te zijn.
Normaal heb ik snel het gevoel dat iets eerst helemaal goed en uitgewerkt moet zijn voordat ik het kan laten zien. Bij een digital garden hoort het juist bij het concept dat ideeën nog groeien en veranderen.

Ik vond vooral het verschil tussen Seedling, Budding en Evergreen duidelijk. Deze termen maken zichtbaar dat niet iedere pagina hetzelfde niveau van uitwerking hoeft te hebben. Een klein idee kan al onderdeel zijn van de website en later verder worden aangevuld.
Ook het verschil tussen The Garden en The Stream heeft mij geholpen. Ik begrijp hierdoor beter dat ik mijn website niet alleen als een lijst met nieuwe berichten moet zien. Ik kan onderwerpen juist met elkaar verbinden, zodat bezoekers zelf verschillende routes door mijn website kunnen volgen.
Daarnaast vond ik het idee van Learning in Public interessant. Mijn digital garden hoeft niet alleen te laten zien wat ik al kan. Ik mag ook laten zien wat ik nog aan het ontdekken en leren ben.

## chech-out: heel kort

1. Een digital garden is een persoonlijke website waarop ideeën en projecten blijven groeien. Anders dan een gewone website hoeft de inhoud niet direct af of perfect te zijn.

2. Een website is ‘webby’ wanneer je de mogelijkheden van het web gebruikt, zoals links, interacties, animaties en verschillende routes. Vooral persoonlijke en speelse websites inspireren mij.

3. Ik wil mijn digital garden over mijn haakwereld maken. Hierin wil ik mijn haakcreaties, patronen, inspiratie en maakproces op een persoonlijke en interactieve manier laten zien.

## Voorbereiding maandag 7 september: We hebben voor deze les geen voorbereiding.

# Sprint 0:

## vrijdag 4 september

### Deep Dive schetsen

Tijdens deze Deep Dive heb ik geleerd dat schetsen niet alleen bedoeld is om iets mooi te tekenen. Het helpt vooral om na te denken, ideeën te onderzoeken en ontwerpkeuzes zichtbaar te maken. Een belangrijke uitspraak uit de les was:
Schetsen = denken = niet in één keer ‘klaar’.
Een schets hoeft dus niet perfect te zijn. Het belangrijkste is dat ik ideeën snel zichtbaar kan maken en verschillende mogelijkheden kan vergelijken.

#### Oude schetsen vergelijken

Voor de eerste opdracht heb ik schetsen uit eerdere projecten meegenomen, zoals logoschetsen, Crazy 8’s, interfaces, typografie, positionering en uitgewerkte tekeningen.
Mijn tekening van D’Oude Veiling laat duidelijk het eindresultaat zien, maar minder goed hoe ik tot dit ontwerp ben gekomen. Mijn Crazy 8 ziet er minder netjes uit, maar laat juist verschillende oplossingen zien. Bij mijn schetsen voor de positionering en typografie van mijn campagnewebsite is mijn proces nog duidelijker zichtbaar door de varianten en annotaties.
Hierdoor leerde ik dat een mooie schets niet automatisch een goede ontwerpschets is.

#### Een goede schets

Een goede schets hoeft voor mij niet perfect te zijn, maar moet wel mijn denkproces zichtbaar maken. Daarbij helpen:

- meerdere ideeën en varianten;
- annotaties, pijlen en korte teksten;
- verschillende lijndiktes, kleuren, highlights en schaduwen;
- het zichtbaar maken van interacties en verschillende states.
  Annotaties zijn handig omdat ik daarmee iets kan uitleggen zonder alles volledig te tekenen.

#### Oefenen met de basis

We hebben geoefend met lijnen, vormen, grids en interfaces. Ik heb geleerd dat ik eerst met eenvoudige vormen de basis kan neerzetten en daarna details kan toevoegen.
Ook hebben we het verschil tussen low-fi en hi-fi behandeld. Een low-fi schets is eenvoudig en bedoeld om snel een idee of indeling te onderzoeken. Een hi-fi uitwerking bevat meer details en lijkt meer op het uiteindelijke ontwerp.
Met dikkere lijnen en highlights kan ik belangrijke onderdelen benadrukken. Schaduwen kunnen bijvoorbeeld duidelijk maken dat iets klikbaar is. Door annotaties in een andere kleur te schrijven, blijft het verschil tussen mijn ontwerp en mijn uitleg zichtbaar.
Interactie en animatie schetsen

Een website bestaat niet alleen uit stilstaande schermen. Een gebruiker kan klikken, swipen en hoveren. Deze interacties kan ik schetsen met pijlen, stippellijnen, annotaties, kleuren en verschillende states.
Met de zoom-techniek kan ik één onderdeel groter tekenen om te laten zien wat er verandert. In de les zagen we bijvoorbeeld hoe een sidebar verschijnt, hoe een icoon verandert nadat het is geselecteerd en hoe een swipe nieuwe opties zichtbaar maakt.

#### Wat heb ik hier het meest van geleerd?

Ik heb vooral geleerd dat schetsen een manier van denken is. Het is juist waardevol om meerdere versies te maken, dingen opnieuw te proberen en erbij te schrijven waarom ik bepaalde keuzes maak.
Bij het ontwerpen van mijn website wil ik daarom niet meteen één idee volledig uitwerken. Ik wil eerst verschillende mogelijkheden onderzoeken. Daarbij ga ik ook schetsen hoe gebruikers door mijn website bewegen en hoe onderdelen reageren op klikken, swipen en hoveren.

### Deep Dive – Pick 'n' Mix

Tijdens de Deep Dive hebben we verder gekeken naar hoe je een passend lettertype kiest en hoe je verschillende lettertypes met elkaar kunt combineren. Daarbij kwamen veel dingen uit de artikelen terug.
Bij het kiezen van een lettertype kan ik onder andere kijken naar:

- stijl – past de uitstraling bij wat ik wil communiceren?
- leesbaarheid – blijft de tekst duidelijk?
- opties – welke varianten en mogelijkheden heeft de fontfamilie?
- beschikbaarheid – kan en mag ik het lettertype daadwerkelijk gebruiken?
  We hebben ook gekeken naar de geschiedenis van verschillende soorten lettertypes. In de slides kwamen onder andere Fraktur, Venetian, Old Face, Transitional, Modern, Egyptian en Sans voorbij. Hierdoor kon ik goed zien dat lettertypes door de jaren heen steeds andere kenmerken hebben gekregen.

#### Leesbaarheid

Een onderdeel waar ik veel aan had was het verschil in leesbaarheid tussen lettertypes.
Zelfs wanneer verschillende lettertypes allemaal op bijvoorbeeld 18 px staan, kunnen ze toch heel verschillend groot ogen. Dit komt onder andere door de x-hoogte en de verhoudingen van de letters. In de slides werd dit zichtbaar gemaakt door verschillende lettertypes op dezelfde grootte naast elkaar te zetten.
Hierdoor begrijp ik beter dat ik bij mijn website niet alleen kan zeggen: "18 px is groot genoeg." Ik moet het lettertype daadwerkelijk op mijn website bekijken en testen of het prettig leesbaar is.

#### Lettertypes combineren

We hebben daarna gekeken naar het combineren van lettertypes. Wat ik hiervan vooral heb onthouden, is dat een goede combinatie vaak bestaat uit een balans tussen contrast en overeenkomst.
Contrast kan bijvoorbeeld ontstaan door:

- sans serif tegenover serif;
- bold tegenover light;
- narrow tegenover wide;
- roman tegenover italic of small caps.
  Tegelijkertijd kunnen de lettertypes overeenkomsten hebben, bijvoorbeeld doordat ze uit dezelfde fontfamilie komen, dezelfde letterontwerper hebben, een vergelijkbare constructie hebben of uit ongeveer dezelfde periode komen.
  Ik vond dit vooral handig omdat ik hiervoor bij het combineren van lettertypes voornamelijk keek naar of ik ze mooi bij elkaar vond staan. Nu weet ik beter naar welke eigenschappen ik kan kijken om uit te leggen waarom twee lettertypes wel of niet bij elkaar passen.

#### Waar had ik het meeste aan?

Waar ik het meeste aan had, is dat ik nu veel beter begrijp dat een lettertype kiezen niet alleen een visuele keuze is. Hiervoor keek ik vooral naar welk lettertype ik mooi vond en of het bij mijn ontwerp paste. Nu weet ik dat ik ook moet kijken naar leesbaarheid, x-hoogte, verschillende gewichten en stijlen, taalondersteuning, het apparaat waarop de tekst wordt bekeken en waarvoor het lettertype gebruikt gaat worden.
Voor mijn eigen website vind ik vooral de leesbaarheid belangrijk. Mijn portfolio moet er natuurlijk bij mij passen en een eigen uitstraling hebben, maar bezoekers moeten de informatie ook makkelijk kunnen lezen en snel kunnen vinden.
Ook het combineren van lettertypes vond ik erg nuttig. Ik weet nu dat ik niet zomaar twee mooie lettertypes naast elkaar moet zetten, maar dat ik kan zoeken naar een combinatie met zowel contrast als overeenkomst. Dat geeft mij veel meer houvast wanneer ik straks de typografie voor mijn eigen website ga bepalen.

Wat ik uiteindelijk vooral meeneem uit deze voorbereiding en Deep Dive is:
Ik moet een lettertype niet alleen kiezen omdat ik het mooi vind, maar omdat het past bij de boodschap, goed leesbaar is én goed werkt op de plek waar ik het ga gebruiken.

## Check-out vrijdag 4 sept: vanwege de Deep-dives hadden we geen chech-out vandaag.

## voorbereiding voor 4 september

### Voorbereiding Deep Dive: Typografie

Voor deze Deep Dive heb ik twee artikelen gelezen over het kiezen en gebruiken van lettertypes. Tijdens het lezen heb ik per artikel de dingen opgeschreven die ik het belangrijkste of opvallendste vond.

### Artikel 1: How to choose the right typeface

In dit artikel wordt uitgelegd dat het kiezen van een lettertype niet alleen gaat om welk lettertype je mooi vindt. Je moet vooral kijken naar waarvoor je het lettertype gaat gebruiken, wat je ermee wilt uitstralen en of het technisch geschikt is.

Wat ik uit dit artikel heb gehaald:

1. Kijk eerst waarvoor je het lettertype gaat gebruiken.Een lettertype voor een grote titel heeft andere eigenschappen nodig dan een lettertype voor lange stukken tekst. Bij langere teksten is leesbaarheid veel belangrijker, terwijl je bij een grote titel meer ruimte hebt voor een opvallend lettertype.

2. Gebruik liever niet te veel verschillende lettertypes.Voor veel ontwerpen kan één goede fontfamilie al genoeg zijn, omdat daar bijvoorbeeld regular, bold en italic varianten in zitten. Meer lettertypes gebruiken betekent dus niet automatisch dat een ontwerp beter wordt.

3. Een lettertype moet passen bij de boodschap die je wilt overbrengen.Lettertypes hebben een bepaalde uitstraling en kunnen daardoor invloed hebben op hoe de inhoud overkomt. Een lettertype kan bijvoorbeeld formeel, modern, rustig of juist opvallend voelen. Het is daarom belangrijk dat de uitstraling past bij de boodschap van het ontwerp.

4. Controleer welke tekens en talen een lettertype ondersteunt.Dit vond ik iets waar ik zelf niet zo snel aan zou denken. Niet ieder lettertype bevat automatisch alle accenten, symbolen en speciale tekens. Je kunt dus een mooi lettertype kiezen en er later achter komen dat bepaalde tekens die je nodig hebt ontbreken.

5. Niet ieder lettertype werkt even goed op een scherm.Sommige lettertypes zijn speciaal gemaakt om ook op kleinere formaten en beeldschermen goed leesbaar te blijven. Hele dunne of gedetailleerde letters kunnen er mooi uitzien, maar op een klein scherm juist minder goed werken.

6. Bij het combineren van lettertypes moet er samenhang én verschil zijn.Lettertypes hoeven niet precies hetzelfde te zijn om goed bij elkaar te passen. Het kan juist helpen als er contrast is, maar ze moeten wel een bepaalde overeenkomst hebben in bijvoorbeeld uitstraling of bedoeling. Ook helpt het als de lettertypes verschillende functies krijgen, bijvoorbeeld één voor koppen en één voor lopende tekst.

### Artikel 2: Typography for User Interfaces

Bij dit artikel ging het veel meer over typografie binnen interfaces en websites. Wat ik hier vooral interessant aan vond, is dat tekst eigenlijk een heel groot onderdeel van een interface is. Typografie bepaalt daardoor niet alleen hoe een website eruitziet, maar ook hoe makkelijk iemand hem kan gebruiken.

Wat ik uit dit artikel heb gehaald:

1. Tekst is een onderdeel van de interface zelf.Een interface bestaat voor een groot deel uit woorden: knoppen, menu's, titels, labels en andere teksten. Typografie is daarom niet alleen iets wat je achteraf mooi maakt, maar hoort echt bij het ontwerpen van de interface.

2. Letters moeten duidelijk van elkaar te onderscheiden zijn.Bij een interface is leesbaarheid extra belangrijk. Letters zoals een hoofdletter I, kleine l en bijvoorbeeld het cijfer 1 kunnen bij sommige lettertypes heel erg op elkaar lijken. Hierdoor moet een gebruiker meer moeite doen om de tekst te begrijpen.

3. Een goed lettertype voor een interface hoeft niet de aandacht te trekken.Het lettertype moet de gebruiker vooral helpen om de inhoud te begrijpen. Het hoeft dus niet altijd het meest bijzondere of opvallende lettertype te zijn. De gebruiker moet eigenlijk zonder moeite kunnen lezen wat er staat.

4. Een UI-lettertype moet op verschillende formaten werken.Een website kan bekeken worden op een groot computerscherm, maar ook op een kleine telefoon. Daarom moet een lettertype flexibel zijn en ook bij kleinere tekstgroottes goed leesbaar blijven.

5. De x-hoogte heeft invloed op de leesbaarheid.De x-hoogte is de hoogte van kleine letters, gemeten aan bijvoorbeeld de letter x. Een grotere x-hoogte kan ervoor zorgen dat tekst op kleine formaten makkelijker leesbaar is. Te groot is alleen ook weer niet altijd beter, omdat sommige letters dan juist moeilijker van elkaar te onderscheiden kunnen worden.

6. Mensen lezen tekst in een interface anders dan een lange tekst.In een interface staan vaak losse woorden of korte stukjes tekst, zoals bij een menu of knop. Daardoor is het extra belangrijk dat individuele letters en woorden snel herkenbaar zijn.

#### Wat vond ik het opvallendst?

Ik vond het interessant dat een lettertype binnen een interface eigenlijk niet te veel aandacht hoeft te trekken. In eerste instantie kijk ik bij een lettertype snel naar de uitstraling. Door dit artikel begrijp ik beter dat een lettertype vooral de gebruiker moet ondersteunen en de inhoud duidelijk moet maken.

#### Wat heb ik van deze voorbereiding geleerd?

Door deze twee artikelen begrijp ik dat typografie veel meer is dan het kiezen van een mooi lettertype. Een lettertype moet passen bij het doel en de uitstraling van mijn website, maar het moet vooral goed leesbaar en bruikbaar zijn.
Bij het kiezen van mijn lettertypes wil ik daarom letten op:

- de leesbaarheid van titels en lopende tekst;
- de uitstraling die bij mijn onderwerp past;
- het aantal lettertypes en varianten;
- de herkenbaarheid van verschillende letters en cijfers;
- de beschikbare tekens en symbolen;
- de leesbaarheid op desktop en mobiel;
- het verschil en de samenhang tussen mijn fonts.

Wat ik vooral meeneem, is dat ik mijn keuze niet alleen moet kunnen uitleggen met ‘ik vind dit lettertype mooi’. Ik moet ook kunnen onderbouwen waarom het bij mijn website past en waarom het voor de gebruiker prettig leesbaar is.

## woensdag 2 september

### verwerking van de les

#### Voorbereiding

Voor deze les had ik de artikelen van Interneting Is Hard gelezen en de pagina Structuring content with HTML van MDN gescand. Tijdens het lezen heb ik aantekeningen gemaakt en twee vragen meegenomen naar de les. Ook had ik opgeschreven welke dingen mij tijdens het lezen verwonderden.
Mijn volledige aantekeningen en voorbereiding staan eerder in mijn Learning Log.

#### Antwoorden op mijn vragen

Tijdens mijn voorbereiding had ik twee vragen opgeschreven die ik tijdens de les wilde stellen.

1. Wanneer kan ik beter een HTML-element als selector gebruiken en wanneer een class?
   Tijdens de les kwam ik erachter dat we binnen dit project geen classes mogen gebruiken. Het is juist de bedoeling dat we leren om HTML-elementen op andere manieren te selecteren met CSS. Hierdoor moet ik dus verder kijken dan alleen een class toevoegen wanneer ik één specifiek onderdeel wil vormgeven.
   Dit vind ik eigenlijk wel interessant, omdat ik normaal waarschijnlijk snel een class zou gebruiken. Nu word ik gedwongen om beter naar mijn HTML-structuur en CSS-selectors te kijken.

2. Welke CSS-regel krijgt voorrang wanneer meerdere regels hetzelfde element aanpassen?
   Ik heb geleerd dat de volledige manier waarop CSS bepaalt welke regel voorrang krijgt best complex is. De docent gaf aan dat we daar op dit moment nog niet helemaal diep op in hoeven te gaan.
   Wat ik voor nu vooral moet onthouden is:
   Hoe specifieker een CSS-regel is, hoe meer voorrang deze heeft.
   Voor nu is dit voldoende om mee te werken. Later gaan we waarschijnlijk dieper in op hoe deze voorrang precies wordt berekend.

#### Wat mij verwonderde

Tijdens mijn voorbereiding had ik al een aantal dingen gevonden die mij verwonderden, onder andere tijdens het scannen van MDN. Zo kwam ik erachter dat een decoratieve afbeelding juist een lege alt="" kan krijgen en dat ‘klik hier’ geen goede tekst voor een link is.
Deze verwonderingen en mijn uitleg daarbij heb ik al bij mijn voorbereiding uitgewerkt.

#### Nieuwe bron uit de les; HTML5 Doctor

Tijdens de les kregen we ook HTML5 Doctor als website mee. Deze website kan ik gebruiken om meer te ontdekken over HTML-elementen en om op te zoeken waarvoor verschillende elementen bedoeld zijn.
Dit sluit goed aan op wat we nu aan het leren zijn, omdat we niet alleen moeten kijken naar hoe iets eruitziet, maar ook naar welk HTML-element inhoudelijk het beste past bij de content.

#### Wat neem ik mee uit deze les?

Door mijn voorbereiding had ik al kennisgemaakt met HTML-structuur, semantiek, CSS-selectors en de cascade. Tijdens de les zijn vooral mijn vragen hierover duidelijker geworden.
Ik weet nu dat ik binnen dit project niet zomaar classes kan gebruiken en daardoor bewuster moet nadenken over mijn HTML-structuur en de manier waarop ik elementen selecteer. Ook weet ik dat CSS-regels verschillende prioriteiten kunnen hebben en dat ik voor nu vooral moet onthouden dat de specifiekste regel voorrang krijgt.
Daarnaast heb ik met HTML5 Doctor een nieuwe bron gekregen die ik tijdens het maken van mijn website kan gebruiken wanneer ik niet weet welk HTML-element ik het beste kan gebruiken.

Vanwege een priva afspraak heb ik helaas niet de tweede deepdive kunnen maken

## Check-out woensdag 2 sept: vanwege de Deep-dives hadden we geen chech-out vandaag.

## Voorbereidingen 2 september

### Voorbereiding basis HTML, CSS, fonts en kleur

Voor de voorbereiding van de les heb ik informatie gelezen over webfonts, HTML en CSS. Hierdoor begrijp ik beter hoe een website wordt opgebouwd en welke keuzes ik moet maken bij het gebruiken van lettertypen.

### Web-safe fonts en @font-face

Ik heb geleerd dat een lettertype beschikbaar moet zijn op het apparaat van de bezoeker of door de website geladen moet worden. Er zijn hiervoor drie mogelijkheden:
Web-safe fonts: deze lettertypen staan standaard op de meeste apparaten. Ze laden snel en gebruiken geen extra data. Voorbeelden hiervan zijn Arial, Verdana, Georgia en Times New Roman.
Webfontservices: dit zijn diensten zoals Google Fonts en Adobe Fonts. Tijdens deze opdracht mogen wij deze niet gebruiken. Ze kunnen namelijk zorgen voor minder privacy, extra laadtijd en afhankelijkheid van een externe dienst.

@font-face: hiermee kan ik een lettertype zelf downloaden, in mijn projectmap zetten en vanuit mijn CSS-bestand laden.
Met font-family bepaal ik welk lettertype een element krijgt. Als ik een lettertype aan de body geef, wordt dit meestal automatisch overgenomen door de elementen die hierin staan. Dit heet inheritance.
Ik kan ook verschillende lettertypen achter elkaar plaatsen. Dit heet een font-stack. Als het eerste lettertype niet geladen kan worden, probeert de browser automatisch het volgende lettertype.
body {
font-family: Georgia, Times, serif;
}
Met system-ui gebruikt de website het standaardlettertype van het besturingssysteem. Hierdoor kan het lettertype er op een Windows-computer bijvoorbeeld iets anders uitzien dan op een MacBook.
Wanneer ik een zelf gedownload lettertype wil gebruiken, maak ik eerst een map voor de fontbestanden. Daarna koppel ik het lettertype bovenaan mijn CSS-bestand met @font-face.
@font-face {
font-family: "Dyna Puff";
src: url("../fonts/DynaPuff-Bold.ttf");
}

body {
font-family: "Dyna Puff", sans-serif;
}

Een fontfamilie kan uit verschillende bestanden bestaan, zoals regular, italic, bold en bold italic. Met font-weight en font-style geef ik aan welke variant bij ieder bestand hoort. De browser kan daarna automatisch de juiste variant gebruiken.
Ik heb ook geleerd dat het niet slim is om heel veel lettertypen en varianten aan mijn website toe te voegen. Hierdoor moet de bezoeker meer bestanden downloaden en kan de website langzamer worden. Daarnaast moet ik controleren of de licentie van een lettertype het gebruik op een website toestaat.

<img src="./assets/images-readme/aantekening3sepetmber2.png" alt="aantekeningen deep dive (web safe fonts)" />
Foto: aantekeningen deep dive (web safe font).

### HTML & CSS Is Hard

Voor de voorbereiding heb ik de onderdelen Introduction, Basic Web Pages en Hello, CSS van HTML & CSS Is Hard gelezen.
In Introduction heb ik geleerd dat HTML, CSS en JavaScript ieder een eigen functie hebben. HTML bepaalt de inhoud en structuur van een website. CSS wordt gebruikt voor de vormgeving en JavaScript maakt interacties mogelijk.

In Basic Web Pages heb ik geleerd hoe een HTML-pagina wordt opgebouwd met html, head en body. Ook kwamen headings, paragrafen en lijsten aan bod. HTML bepaalt dus niet alleen wat er op een pagina staat, maar geeft ook betekenis en structuur aan de inhoud.
In Hello, CSS heb ik geleerd hoe ik een CSS-bestand aan HTML kan koppelen. Een CSS-regel bestaat uit een selector, een property en een value. Daarnaast heb ik gelezen over kleuren, lettertypen, meeteenheden, inheritance en de cascade.
Door deze artikelen begrijp ik beter dat HTML en CSS twee verschillende taken hebben, maar wel met elkaar samenwerken. HTML bepaalt wat een onderdeel is en CSS bepaalt hoe dit onderdeel eruitziet.

Na het lezen had ik nog twee vragen:
Wanneer kan ik beter een HTML-element, zoals p of h1, als selector gebruiken en wanneer is een class handiger?
Hoe bepaalt CSS welke regel voorrang krijgt als meerdere regels hetzelfde element aanpassen?

### MDN – Structuring content with HTML

Ik heb ongeveer een half uur scannend gelezen op MDN. Ik heb vooral gekeken naar semantische elementen, zoals header, nav, main, section, article en footer. Deze elementen geven betekenis aan de verschillende onderdelen van een pagina. Dit is duidelijker dan wanneer een hele website alleen met div-elementen wordt opgebouwd.
Ook heb ik gekeken naar links, afbeeldingen, formulieren en tabellen. Bij deze onderwerpen kwam toegankelijkheid vaak terug. Goede HTML helpt niet alleen de browser, maar ook zoekmachines en screenreaders om een website beter te begrijpen.

Ik vond het opvallend dat niet iedere afbeelding een uitgebreide alt-tekst nodig heeft. Als een afbeelding alleen ter decoratie wordt gebruikt, kan deze alt="" krijgen. Een screenreader weet dan dat de afbeelding kan worden overgeslagen.
Ook heb ik geleerd dat ‘klik hier’ geen goede linktekst is. Zonder extra context is namelijk niet duidelijk waar de link naartoe gaat. Een tekst zoals ‘Bekijk mijn contactgegevens’ vertelt veel duidelijker wat iemand na het aanklikken kan verwachten.

### Wat ik hiervan heb geleerd

Ik heb vooral geleerd dat HTML niet alleen bepaalt wat er op het scherm staat. Door semantische elementen, duidelijke linkteksten en passende alt-teksten te gebruiken, kan ik mijn website begrijpelijker en toegankelijker maken.
Daarnaast begrijp ik nu beter hoe lettertypen op het web werken. Voor deze opdracht kan ik een web-safe font gebruiken of een zelf opgeslagen lettertype met @font-face aan mijn website koppelen. Daarbij moet ik niet alleen kijken naar wat ik mooi vind, maar ook letten op leesbaarheid, fallbacks, bestandsgrootte, privacy en de licentie van het lettertype.
Voor mijn eigen website wil ik daarom bewust omgaan met de hoeveelheid fonts en varianten die ik toevoeg. Ik wil een stijl kiezen die bij mijn onderwerp past, maar mijn website moet ook duidelijk leesbaar zijn en snel blijven laden.

<img src="./assets/images-readme/aantekeningen3september.png" alt="aantekeningen van HTML en CSS basis" />
 Foto: aantekeningen van HTML en CSS basi

## kick-off maandag 31 augustus:

31 augustus: Check out

1. Wat is een source hosting platform en welke heb ik gekozen?
   Een source hosting platform is een online plek waar je de bestanden en code van een project kunt opslaan en beheren. Het handige hiervan is dat verschillende versies van je code worden bijgehouden. Hierdoor kun je later terugzien welke aanpassingen je hebt gemaakt en wanneer je deze hebt gemaakt.

Voor mijn website gebruik ik GitHub als source hosting platform. De code van mijn website staat hierdoor online in een repository. De bestanden pas ik aan in Visual Studio Code en daarna stuur ik de nieuwste versie naar GitHub. Met GitHub Pages kan ik mijn website vervolgens online publiceren.

Mijn repository op GitHub, waarin de bestanden en verschillende versies van mijn website worden opgeslagen.
<img src="./assets/images-readme/gitthubstart.png" alt="Je domein koppelen aan je Github" />
Foto:Je domein koppelen aan je Github
Deze foto is wel later toegevoeegd omdat ik niet wist dat dat moest.

2. Welke domeinnaam heb ik gekozen en hoe heb ik deze gekoppeld?
   Ik heb gekozen voor de domeinnaam madebyjudith.nl. Ik heb bewust voor deze naam gekozen omdat ik de website uiteindelijk als mijn persoonlijke portfolio wil blijven gebruiken. Ik kan hier mijn projecten uit het eerste jaar op zetten, maar later ook nieuw werk toevoegen. Zo kan mijn portfolio met mij meegroeien en kan ik de website later gebruiken bij het zoeken naar een stage of werk.

   Om mijn domeinnaam aan mijn website te koppelen, heb ik binnen GitHub Pages mijn eigen domein ingevuld. Daarna heb ik bij mijn domein de benodigde DNS-instellingen aangepast. De uitleg en gegevens die ik hiervoor nodig had, kon ik op DLO vinden.
   Nadat ik deze instellingen had toegevoegd, controleerde GitHub de verbinding. Ik kreeg daarna de melding ‘DNS check successful’. Dit betekende dat mijn GitHub-pagina goed was gekoppeld aan madebyjudith.nl.

Foto: Hier kozen we onze eigen domein naam

<img src="./assets/images-readme/Domeinnaamkiezen.png" alt="Hier kozen we onze eigen domein naam" />

3. Hoe pas ik mijn website aan en publiceer ik deze online?
   Ik pas mijn website aan in Visual Studio Code. Hier kan ik bijvoorbeeld veranderingen maken in mijn HTML- en CSS-bestanden. Tijdens het werken gebruik ik Go Live om mijn website lokaal in de browser te bekijken. Zo kan ik eerst controleren hoe mijn aanpassingen eruitzien, voordat ik ze online publiceer.
   Wanneer ik tevreden ben, sla ik mijn bestanden op. Daarna open ik in Visual Studio Code het onderdeel Source Control. Hier zet ik de aangepaste bestanden klaar en maak ik een commit. Bij deze commit schrijf ik een korte beschrijving van wat ik heb veranderd. Vervolgens push of synchroniseer ik de commit naar GitHub.
   GitHub ontvangt dan de nieuwste versie van mijn bestanden. Via GitHub Pages wordt deze versie automatisch gepubliceerd. Na een korte tijd zijn mijn veranderingen ook zichtbaar op madebyjudith.nl.
   Mijn werkwijze is:
   Aanpassen → testen met Go Live → opslaan → committen → pushen naar GitHub → online publiceren via GitHub Pages

Foto: Dit is het begin wat we gekregen hadden om onze website te maken.

<img src="./assets/images-readme/Blancoversiewebsite.png" alt="Dit is het begin wat we gekregen hadden om onze website te maken." />
